#include "../SDK/SDK.h"

MAKE_SIGNATURE(CSniperDot_GetRenderingPositions, "client.dll", "48 89 5C 24 ? 48 89 74 24 ? 55 57 41 57 48 8D 6C 24", 0x0);
MAKE_SIGNATURE(CBasePlayer_EyePosition, "client.dll", "48 89 5C 24 ? 57 48 83 EC ? 44 8B 81 ? ? ? ? 48 8B FA", 0x0);
MAKE_SIGNATURE(CSniperDot_GetRenderingPositions_EyePosition_Call, "client.dll", "8B 08 89 0F 8B 48 ? 89 4F ? 49 8B CF", 0x0);
MAKE_SIGNATURE(CTFPlayer_EyeAngles, "client.dll", "40 53 48 83 EC ? 48 8B D9 E8 ? ? ? ? 84 C0 74 ? 83 3D", 0x0);
MAKE_SIGNATURE(CSniperDot_GetRenderingPositions_EyeAngles_Call, "client.dll", "48 8D 54 24 ? 48 8D 4C 24 ? F2 0F 10 00 F2 0F 11 44 24 ? 8B 40 ? 89 44 24 ? E8 ? ? ? ? 49 8B 07", 0x0);

static Vec3 s_vEyePosition;
static Vec3 s_vEyeAngles;

MAKE_HOOK(CSniperDot_GetRenderingPositions, S::CSniperDot_GetRenderingPositions(), bool,
	void* rcx, CTFPlayer* pPlayer, Vec3& vecAttachment, Vec3& vecEndPos, float& flSize)
{
	DEBUG_RETURN(CSniperDot_GetRenderingPositions, rcx, pPlayer, vecAttachment, vecEndPos, flSize);

	if (pPlayer && pPlayer->entindex() != I::EngineClient->GetLocalPlayer())
	{
		auto pDot = reinterpret_cast<CSniperDot*>(rcx);

		s_vEyePosition = pPlayer->m_vecOrigin() + pPlayer->GetViewOffset();
		s_vEyeAngles = Math::VectorAngles(pDot->GetAbsOrigin() - s_vEyePosition);
	}

	return CALL_ORIGINAL(rcx, pPlayer, vecAttachment, vecEndPos, flSize);
}

MAKE_HOOK(CBasePlayer_EyePosition, S::CBasePlayer_EyePosition(), Vec3*,
	void* rcx, void* rdx)
{
	DEBUG_RETURN(CBasePlayer_EyePosition, rcx, rdx);

	const auto dwRetAddr = uintptr_t(_ReturnAddress());
	const auto dwDesired = S::CSniperDot_GetRenderingPositions_EyePosition_Call();

	if (dwRetAddr == dwDesired)
		return &s_vEyePosition;

	return CALL_ORIGINAL(rcx, rdx);
}

MAKE_HOOK(CTFPlayer_EyeAngles, S::CTFPlayer_EyeAngles(), Vec3*,
	void* rcx)
{
	DEBUG_RETURN(CTFPlayer_EyeAngles, rcx);

	const auto dwRetAddr = uintptr_t(_ReturnAddress());
	const auto dwDesired = S::CSniperDot_GetRenderingPositions_EyeAngles_Call();

	if (dwRetAddr == dwDesired)
		return &s_vEyeAngles;

	return CALL_ORIGINAL(rcx);
}