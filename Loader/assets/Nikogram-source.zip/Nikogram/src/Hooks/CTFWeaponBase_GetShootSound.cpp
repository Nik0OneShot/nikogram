#include "../SDK/SDK.h"
#include "../Features/SkinChanger/SkinChanger.h"

MAKE_SIGNATURE(CTFWeaponBase_GetShootSound, "client.dll", "40 55 56 41 56 48 83 EC ? 80 B9", 0x0);

MAKE_HOOK(CTFWeaponBase_GetShootSound, S::CTFWeaponBase_GetShootSound(), const char*,
	void* rcx, int iIndex)
{
	DEBUG_RETURN(CTFWeaponBase_GetShootSound, rcx, iIndex);

	if (Vars::Misc::Sound::GiantWeaponSounds.Value)
	{
		auto pWeapon = H::Entities.GetWeapon();
		if (rcx == pWeapon)
		{	// credits: KGB
			int nOldTeam = pWeapon->m_iTeamNum();
			pWeapon->m_iTeamNum() = TF_TEAM_COUNT;
			auto sReturn = CALL_ORIGINAL(rcx, iIndex);
			pWeapon->m_iTeamNum() = nOldTeam;

			switch (FNV1A::Hash32(sReturn))
			{
			case FNV1A::Hash32Const("Weapon_FlameThrower.Fire"): return "MVM.GiantPyro_FlameStart";
			case FNV1A::Hash32Const("Weapon_FlameThrower.FireLoop"): return "MVM.GiantPyro_FlameLoop";
			case FNV1A::Hash32Const("Weapon_GrenadeLauncher.Single"): return "MVM.GiantDemoman_Grenadeshoot";
			}

			return sReturn;
		}
	}

    // Keep returned names stable across later calls, like native schema strings.
    // Names come only from the bounded installed catalog or native weapon script.
    static thread_local std::set<std::string> cosmeticSounds;
    auto cosmeticSound=SkinChanger::SoundFor(reinterpret_cast<CBaseCombatWeapon*>(rcx),iIndex);
    if(!cosmeticSound.empty())return cosmeticSounds.insert(std::move(cosmeticSound)).first->c_str();
    return CALL_ORIGINAL(rcx, iIndex);
}
