#pragma once
#include "../../../SDK/SDK.h"
#include "../AimbotAuditPolicy.h"

//#define DEBUG_VACCINATOR

class CAutoHeal
{
private:
	void AutoHeal(CUserCmd* pCmd);
	void ActivateOnVoice(CUserCmd* pCmd);
	void AutoVaccinator(CUserCmd* pCmd);
	void GetDangers(CTFPlayer* pTarget, bool bVaccinator, float& flBulletDanger, float& flBlastDanger, float& flFireDanger);
	void SwapResistType(CUserCmd* pCmd, int iType);
	void ActivateResistType(CUserCmd* pCmd, int iType);

	CTFPlayer* m_pLocal = nullptr;
	CWeaponMedigun* m_pWeapon = nullptr;
	int m_iWeaponHandle=0;

	int m_iResistType = -1;
	float m_flChargeLevel = 0.f;
	float m_flSwapTime = 0.f;
	bool m_bPreventResistSwap = false;
	bool m_bPreventResistCharge = false;

	std::array<AimbotAuditPolicy::DamageHistory,2> m_DamageHistory = {};

#ifdef DEBUG_VACCINATOR
	std::array<float, MEDIGUN_NUM_RESISTS> vResistDangers = {};
#endif

public:
	void Run(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd);
	void Event(IGameEvent* pEvent, uint32_t uHash);
#ifdef DEBUG_VACCINATOR
	void Draw(CTFPlayer* pLocal);
#endif

	std::unordered_mapset<int> m_mMedicCallers = {};
};

ADD_FEATURE(CAutoHeal, AutoHeal);
