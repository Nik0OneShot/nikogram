#pragma once
#include "../../../SDK/SDK.h"
#include "../../Backtrack/Backtrack.h"
#include "../TargetSwitchPolicy.h"

enum BOUNDS_HITBOXES
{
	BOUNDS_HEAD, BOUNDS_BODY, BOUNDS_FEET, BOUNDS_COUNT
};

Enum(Target, Unknown, Player, Sentry, Dispenser, Teleporter, Sticky, NPC, Bomb)
Enum(ShouldIgnore, None, Dormant = 1 << 0, Ignored = 1 << 1)

struct Target_t
{
	CBaseEntity* m_pEntity = nullptr;
	int m_iTargetType = TargetEnum::Unknown;
	Vec3 m_vPos = {};
	Vec3 m_vAngleTo = {};
	float m_flFOVTo = std::numeric_limits<float>::max();
	float m_flDistTo = std::numeric_limits<float>::max();
	int m_nPriority = 0;
	int m_nAimedHitbox = -1;

	TickRecord* m_pRecord = nullptr;
	bool m_bBacktrack = false;
};

class CAimbotGlobal
{
    TargetSwitchPolicy::State m_switch[2];
    bool m_switchSeen[2] = {};
    unsigned m_switchWeapon = 0;
    int m_switchStyle = -1;
    int m_switchContext = -1;
    float m_switchSettings[4] = {};
public:
    void BeginTargetSwitch(CTFPlayer* local, CTFWeaponBase* weapon, CUserCmd* cmd);
    bool AllowTargetSwitch(CBaseEntity* target);
    void EndTargetSwitch();
	std::vector<Target_t> ManageTargets(std::vector<Target_t>(*GetTargets)(CTFPlayer* pLocal, CTFWeaponBase* pWeapon), CTFPlayer* pLocal, CTFWeaponBase* pWeapon,
		int iMethod = Vars::Aimbot::General::TargetSelection.Value, int iMaxTargets = Vars::Aimbot::General::MaxTargets.Value);
	void SortTargetsPre(std::vector<Target_t>& vTargets, int iMethod);
	void SortTargetsPost(std::vector<Target_t>& vTargets, int iMethod);

	float GetAimFOV();
	float GetConfiguredAimFOV();
	int GetPlayerPriority(CTFPlayer* player, int base, EWeaponType type, bool allowBurning = true);
	bool CanDisplaceUber(CTFWeaponBase* weapon);
	bool IsUberTarget(CTFPlayer* player);
	bool EntityCenterInFOV(CBaseEntity* pTarget, const Vec3& vLocalPos, const Vec3& vLocalAngles, float& flFOVTo, Vec3& vPos, Vec3& vAngleTo);
	bool PlayerBoneInFOV(CTFPlayer* pTarget, const Vec3& vLocalPos, const Vec3& vLocalAngles, float& flFOVTo, Vec3& vPos, Vec3& vAngleTo, int iHitboxes = Vars::Aimbot::Hitscan::HitboxesEnum::Head | Vars::Aimbot::Hitscan::HitboxesEnum::Body | Vars::Aimbot::Hitscan::HitboxesEnum::Pelvis | Vars::Aimbot::Hitscan::HitboxesEnum::Arms | Vars::Aimbot::Hitscan::HitboxesEnum::Legs);
	bool IsHitboxValid(CBaseEntity* pEntity, int nHitbox, int iHitboxes = Vars::Aimbot::Hitscan::HitboxesEnum::Head | Vars::Aimbot::Hitscan::HitboxesEnum::Body | Vars::Aimbot::Hitscan::HitboxesEnum::Pelvis | Vars::Aimbot::Hitscan::HitboxesEnum::Arms | Vars::Aimbot::Hitscan::HitboxesEnum::Legs);
	bool IsHitboxValid(int nHitbox, int iHitboxes = Vars::Aimbot::Projectile::HitboxesEnum::Head | Vars::Aimbot::Projectile::HitboxesEnum::Body | Vars::Aimbot::Projectile::HitboxesEnum::Feet);
	bool ShouldMultipoint(CBaseEntity* pEntity = nullptr, int nHitbox = -1, int iHitboxes = Vars::Aimbot::Hitscan::HitboxesEnum::Head | Vars::Aimbot::Hitscan::HitboxesEnum::Body | Vars::Aimbot::Hitscan::HitboxesEnum::Pelvis | Vars::Aimbot::Hitscan::HitboxesEnum::Arms | Vars::Aimbot::Hitscan::HitboxesEnum::Legs);
	bool ShouldAimAtAngle(Vec3 vAngles);

	bool ShouldIgnore(CBaseEntity* pTarget, CTFPlayer* pLocal, CTFWeaponBase* pWeapon, int iFunctionFlags = ShouldIgnoreEnum::Dormant | ShouldIgnoreEnum::Ignored, int iTargetFlags = Vars::Aimbot::General::Target.Value, int iIgnoreFlags = Vars::Aimbot::General::Ignore.Value);
	int GetPriority(int iIndex);

	bool ShouldAim();
	bool ShouldHoldAttack(CTFWeaponBase* pWeapon);
	bool ValidBomb(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CBaseEntity* pBomb);
};

ADD_FEATURE(CAimbotGlobal, AimbotGlobal);
