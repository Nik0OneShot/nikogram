#include "AimbotHitscan.h"
#include "../SmoothAim.h"
#include "../AimRegionPolicy.h"
#include "HeadRecordPolicy.h"

static bool ConfirmRecordHead(CTFPlayer* local,CTFPlayer* player,const TickRecord* record,const Vec3& eye,const Vec3& direction,float range)
{
    auto set=player->GetHitboxSet();if(!set||!record)return false;
    HeadRecordPolicy::Nearest nearest(range);
    for(int index=0;index<set->numhitboxes;++index)
    {
        auto box=set->pHitbox(index);if(!box||box->bone<0||box->bone>=MAXSTUDIOBONES)continue;
        CursorBacktrackPolicy::Matrix bone{};
        for(int row=0;row<3;++row)for(int col=0;col<4;++col)bone[row][col]=record->m_aBones[box->bone][row][col];
        double distance;
        if(CursorBacktrackPolicy::HitDistance({eye.x,eye.y,eye.z},{direction.x,direction.y,direction.z},
            {box->bbmin.x,box->bbmin.y,box->bbmin.z},{box->bbmax.x,box->bbmax.y,box->bbmax.z},bone,range,distance))
            nearest.Consider(index,index==HITBOX_HEAD,distance);
    }
    if(nearest.hitbox!=HITBOX_HEAD)return false;
    class Filter:public CTraceFilterHitscan
    {
    public:CTFPlayer* target=nullptr;
        bool ShouldHitEntity(IHandleEntity* e,int mask)override
        {return reinterpret_cast<CBaseEntity*>(e)!=target&&CTraceFilterHitscan::ShouldHitEntity(e,mask);}
    } filter;
    filter.pSkip=local;filter.target=player;
    CGameTrace trace{};SDK::Trace(eye,eye+direction*float(nearest.distance),MASK_SHOT|CONTENTS_GRATE,&filter,&trace);
    return !trace.startsolid&&!trace.allsolid&&trace.fraction>=.9999f;
}

static bool RegionPoint(const Vec3& eye,const Vec3& view,const Vec3& mins,const Vec3& maxs,const matrix3x4& transform,Vec3& local,bool& inside,float& heightMiss)
{
    AimRegionPolicy::Box box;
    box.origin={transform[0][3],transform[1][3],transform[2][3]};
    box.mins={mins.x,mins.y,mins.z};box.maxs={maxs.x,maxs.y,maxs.z};
    for(int i=0;i<3;++i)box.axis[i]={transform[0][i],transform[1][i],transform[2][i]};
    Vec3 forward;Math::AngleVectors(view,&forward);
    AimRegionPolicy::Result result;
    if(!AimRegionPolicy::Nearest({eye.x,eye.y,eye.z},{forward.x,forward.y,forward.z},box,result,true))return false;
    std::array<AimRegionPolicy::V,3> rows;
    if(!AimRegionPolicy::Inverse(box,rows))return false;
    const auto point=AimRegionPolicy::Local(rows,AimRegionPolicy::Sub(result.point,box.origin));
    local={float(point[0]),float(point[1]),float(point[2])};inside=result.inside;heightMiss=float(result.heightMiss);return true;
}
#include "ServerEstimate.h"
#include "../AimbotAuditPolicy.h"

#include "../Aimbot.h"
#include "../../Ticks/Ticks.h"
#include "../../Resolver/Resolver.h"
#include "../../NoSpread/NoSpread.h"
#include "../../Simulation/MovementSimulation/MovementSimulation.h"
#include "../../Visuals/Visuals.h"
#include "../../AntiCheatCompatibility/AntiCheatCompatibility.h"

static inline std::vector<Target_t> GetTargets(CTFPlayer* pLocal, CTFWeaponBase* pWeapon)
{
	std::vector<Target_t> vTargets;

	Vec3 vLocalPos = F::Ticks.GetShootPos();
	Vec3 vLocalAngles = I::EngineClient->GetViewAngles();

	{
		auto eGroup = EntityEnum::Invalid;
		if (Vars::Aimbot::General::Target.Value & Vars::Aimbot::General::TargetEnum::Players)
		{
			eGroup = !SDK::FriendlyFire() || Vars::Aimbot::General::Ignore.Value & Vars::Aimbot::General::IgnoreEnum::Team ? EntityEnum::PlayerEnemy : EntityEnum::PlayerAll;
			if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::ExtinguishTeam &&
				!SDK::FriendlyFire() && SDK::AttribHookValue(0, "jarate_duration", pWeapon) > 0)
				eGroup = EntityEnum::PlayerAll;
		}
		if (pWeapon->GetWeaponID() == TF_WEAPON_MEDIGUN)
			eGroup = Vars::Aimbot::Healing::AutoHeal.Value ? EntityEnum::PlayerTeam : EntityEnum::Invalid;
		bool bHeal = pWeapon->GetWeaponID() == TF_WEAPON_MEDIGUN;

		for (auto pEntity : H::Entities.GetGroup(eGroup))
		{
			if (F::AimbotGlobal.ShouldIgnore(pEntity, pLocal, pWeapon))
				continue;

			bool bTeam = pEntity->m_iTeamNum() == pLocal->m_iTeamNum();
			if (bTeam)
			{
				if (bHeal)
				{
					if (pEntity->As<CTFPlayer>()->InCond(TF_COND_STEALTHED)
						|| Vars::Aimbot::Healing::HealPriority.Value == Vars::Aimbot::Healing::HealPriorityEnum::FriendsOnly
						&& !H::Entities.IsFriend(pEntity->entindex()) && !H::Entities.InParty(pEntity->entindex()))
						continue;
				}
				if (!SDK::FriendlyFire() && SDK::AttribHookValue(0, "jarate_duration", pWeapon) > 0)
				{
					if (!pEntity->As<CTFPlayer>()->InCond(TF_COND_BURNING))
						continue;
				}
			}

			float flFOVTo; Vec3 vPos, vAngleTo;
			if (!F::AimbotGlobal.PlayerBoneInFOV(pEntity->As<CTFPlayer>(), vLocalPos, vLocalAngles, flFOVTo, vPos, vAngleTo, Vars::Aimbot::Hitscan::Hitboxes.Value))
				continue;

			float flDistTo = vLocalPos.DistToSqr(vPos);
			int iPriority = F::AimbotGlobal.GetPriority(pEntity->entindex());
			if (bTeam && bHeal)
			{
				iPriority = 0;
				switch (Vars::Aimbot::Healing::HealPriority.Value)
				{
				case Vars::Aimbot::Healing::HealPriorityEnum::PrioritizeFriends:
					if (H::Entities.IsFriend(pEntity->entindex()) || H::Entities.InParty(pEntity->entindex()))
						iPriority = std::numeric_limits<int>::max();
					break;
				case Vars::Aimbot::Healing::HealPriorityEnum::PrioritizeTeam:
					iPriority = std::numeric_limits<int>::max();
				}
			}
			iPriority=F::AimbotGlobal.GetPlayerPriority(pEntity->As<CTFPlayer>(),iPriority,EWeaponType::HITSCAN);
			vTargets.emplace_back(pEntity, TargetEnum::Player, vPos, vAngleTo, flFOVTo, flDistTo, iPriority);
		}

		if (pWeapon->GetWeaponID() == TF_WEAPON_MEDIGUN)
			return vTargets;
	}

	if (Vars::Aimbot::General::Target.Value & Vars::Aimbot::General::TargetEnum::Building)
	{
		for (auto pEntity : H::Entities.GetGroup(EntityEnum::BuildingEnemy))
		{
			if (F::AimbotGlobal.ShouldIgnore(pEntity, pLocal, pWeapon))
				continue;

			float flFOVTo; Vec3 vPos, vAngleTo;
			if (!F::AimbotGlobal.EntityCenterInFOV(pEntity, vLocalPos, vLocalAngles, flFOVTo, vPos, vAngleTo))
				continue;

			float flDistTo = vLocalPos.DistToSqr(vPos);
			vTargets.emplace_back(pEntity, pEntity->IsSentrygun() ? TargetEnum::Sentry : pEntity->IsDispenser() ? TargetEnum::Dispenser : TargetEnum::Teleporter, vPos, vAngleTo, flFOVTo, flDistTo);
		}
	}

	if (Vars::Aimbot::General::Target.Value & Vars::Aimbot::General::TargetEnum::Stickies)
	{
		for (auto pEntity : H::Entities.GetGroup(EntityEnum::WorldProjectile))
		{
			if (F::AimbotGlobal.ShouldIgnore(pEntity, pLocal, pWeapon))
				continue;

			float flFOVTo; Vec3 vPos, vAngleTo;
			if (!F::AimbotGlobal.EntityCenterInFOV(pEntity, vLocalPos, vLocalAngles, flFOVTo, vPos, vAngleTo))
				continue;

			float flDistTo = vLocalPos.DistToSqr(vPos);
			vTargets.emplace_back(pEntity, TargetEnum::Sticky, vPos, vAngleTo, flFOVTo, flDistTo);
		}
	}

	if (Vars::Aimbot::General::Target.Value & Vars::Aimbot::General::TargetEnum::NPCs)
	{
		for (auto pEntity : H::Entities.GetGroup(EntityEnum::WorldNPC))
		{
			if (F::AimbotGlobal.ShouldIgnore(pEntity, pLocal, pWeapon))
				continue;

			float flFOVTo; Vec3 vPos, vAngleTo;
			if (!F::AimbotGlobal.EntityCenterInFOV(pEntity, vLocalPos, vLocalAngles, flFOVTo, vPos, vAngleTo))
				continue;

			float flDistTo = vLocalPos.DistToSqr(vPos);
			vTargets.emplace_back(pEntity, TargetEnum::NPC, vPos, vAngleTo, flFOVTo, flDistTo);
		}
	}

	if (Vars::Aimbot::General::Target.Value & Vars::Aimbot::General::TargetEnum::Bombs)
	{
		for (auto pEntity : H::Entities.GetGroup(EntityEnum::WorldBomb))
		{
			if (F::AimbotGlobal.ShouldIgnore(pEntity, pLocal, pWeapon))
				continue;

			float flFOVTo; Vec3 vPos, vAngleTo;
			if (!F::AimbotGlobal.EntityCenterInFOV(pEntity, vLocalPos, vLocalAngles, flFOVTo, vPos, vAngleTo))
				continue;

			float flDistTo = vLocalPos.DistToSqr(vPos);
			vTargets.emplace_back(pEntity, TargetEnum::Bomb, vPos, vAngleTo, flFOVTo, flDistTo);
		}
	}

	return vTargets;
}



std::vector<HitscanHitbox_t> CAimbotHitscan::GetHitboxes(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CBaseEntity* pTarget)
{
	std::vector<HitscanHitbox_t> vHitboxes = {};

	if (pWeapon->GetWeaponID() == TF_WEAPON_LASER_POINTER)
	{
		CObjectSentrygun* pSentry = nullptr;
		for (auto pEntity : H::Entities.GetGroup(EntityEnum::BuildingTeam))
		{
			if (pEntity->IsSentrygun() && pEntity->As<CBaseObject>()->m_hBuilder().GetEntryIndex() == I::EngineClient->GetLocalPlayer())
			{
				pSentry = pEntity->As<CObjectSentrygun>();
				break;
			}
		}
		if (!pSentry)
			return vHitboxes;

		Vec3 vOrigin = pTarget->m_vecOrigin();
		{
			MoveStorage tMoveStorage; // run movesim based on ping
			F::MoveSim.Initialize(pTarget, tMoveStorage);
			if (!tMoveStorage.m_bFailed)
			{
				for (int i = 1 - TIME_TO_TICKS(F::Backtrack.GetReal()); i <= 0; i++)
				{
					F::MoveSim.RunTick(tMoveStorage);
					vOrigin = tMoveStorage.m_vPredictedOrigin;
				}
			}
			F::MoveSim.Restore(tMoveStorage);
		}
		if (!SDK::VisPosWorld(nullptr, pTarget, pSentry->m_vecOrigin() + pSentry->GetOffset() / 2 * pSentry->m_flModelScale(), vOrigin + pTarget->GetOffset() / 2))
			return vHitboxes;

		vHitboxes.emplace_back(nullptr, vOrigin);
		return vHitboxes;
	}

	if (!pTarget->IsPlayer())
	{
		vHitboxes.emplace_back();
		return vHitboxes;
	}

	if (auto pSet = pTarget->As<CBaseAnimating>()->GetHitboxSet())
	{
		std::vector<std::tuple<const mstudiobbox_t*, int, int>> vBones;
		for (int nHitbox = 0; nHitbox < pSet->numhitboxes; nHitbox++)
		{
			int iPriority = GetHitboxPriority(nHitbox, pLocal, pWeapon, pTarget);
			if (iPriority == -1)
				continue;

			auto pBox = pSet->pHitbox(nHitbox);
			if (!pBox)
				continue;

			vBones.emplace_back(pBox, nHitbox, iPriority);
		}
		std::sort(vBones.begin(), vBones.end(), [&](const auto& a, const auto& b) -> bool
		{
			return std::get<2>(a) < std::get<2>(b);
		});
		vHitboxes.reserve(vBones.size());
		for (auto& [pBox, nHitbox, _] : vBones)
			vHitboxes.emplace_back(pBox, std::nullopt, nHitbox);
	}

	return vHitboxes;
}

int CAimbotHitscan::GetHitboxPriority(int nHitbox, CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CBaseEntity* pTarget)
{
	if (!F::AimbotGlobal.IsHitboxValid(pTarget, nHitbox, Vars::Aimbot::Hitscan::Hitboxes.Value))
		return -1;

	bool bHeadshot = false;
	switch (pWeapon->GetWeaponID())
	{
	case TF_WEAPON_SNIPERRIFLE:
	case TF_WEAPON_SNIPERRIFLE_DECAP:
	case TF_WEAPON_SNIPERRIFLE_CLASSIC:
	{
		auto pSniperRifle = pWeapon->As<CTFSniperRifle>();

		if (G::CanHeadshot
			|| pLocal->InCond(TF_COND_AIMING) && (pSniperRifle->GetRifleType() == RIFLE_JARATE && SDK::AttribHookValue(0, "jarate_duration", pWeapon) > 0 || Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::WaitForHeadshot))
			bHeadshot = true;
		break;
	}
	case TF_WEAPON_REVOLVER:
	{
		if (SDK::AttribHookValue(0, "set_weapon_mode", pWeapon) == 1 && (pWeapon->AmbassadorCanHeadshot() || Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::WaitForHeadshot))
			bHeadshot = true;
	}
	}

	if (Vars::Aimbot::Hitscan::Hitboxes.Value & Vars::Aimbot::Hitscan::HitboxesEnum::BodyaimIfLethal && bHeadshot)
	{
		auto pPlayer = pTarget->As<CTFPlayer>();

		switch (pWeapon->GetWeaponID())
		{
		case TF_WEAPON_SNIPERRIFLE:
		case TF_WEAPON_SNIPERRIFLE_DECAP:
		case TF_WEAPON_SNIPERRIFLE_CLASSIC:
		{
			auto pSniperRifle = pWeapon->As<CTFSniperRifle>();

			int iDamage = ceilf(std::max(pSniperRifle->m_flChargedDamage(), 50.f) * pSniperRifle->GetBodyshotMult(pPlayer));
			if (pPlayer->m_iHealth() <= iDamage)
				bHeadshot = false;
			break;
		}
		case TF_WEAPON_REVOLVER:
		{
			if (SDK::AttribHookValue(0, "set_weapon_mode", pWeapon) == 1)
			{
				float flDistTo = pTarget->m_vecOrigin().DistTo(pLocal->m_vecOrigin());

				float flMult = SDK::AttribHookValue(1, "mult_dmg", pWeapon);
				int iDamage = ceilf(Math::RemapVal(flDistTo, 90.f, 900.f, 60.f, 21.f) * flMult);
				if (pPlayer->m_iHealth() <= iDamage)
					bHeadshot = false;
			}
		}
		}
	}
	
	bool bHeadOnly = bHeadshot && Vars::Aimbot::Hitscan::Hitboxes.Value & Vars::Aimbot::Hitscan::HitboxesEnum::HeadshotOnly;

	int iHeadPriority = bHeadshot ? 0 : 1;
	int iBodyPriority = bHeadOnly ? -1 : bHeadshot ? 1 : 0;
	int iMiscPriority = bHeadOnly ? -1 : 2;
	int iLimbPriority = bHeadOnly ? -1 : 3;

	switch (pTarget->GetHitboxToBase(nHitbox))
	{
	case HITBOX_HEAD: return iHeadPriority;
	case HITBOX_SPINE0:
	case HITBOX_SPINE1:
	case HITBOX_SPINE2:
	case HITBOX_SPINE3: return iBodyPriority;
	case HITBOX_PELVIS: return iMiscPriority;
	}

	return iLimbPriority;
};

void CAimbotHitscan::GetHitboxInfo(HitscanHitbox_t& tHitbox, CBaseEntity* pTarget, matrix3x4* aBones, const matrix3x4** pTransform, Vec3* pMins, Vec3* pMaxs)
{
	if (pMins && pMaxs)
	{
		if (tHitbox.m_pBox)
		{
			*pMins = tHitbox.m_pBox->bbmin;
			*pMaxs = tHitbox.m_pBox->bbmax;
		}
		else if (pTarget)
		{
			*pMins = pTarget->m_vecMins();
			*pMaxs = pTarget->m_vecMaxs();
		}
	}

	if (pTransform)
	{
		if (aBones && tHitbox.m_pBox)
			*pTransform = &aBones[tHitbox.m_pBox->bone];
		else if (tHitbox.m_vPos)
			*pTransform = &m_mMatrix, Math::MatrixInitialize(m_mMatrix, *tHitbox.m_vPos, false);
		else if (pTarget)
			*pTransform = &pTarget->m_Collision()->CollisionToWorldTransform();
	}
}

void CAimbotHitscan::GetHullInfo(CBaseEntity* pTarget, TickRecord* pRecord, const matrix3x4** pTransform, Vec3* pMins, Vec3* pMaxs, float* pModelScale)
{
	if (!pTarget->IsPlayer())
		return; // only really important for player targets to check that our trace will be in the bbox

	if (pModelScale)
		*pModelScale = pTarget->As<CBaseAnimating>()->m_flModelScale();

	if (pMins && pMaxs)
	{
		float flModelScale = pModelScale ? *pModelScale : 1.f;
		auto pGameRules = I::TFGameRules();
		auto pViewVectors = pGameRules ? pGameRules->GetViewVectors() : nullptr;
		*pMins = (pViewVectors ? pViewVectors->m_vHullMin : Vec3(-24, -24, 0)) * flModelScale;
		*pMaxs = (pViewVectors ? pViewVectors->m_vHullMax : Vec3(24, 24, 82)) * flModelScale;
	}

	if (pTransform && pRecord)
		*pTransform = &m_mHullMatrix, Math::MatrixInitialize(m_mHullMatrix, pRecord->m_vOrigin, false);
}

void CAimbotHitscan::GetHitboxPoints(std::vector<Vec3>& vPoints, CBaseEntity* pTarget, CTFWeaponBase* pWeapon, const Vec3& vMins, const Vec3& vMaxs, int nHitbox)
{	// output vector is reused by the caller to avoid allocating per hitbox
	vPoints = { Vec3() };

	bool bPlayer = pTarget->IsPlayer();
	if (bPlayer && !F::AimbotGlobal.ShouldMultipoint(pTarget, nHitbox, Vars::Aimbot::Hitscan::MultipointHitboxes.Value)
		|| pWeapon->GetWeaponID() == TF_WEAPON_LASER_POINTER)
		return;

	switch (Vars::Aimbot::General::AimType.Value)
	{
	case Vars::Aimbot::General::AimTypeEnum::Smooth:
	case Vars::Aimbot::General::AimTypeEnum::Assistive:
		if (!Vars::Aimbot::General::AssistStrength.Value && !SmoothAim::Combined() && (Vars::Aimbot::General::AimType.Value != Vars::Aimbot::General::AimTypeEnum::Smooth || Vars::Aimbot::General::SmoothFormula.Value == Vars::Aimbot::General::SmoothFormulaEnum::Default))
			return; // triggerbot
	}

	float flScale = !bPlayer ? 0.5f : Vars::Aimbot::Hitscan::MultipointScale.Value / 100;
	Vec3 vMinsS = (vMins - vMaxs) / 2 * flScale;
	Vec3 vMaxsS = (vMaxs - vMins) / 2 * flScale;

	vPoints = {
		Vec3(),
		Vec3(vMinsS.x, vMinsS.y, vMaxsS.z),
		Vec3(vMaxsS.x, vMinsS.y, vMaxsS.z),
		Vec3(vMinsS.x, vMaxsS.y, vMaxsS.z),
		Vec3(vMaxsS.x, vMaxsS.y, vMaxsS.z),
		Vec3(vMinsS.x, vMinsS.y, vMinsS.z),
		Vec3(vMaxsS.x, vMinsS.y, vMinsS.z),
		Vec3(vMinsS.x, vMaxsS.y, vMinsS.z),
		Vec3(vMaxsS.x, vMaxsS.y, vMinsS.z)
	};
}

bool CAimbotHitscan::BuildServerEstimate(CBaseEntity* pTarget, const std::vector<TickRecord*>& records)
{
	if (!Vars::Aimbot::Hitscan::Extrapolation.Value || records.size() < 2 || pTarget->IsDormant())
		return false;
	const auto& latest = *records[0];
	const auto& previous = *records[1];
	if (latest.m_bInvalid || previous.m_bInvalid)
		return false;
	const float scale = ServerEstimate::SampleScale(TICKS_TO_TIME(F::Backtrack.m_iTickCount),
		latest.m_flSimTime, previous.m_flSimTime, Vars::Aimbot::Hitscan::ExtrapolationRange.Value);
	if (scale <= 0.f)
		return false;
	const auto finite = [](const Vec3& v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); };
	const Vec3 sample = latest.m_vOrigin - previous.m_vOrigin;
	Vec3 offset = sample * scale;
	// Reject discontinuities and implausible displacement rather than amplifying them.
	if (!finite(latest.m_vOrigin) || !finite(sample) || !finite(offset)
		|| sample.LengthSqr() > 64.f * 64.f || offset.LengthSqr() > 64.f * 64.f
		|| offset.LengthSqr() < 0.0001f)
		return false;
	// Network record bounds already include crouch and model scale. A standing
	// hull here rejects valid crouched motion underneath low geometry.
	const Vec3 mins=latest.m_vMins,maxs=latest.m_vMaxs;
	if(!AimbotAuditPolicy::Bounds({mins.x,mins.y,mins.z},{maxs.x,maxs.y,maxs.z})) return false;
	CTraceFilterWorldAndPropsOnly filter = {};
	filter.pSkip = pTarget;
	CGameTrace trace = {};
	SDK::TraceHull(latest.m_vOrigin, latest.m_vOrigin + offset, mins, maxs, MASK_PLAYERSOLID, &filter, &trace);
	if (trace.startsolid || trace.allsolid || !std::isfinite(trace.fraction))
		return false;
	offset *= std::clamp(trace.fraction, 0.f, 1.f);
	if (offset.LengthSqr() < 0.0001f)
		return false;
	m_tServerEstimate = latest;
	m_vEstimateOffset = offset;
	m_flEstimateSeconds = scale * (latest.m_flSimTime - previous.m_flSimTime) * std::clamp(trace.fraction, 0.f, 1.f);
	m_tServerEstimate.m_vOrigin += offset;
	for (auto& bone : m_tServerEstimate.m_aBones)
	{
		bone[0][3] += offset.x;
		bone[1][3] += offset.y;
		bone[2][3] += offset.z;
	}
	// Keep the real sample timestamp; Run must never use this as a backtrack record.
	return true;
}

int CAimbotHitscan::CanHit(Target_t& tTarget, CTFPlayer* pLocal, CTFWeaponBase* pWeapon)
{
    SmoothAim::CandidateScope smoothing(tTarget.m_pEntity,true);
	if (Vars::Aimbot::General::Ignore.Value & Vars::Aimbot::General::IgnoreEnum::Unsimulated && H::Entities.GetChoke(tTarget.m_pEntity->entindex()) > Vars::Aimbot::General::TickTolerance.Value)
		return false;

	m_vEyePos = pLocal->GetShootPos();
	float flMaxRangeSqr = powf(pWeapon->GetRange(), 2.f);
	bool bPlayer = tTarget.m_pEntity->IsPlayer();
	bool bWrangler = pWeapon->GetWeaponID() == TF_WEAPON_LASER_POINTER;
	bool bServerEstimate = false;

	std::vector<TickRecord*> vRecords = {};
	if (F::Backtrack.GetRecords(tTarget.m_pEntity, vRecords) && !bWrangler)
	{
		bServerEstimate = bPlayer && pWeapon->GetWeaponID() != TF_WEAPON_MEDIGUN
			&& BuildServerEstimate(tTarget.m_pEntity, vRecords);
		vRecords = bServerEstimate ? std::vector<TickRecord*>{ &m_tServerEstimate }
			: F::Backtrack.GetValidRecords(vRecords, pLocal);
		if (vRecords.empty())
			return false;
	}
	else
	{
		// A rendered/cached pose is not a server-valid record. Wait for the
		// next network sample rather than shooting players using screen bones.
		if (bPlayer && !bWrangler && pWeapon->GetWeaponID()!=TF_WEAPON_MEDIGUN)
			return false;
		F::Backtrack.m_tRecord = { tTarget.m_pEntity->m_flSimulationTime(), tTarget.m_pEntity->m_vecOrigin(), Vec3(), Vec3() };
		if (!tTarget.m_pEntity->SetupBones(F::Backtrack.m_tRecord.m_aBones, MAXSTUDIOBONES, BONE_USED_BY_ANYTHING, tTarget.m_pEntity->m_flSimulationTime()))
			return false;

		vRecords = { &F::Backtrack.m_tRecord };
	}

	auto vHitboxes = GetHitboxes(pLocal, pWeapon, tTarget.m_pEntity);
	if (vHitboxes.empty())
		return false;

	int iReturn = false;
	// Region is opt-in, Legit-only, and does not change held-shot angles or
	// Wrangler's remote sentry destination. Every candidate still runs the
	// original range, visibility, hull, hitbox and firing checks below.
	const bool bRegion=SmoothAim::Region()&&!F::Ticks.GetShootAngle()&&!bWrangler;
	const bool bAssist=bRegion&&bPlayer&&SmoothAim::HitboxAssistance()&&SmoothAim::controller.WantsAssist()
		&&pWeapon->GetWeaponID()!=TF_WEAPON_MEDIGUN;
	const Vec3 vRegionView=G::OriginalCmd.viewangles+pLocal->m_vecPunchAngle();
	float flBestAimOnly=std::numeric_limits<float>::max();
	float flBestAimOnlyHeight=std::numeric_limits<float>::max();
	Vec3 vAimOnly;

	std::optional<Vec3> vPeekPos = std::nullopt;
	if (Vars::Aimbot::Hitscan::PeekAmount.Value && pWeapon->GetWeaponSpread())
	{
		switch (Vars::Aimbot::Hitscan::PeekCheck.Value)
		{
		case Vars::Aimbot::Hitscan::PeekCheckEnum::DoubletapOnly:
			if (!F::Ticks.GetTicks(pWeapon))
				break;
			[[fallthrough]];
		case Vars::Aimbot::Hitscan::PeekCheckEnum::Always:
			vPeekPos = m_vEyePos - pLocal->m_vecVelocity() * TICKS_TO_TIME(Vars::Aimbot::Hitscan::PeekAmount.Value);
		}
	}

	// if we're doubletapping, we can't change viewangles so work around that
	static int iTargetBone = 0;
	Vec3* pHoldAngle = F::Ticks.GetShootAngle(); if (pHoldAngle && bPlayer && vRecords.size() > 1)
	{
		Vec3 vHoldAngle = *pHoldAngle - F::NoSpread.GetOffset();
		std::sort(vRecords.begin(), vRecords.end(), [&](const TickRecord* a, const TickRecord* b) -> bool
		{
			Vec3 vPosA = { a->m_aBones[iTargetBone][0][3], a->m_aBones[iTargetBone][1][3], a->m_aBones[iTargetBone][2][3] };
			Vec3 vPosB = { b->m_aBones[iTargetBone][0][3], b->m_aBones[iTargetBone][1][3], b->m_aBones[iTargetBone][2][3] };
			Vec3 vAnglesA = Math::CalcAngle(m_vEyePos, vPosA);
			Vec3 vAnglesB = Math::CalcAngle(m_vEyePos, vPosB);
			return vHoldAngle.DeltaAngle(vAnglesA).Length2DSqr() < vHoldAngle.DeltaAngle(vAnglesB).Length2DSqr();
		});
	}

	float flBoneScale = std::max(Vars::Aimbot::Hitscan::BoneSizeMinimumScale.Value, Vars::Aimbot::Hitscan::MultipointScale.Value / 100.f);
	float flBoneSubtract = Vars::Aimbot::Hitscan::BoneSizeSubtract.Value;
	float flModelScale = 1.f;
	Vec3 vMins, vMaxs, vHullMins, vHullMaxs;
	const matrix3x4* pTransform = &m_mMatrix, *pHullTransform = nullptr;

	GetHullInfo(tTarget.m_pEntity, nullptr, nullptr, &vHullMins, &vHullMaxs, &flModelScale);
	std::vector<Vec3> vPoints = {};
	for (auto pRecord : vRecords)
	{
		std::optional<Target_t> regionHit;
		float flBestRegionHit=std::numeric_limits<float>::max();
		float flBestRegionHeight=std::numeric_limits<float>::max();
		bool bRecordAimOnly=false;
		if(bRegion){flBestAimOnly=flBestAimOnlyHeight=std::numeric_limits<float>::max();iReturn=false;}
		int iRegionBone=0;
		bool bRunPeekCheck = vPeekPos.has_value();
		auto aBones = pRecord->m_aBones;

		GetHullInfo(tTarget.m_pEntity, bPlayer && !bWrangler ? pRecord : nullptr, &pHullTransform);
		SmoothPolicy::AssistChoice assist;
		if(bAssist)
		{
			// Only already-enabled hitboxes enter this pass. Smooth keeps its
			// original region destination; Assistive has its own visible region.
			for(auto& hitbox:vHitboxes)
			{
				Vec3 mins,maxs,nearest;const matrix3x4* transform=nullptr;bool inside=false;float height=0.f;
				GetHitboxInfo(hitbox,tTarget.m_pEntity,aBones,&transform,&mins,&maxs);
				if(!transform||!RegionPoint(m_vEyePos,vRegionView,(mins+flBoneSubtract/flModelScale)*flBoneScale,
					(maxs-flBoneSubtract/flModelScale)*flBoneScale,*transform,nearest,inside,height))continue;
				Vec3 point;Math::VectorTransform(nearest,*transform,point);
				if(m_vEyePos.DistToSqr(point)>flMaxRangeSqr
					||!SDK::VisPos(pLocal,tTarget.m_pEntity,m_vEyePos,point)
					||(bServerEstimate&&!SDK::VisPosWorld(pLocal,nullptr,m_vEyePos,point)))continue;
				const Vec3 goal=inside?vRegionView:Math::CalcAngle(m_vEyePos,point);
				const float score=goal.DeltaAngle(vRegionView).Length2DSqr();
				const Vec3 cameraGoal=goal-pLocal->m_vecPunchAngle();
				if(!F::AimbotGlobal.ShouldAimAtAngle(cameraGoal))continue;
				assist.Consider({cameraGoal.x,cameraGoal.y},score,hitbox.m_iHitbox==HITBOX_HEAD,
					Vars::Aimbot::General::AssistHitbox.Value==Vars::Aimbot::General::AssistHitboxEnum::Head,height);
			}
		}
		SmoothAim::GuideScope guide(assist); // restored for every record/target/secondary path
		for (auto& tHitbox : vHitboxes)
		{
			GetHitboxInfo(tHitbox, tTarget.m_pEntity, aBones, &pTransform, &vMins, &vMaxs);
			Vec3 vCheckMins = (vMins + flBoneSubtract / flModelScale) * flBoneScale;
			Vec3 vCheckMaxs = (vMaxs - flBoneSubtract / flModelScale) * flBoneScale;
			Vec3 vOrigin; Math::VectorTransform({}, *pTransform, vOrigin);
			Vec3 vCenter; Math::VectorTransform((vMins + vMaxs) / 2, *pTransform, vCenter);
			Vec3 vOffset = vCenter - vOrigin;

			GetHitboxPoints(vPoints, tTarget.m_pEntity, pWeapon, vMins, vMaxs, tHitbox.m_iHitbox);
			bool bRegionInside=false;
			float flHeightMiss=std::numeric_limits<float>::max();
			if(bRegion)
			{
				Vec3 nearest;
				if(RegionPoint(m_vEyePos,vRegionView,vCheckMins,vCheckMaxs,*pTransform,nearest,bRegionInside,flHeightMiss))
				{
					// Points in this list are offsets from the hitbox's centre.
					const Vec3 local=nearest-(vMins+vMaxs)*.5f;
					vPoints.insert(vPoints.begin(),local);
				}
			}
			for (auto& vPoint : vPoints)
			{
				Math::VectorTransform(vPoint, *pTransform, vOrigin); vOrigin += vOffset;
				if (m_vEyePos.DistToSqr(vOrigin) > flMaxRangeSqr)
					continue;
				// The old entity pose must not hide an obstacle in front of the estimate.
				if (bServerEstimate && !SDK::VisPosWorld(pLocal, nullptr, m_vEyePos, vOrigin))
					continue;

				if (bRunPeekCheck)
				{
					bRunPeekCheck = false;
					if (!SDK::VisPos(pLocal, tTarget.m_pEntity, *vPeekPos, vOrigin))
						goto skip; // if we can't hit our primary hitbox, don't bother
				}

				const bool bPreserve=bRegionInside && &vPoint==vPoints.data();
				const Vec3 vGoal=bPreserve?vRegionView:Math::CalcAngle(m_vEyePos,vOrigin);
				const float flRegionScore=vGoal.DeltaAngle(vRegionView).Length2DSqr();
				// Restrict the unsmoothed destination, not the tiny per-command step.
				if(SmoothAim::VisibleGuidance()&&!F::AimbotGlobal.ShouldAimAtAngle(vGoal-pLocal->m_vecPunchAngle()))continue;
				// Region destination is first in the list; fallback multipoints are
				// ranked by their own projected vertical distance, not its row score.
				const float height=bRegion && &vPoint==vPoints.data() && flHeightMiss!=std::numeric_limits<float>::max()
					?flHeightMiss:std::abs(std::tan(Math::Deg2Rad(vGoal.x-vRegionView.x)));
				Vec3 vAngles; bool bChanged = Aim(G::CurrentUserCmd->viewangles, vGoal, vAngles);
				if(bPreserve&&!assist.valid)vAngles=G::CurrentUserCmd->viewangles; // Assistive may refine a different hitbox
				if (pHoldAngle) vAngles -= F::NoSpread.GetOffset(); // hold angle recorded with nospread, correct it
				if (!F::AimbotGlobal.ShouldAimAtAngle(vAngles) || !bChanged && !SDK::VisPos(pLocal, tTarget.m_pEntity, m_vEyePos, vOrigin))
					continue;

				// for the time being, no vischecks against other hitboxes
				Vec3 vForward; Math::AngleVectors(bRegion?vAngles+pLocal->m_vecPunchAngle():vAngles, &vForward);
				if ((!bChanged || Math::RayToOBB(m_vEyePos, vForward, vCheckMins, vCheckMaxs, *pTransform, flModelScale) && SDK::VisPos(pLocal, tTarget.m_pEntity, m_vEyePos, m_vEyePos + vForward * m_vEyePos.DistTo(vOrigin)))
					&& (!pHullTransform || Math::RayToOBB(m_vEyePos, vForward, vHullMins, vHullMaxs, *pHullTransform)))
				{
					if(bRegion&&!SmoothPolicy::PlacementBetter(height,flRegionScore,flBestRegionHeight,flBestRegionHit))continue;
                    if(bPlayer&&!bWrangler&&!bServerEstimate&&tHitbox.m_iHitbox==HITBOX_HEAD)
                    {
                        Vec3 shot;Math::AngleVectors(vAngles+pLocal->m_vecPunchAngle(),&shot);
                        if(!ConfirmRecordHead(pLocal,tTarget.m_pEntity->As<CTFPlayer>(),pRecord,m_vEyePos,shot,pWeapon->GetRange()))continue;
                    }
					tTarget.m_vAngleTo = vAngles;
					tTarget.m_pRecord = pRecord;
					tTarget.m_vPos = vOrigin;
					if (bServerEstimate && Vars::Aimbot::Hitscan::ExtrapolationGuide.Value && !F::Aimbot.m_bRunningSecondary)
						G::ExtrapolationGuide = { vOrigin - m_vEstimateOffset, vOrigin, m_flEstimateSeconds, I::GlobalVars->tickcount,
							tTarget.m_pEntity->As<IHandleEntity>()->GetRefEHandle(), tHitbox.m_pBox ? tHitbox.m_iHitbox : -1 };
					if (tHitbox.m_pBox)
					{
						tTarget.m_bBacktrack = !bServerEstimate;
						tTarget.m_nAimedHitbox = tHitbox.m_iHitbox;
						iTargetBone = tHitbox.m_pBox->bone;
					}
					if(!bRegion||flRegionScore<.00000001f)return true;
					// Compare across eligible hitboxes: an already valid body aim
					// must not be recentered toward an earlier head candidate.
					regionHit=tTarget;flBestRegionHit=flRegionScore;flBestRegionHeight=height;
					if(tHitbox.m_pBox)iRegionBone=tHitbox.m_pBox->bone;
				}
				else if (bChanged && SDK::VisPos(pLocal, tTarget.m_pEntity, m_vEyePos, vOrigin))
				{
					if(bRegion)
					{
						if(SmoothPolicy::PlacementBetter(height,flRegionScore,flBestAimOnlyHeight,flBestAimOnly))
						{flBestAimOnly=flRegionScore;flBestAimOnlyHeight=height;vAimOnly=vAngles;bRecordAimOnly=true;}
					}
					else if (iReturn != 2 || vAngles.DeltaAngle(G::CurrentUserCmd->viewangles).Length2DSqr() < tTarget.m_vAngleTo.DeltaAngle(G::CurrentUserCmd->viewangles).Length2DSqr())
						tTarget.m_vAngleTo = vAngles;
					iReturn = 2;
				}
			}
		}
		// An incidental body hit must not outrank a better head-level destination
		// just because smoothing has not reached that destination yet.
		if(bRegion&&bRecordAimOnly&&(!regionHit||SmoothPolicy::PlacementBetter(flBestAimOnlyHeight,flBestAimOnly,flBestRegionHeight,flBestRegionHit)))
		{tTarget.m_vAngleTo=vAimOnly;return 2;}
		if(regionHit)
		{
			tTarget=*regionHit;iTargetBone=iRegionBone;
			return true; // keep the existing preferred-record order
		}

		skip: if(bRegion)iReturn=false;continue;
	}

	if(bRegion&&iReturn==2)tTarget.m_vAngleTo=vAimOnly;
	return iReturn;
}



bool CAimbotHitscan::ShouldFire(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd, const Target_t& tTarget)
{
	if (!Vars::Aimbot::General::AutoShoot.Value)
		return false;

	if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::WaitForHeadshot
		&& tTarget.m_pEntity->IsPlayer())
	{
		switch (pWeapon->GetWeaponID())
		{
		case TF_WEAPON_SNIPERRIFLE:
		case TF_WEAPON_SNIPERRIFLE_DECAP:
			if (!G::CanHeadshot && pLocal->InCond(TF_COND_AIMING) && pWeapon->As<CTFSniperRifle>()->GetRifleType() != RIFLE_JARATE)
				return false;
			break;
		case TF_WEAPON_SNIPERRIFLE_CLASSIC:
			if (!G::CanHeadshot)
				return false;
			break;
		case TF_WEAPON_REVOLVER:
			if (SDK::AttribHookValue(0, "set_weapon_mode", pWeapon) == 1 && !pWeapon->AmbassadorCanHeadshot())
				return false;
		}
	}

	if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::WaitForCharge)
	{
		switch (pWeapon->GetWeaponID())
		{
		case TF_WEAPON_SNIPERRIFLE:
		case TF_WEAPON_SNIPERRIFLE_DECAP:
		case TF_WEAPON_SNIPERRIFLE_CLASSIC:
		{
			auto pSniperRifle = pWeapon->As<CTFSniperRifle>();
			if (!pLocal->InCond(TF_COND_AIMING) || pSniperRifle->m_flChargedDamage() == 150.f)
				break;

			if (tTarget.m_pEntity->IsPlayer())
			{
				auto pPlayer = tTarget.m_pEntity->As<CTFPlayer>();
				if (tTarget.m_nAimedHitbox == HITBOX_HEAD && (pWeapon->GetWeaponID() != TF_WEAPON_SNIPERRIFLE_CLASSIC || pSniperRifle->m_flChargedDamage() == 150.f))
				{
					int iDamage = ceilf(std::max(pSniperRifle->m_flChargedDamage(), 50.f) * pSniperRifle->GetHeadshotMult(pPlayer));
					if (pPlayer->m_iHealth() <= iDamage && (G::CanHeadshot || pLocal->IsCritBoosted()))
						break;
				}
				else
				{
					int iDamage = ceilf(std::max(pSniperRifle->m_flChargedDamage(), 50.f) * pSniperRifle->GetBodyshotMult(pPlayer));
					if (pPlayer->m_iHealth() <= iDamage)
						break;
				}
			}
			else if (tTarget.m_pEntity->IsBuilding())
			{
				auto pBuilding = tTarget.m_pEntity->As<CBaseObject>();
				int iDamage = ceilf(std::max(pSniperRifle->m_flChargedDamage(), 50.f));
				if (pBuilding->m_iHealth() <= iDamage)
					break;
			}
			else
				break;
			
			return false;
		}
		}
	}

	return true;
}

bool CAimbotHitscan::Aim(const Vec3& vCurAngle, Vec3 vToAngle, Vec3& vOut, int iMethod)
{
	if (Vec3* pHoldAngle = F::Ticks.GetShootAngle())
	{
		vOut = *pHoldAngle;
		return true;
	}

	bool bReturn = false;
	if (auto pLocal = H::Entities.GetLocal())
		vToAngle -= pLocal->m_vecPunchAngle();
	switch (iMethod)
	{
	case Vars::Aimbot::General::AimTypeEnum::Plain:
	case Vars::Aimbot::General::AimTypeEnum::Silent:
	case Vars::Aimbot::General::AimTypeEnum::Locking:
		vOut = vToAngle;
		break;
	case Vars::Aimbot::General::AimTypeEnum::Smooth:
		if (!SmoothAim::Preview(vToAngle,vOut))
			vOut = vCurAngle.LerpAngle(vToAngle, Vars::Aimbot::General::AssistStrength.Value / 100.f);
		bReturn = true;
		break;
	case Vars::Aimbot::General::AimTypeEnum::Assistive:
		Vec3 vMouseDelta = G::CurrentUserCmd->viewangles.DeltaAngle(G::LastUserCmd->viewangles);
		Vec3 vTargetDelta = vToAngle.DeltaAngle(G::LastUserCmd->viewangles);
		float flMouseDelta = vMouseDelta.Length2DSqr(), flTargetDelta = vTargetDelta.Length2DSqr();
		vTargetDelta = vTargetDelta.Normalized() * sqrtf(std::min(flMouseDelta, flTargetDelta));
		vOut = vCurAngle - vMouseDelta + vMouseDelta.LerpAngle(vTargetDelta, Vars::Aimbot::General::AssistStrength.Value / 100.f);
		bReturn = true;
		break;
	}

	//if (iMethod != Vars::Aimbot::General::AimTypeEnum::Silent || F::AntiCheatCompatibility.Active())
		Math::ClampAngles(vOut);
	return bReturn;
}

// assume angle calculated outside with other overload
void CAimbotHitscan::Aim(CUserCmd* pCmd, Vec3& vAngles, int iMethod)
{
	bool bUnsure = F::Ticks.IsTimingUnsure();
	switch (iMethod)
	{
	case Vars::Aimbot::General::AimTypeEnum::Plain:
		if (G::Attacking != 1 && !bUnsure)
			break;
		[[fallthrough]];
	case Vars::Aimbot::General::AimTypeEnum::Smooth:
	case Vars::Aimbot::General::AimTypeEnum::Assistive:
		pCmd->viewangles = vAngles;
		I::EngineClient->SetViewAngles(vAngles);
        if(iMethod==Vars::Aimbot::General::AimTypeEnum::Smooth)SmoothAim::Select(vAngles);
		break;
	case Vars::Aimbot::General::AimTypeEnum::Silent:
		if (G::Attacking == 1 || bUnsure)
		{
			SDK::FixMovement(pCmd, vAngles);
			pCmd->viewangles = vAngles;
			G::SilentAngles = true;
		}
		break;
	case Vars::Aimbot::General::AimTypeEnum::Locking:
		SDK::FixMovement(pCmd, vAngles);
		pCmd->viewangles = vAngles;
		G::SilentAngles = true;
	}
}

static inline void DrawVisuals(CTFPlayer* pLocal, Target_t& tTarget, int nWeaponID)
{
	if (G::Attacking == 1)
	{
		G::AimTarget = { tTarget.m_pEntity->entindex(), I::GlobalVars->tickcount };
		G::AimPoint = { tTarget.m_vPos, I::GlobalVars->tickcount };
	}
	else
	{
		G::AimTarget = { tTarget.m_pEntity->entindex(), I::GlobalVars->tickcount, 0 };
		G::AimPoint = { tTarget.m_vPos, I::GlobalVars->tickcount, 0 };
	}

	if (G::Attacking == 1 && nWeaponID != TF_WEAPON_LASER_POINTER)
	{
		bool bLine = Vars::Visuals::Line::TracersEnabled.Value;
		bool bBoxes = Vars::Visuals::Hitbox::BonesEnabled.Value & Vars::Visuals::Hitbox::BonesEnabledEnum::OnShot;
		if (bLine || bBoxes)
		{
			G::LineStorage.clear();
			G::BoxStorage.clear();
			G::PathStorage.clear();

			if (bLine)
			{
				Vec3 vEyePos = pLocal->GetShootPos();
				float flDist = vEyePos.DistTo(tTarget.m_vPos);
				Vec3 vForward; Math::AngleVectors(tTarget.m_vAngleTo + pLocal->m_vecPunchAngle(), &vForward);

				if (Vars::Colors::LineIgnoreZ.Value.a)
					G::LineStorage.emplace_back(std::pair<Vec3, Vec3>(vEyePos, vEyePos + vForward * flDist), I::GlobalVars->curtime + Vars::Visuals::Line::DrawDuration.Value, Vars::Colors::LineIgnoreZ.Value);
				if (Vars::Colors::Line.Value.a)
					G::LineStorage.emplace_back(std::pair<Vec3, Vec3>(vEyePos, vEyePos + vForward * flDist), I::GlobalVars->curtime + Vars::Visuals::Line::DrawDuration.Value, Vars::Colors::Line.Value, true);
			}
			if (bBoxes)
			{
				auto vBoxes = F::Visuals.GetHitboxes(tTarget.m_pRecord->m_aBones, tTarget.m_pEntity->As<CBaseAnimating>(), {}, tTarget.m_nAimedHitbox);
				G::BoxStorage.insert(G::BoxStorage.end(), vBoxes.begin(), vBoxes.end());
			}
		}
	}
}

bool CAimbotHitscan::BuildOccludedGuide(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CBaseEntity* pTarget)
{
	// Display-only fallback: an obstructed shot must not suppress the ESP estimate.
	// Never publish this point as an aim target or cooldown crosshair/viewmodel point.
	if (!pTarget->IsPlayer() || pWeapon->GetWeaponID() == TF_WEAPON_MEDIGUN
		|| pWeapon->GetWeaponID() == TF_WEAPON_LASER_POINTER)
		return false;
	std::vector<TickRecord*> records;
	if (!F::Backtrack.GetRecords(pTarget, records) || !BuildServerEstimate(pTarget, records))
		return false;
	for (const auto& hitbox : GetHitboxes(pLocal, pWeapon, pTarget))
	{
		const auto* box = hitbox.m_pBox;
		if (!box || box->bone < 0 || box->bone >= MAXSTUDIOBONES) continue;
		Vec3 endpoint;
		Math::VectorTransform((box->bbmin + box->bbmax) * 0.5f, m_tServerEstimate.m_aBones[box->bone], endpoint);
		const Vec3 eye = pLocal->GetShootPos();
		if (eye.DistToSqr(endpoint) > powf(pWeapon->GetRange(), 2.f)
			|| !F::AimbotGlobal.ShouldAimAtAngle(Math::CalcAngle(eye, endpoint)))
			continue;
		G::ExtrapolationGuide = { endpoint - m_vEstimateOffset, endpoint, m_flEstimateSeconds, I::GlobalVars->tickcount,
			pTarget->As<IHandleEntity>()->GetRefEHandle(), hitbox.m_iHitbox };
		return true;
	}
	return false;
}

void CAimbotHitscan::Run(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd)
{
	const bool enabled = Vars::Aimbot::General::AimType.Value != 0;
	m_vMainPreview.reset();
	RunMain(pLocal, pWeapon, pCmd);
	const bool aimPreview = (Vars::Visuals::Viewmodel::CrosshairAim.Value && Vars::Visuals::Viewmodel::CrosshairCooldown.Value)
		|| (Vars::Visuals::Viewmodel::ViewmodelAim.Value && Vars::Visuals::Viewmodel::ViewmodelCooldown.Value);
	const bool guide = Vars::Aimbot::Hitscan::Extrapolation.Value && Vars::Aimbot::Hitscan::ExtrapolationGuide.Value;
	if (!enabled || F::Aimbot.m_bRunningSecondary || (!aimPreview && !guide))
		return;
	// Only reuse an actual CanHit==1 solution from this invocation. No stale
	// record pointers, cross-command cache, or fire/input changes are involved.
	if(m_vMainPreview)
	{
		if(aimPreview && G::Attacking!=1)
			G::CooldownAimPoint={*m_vMainPreview,I::GlobalVars->tickcount,2};
		if(G::Attacking==1 || !guide || G::ExtrapolationGuide.tick) return;
	}
	// Visual-only target evaluation: never execute the aim/fire/input path here.
	auto targets = F::AimbotGlobal.ManageTargets(GetTargets, pLocal, pWeapon);
	if(!m_vMainPreview) for (auto& target : targets)
	{
		if (G::Attacking == 1) break;
		if (CanHit(target, pLocal, pWeapon) != 1) continue;
		if (aimPreview)
			G::CooldownAimPoint = { target.m_vPos, I::GlobalVars->tickcount, 2 };
		break;
	}
	// Prefer the actual hittable solution; otherwise show the best eligible estimate
	// even through a wall. This pass does not alter CanHit or any shooting checks.
	if (guide && !G::ExtrapolationGuide.tick)
		for (auto& target : targets)
			if (BuildOccludedGuide(pLocal, pWeapon, target.m_pEntity)) break;
}

void CAimbotHitscan::RunMain(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd)
{
	const int nWeaponID = pWeapon->GetWeaponID();

	static int iStaticAimType = Vars::Aimbot::General::AimType.Value;
	const int iLastAimType = iStaticAimType;
	const int iRealAimType = Vars::Aimbot::General::AimType.Value;

	switch (nWeaponID)
	{
	case TF_WEAPON_SNIPERRIFLE_CLASSIC:
		if (G::Attacking && !iRealAimType && iLastAimType)
			Vars::Aimbot::General::AimType.Value = iLastAimType;
	}
	iStaticAimType = Vars::Aimbot::General::AimType.Value;

	if (F::AimbotGlobal.ShouldHoldAttack(pWeapon))
		pCmd->buttons |= IN_ATTACK;
	if (!Vars::Aimbot::General::AimType.Value
		|| !F::AimbotGlobal.ShouldAim() && (nWeaponID != TF_WEAPON_MINIGUN || pWeapon->As<CTFMinigun>()->m_iWeaponState() == AC_STATE_FIRING || pWeapon->As<CTFMinigun>()->m_iWeaponState() == AC_STATE_SPINNING))
		return;

	switch (nWeaponID)
	{
	case TF_WEAPON_MINIGUN:
		if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::AutoRev)
			pCmd->buttons |= IN_ATTACK2;
		if (pWeapon->As<CTFMinigun>()->m_iWeaponState() != AC_STATE_FIRING && pWeapon->As<CTFMinigun>()->m_iWeaponState() != AC_STATE_SPINNING)
			return;
		break;
	}

	auto vTargets = F::AimbotGlobal.ManageTargets(GetTargets, pLocal, pWeapon);
	if (vTargets.empty())
		return;

	switch (nWeaponID)
	{
	case TF_WEAPON_SNIPERRIFLE:
	case TF_WEAPON_SNIPERRIFLE_DECAP:
	{
		bool bScoped = pLocal->InCond(TF_COND_ZOOMED);
		if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::AutoScope && !bScoped)
		{
			pCmd->buttons |= IN_ATTACK2;
			return;
		}
		else if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::ScopedOnly && !bScoped)
			return;
		else if (!bScoped && SDK::AttribHookValue(0, "sniper_only_fire_zoomed", pWeapon))
			return;
		break;
	}
	case TF_WEAPON_SNIPERRIFLE_CLASSIC:
		if (iRealAimType)
			pCmd->buttons |= IN_ATTACK;
	}

	for (auto& tTarget : vTargets)
	{
        SmoothAim::CandidateScope smoothing(tTarget.m_pEntity);
		if (nWeaponID == TF_WEAPON_MEDIGUN && pWeapon->As<CWeaponMedigun>()->m_hHealingTarget().Get() == tTarget.m_pEntity)
		{
			if (G::LastUserCmd->buttons & IN_ATTACK)
				pCmd->buttons |= IN_ATTACK;
			return;
		}

		const auto iResult = CanHit(tTarget, pLocal, pWeapon);
		if (!iResult) continue;
        if (!F::AimbotGlobal.AllowTargetSwitch(tTarget.m_pEntity)) break;
		F::Aimbot.m_bHitscanAssisted = true;
		if (iResult == 2)
		{
			G::AimTarget = { tTarget.m_pEntity->entindex(), I::GlobalVars->tickcount, 0 };
			Aim(pCmd, tTarget.m_vAngleTo);
			break;
		}

		m_vMainPreview=tTarget.m_vPos;
		if (ShouldFire(pLocal, pWeapon, pCmd, tTarget))
		{
			switch (nWeaponID)
			{
			case TF_WEAPON_MEDIGUN:
				if (!(G::LastUserCmd->buttons & IN_ATTACK))
					pCmd->buttons |= IN_ATTACK;
				break;
			case TF_WEAPON_SNIPERRIFLE_CLASSIC:
				if (pWeapon->As<CTFSniperRifle>()->m_flChargedDamage() && pLocal->m_hGroundEntity())
					pCmd->buttons &= ~IN_ATTACK;
				break;
			case TF_WEAPON_LASER_POINTER:
				pCmd->buttons |= IN_ATTACK | IN_ATTACK2;
				break;
			default:
				pCmd->buttons |= IN_ATTACK;
			}

			if (Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::Tapfire && pWeapon->GetWeaponSpread() != 0.f && !pLocal->InCond(TF_COND_RUNE_PRECISION)
				&& m_vEyePos.DistToSqr(tTarget.m_vPos) > powf(Vars::Aimbot::Hitscan::TapfireDistance.Value, 2))
			{
				const float flTimeSinceLastShot = (pLocal->m_nTickBase() * TICK_INTERVAL) - pWeapon->m_flLastFireTime();
				if (flTimeSinceLastShot <= (pWeapon->GetBulletsPerShot() > 1 ? 0.25f : 1.25f))
					pCmd->buttons &= ~IN_ATTACK;
			}
		}

		G::Attacking = SDK::IsAttacking(pLocal, pWeapon, pCmd, true);
		if (G::Attacking == 1 && nWeaponID != TF_WEAPON_LASER_POINTER)
		{
			if (tTarget.m_pEntity->IsPlayer())
				F::Resolver.HitscanRan(pLocal, tTarget.m_pEntity->As<CTFPlayer>(), pWeapon, tTarget.m_nAimedHitbox);

            if (tTarget.m_bBacktrack)
            {
                pCmd->tick_count = TIME_TO_TICKS(tTarget.m_pRecord->m_flSimTime) + TIME_TO_TICKS(F::Backtrack.GetFakeInterp());
                F::Backtrack.ReportSelection(tTarget.m_pRecord,pCmd,tTarget.m_pEntity->entindex());
            }
		}
		DrawVisuals(pLocal, tTarget, nWeaponID);

		Aim(pCmd, tTarget.m_vAngleTo);
		if (G::SilentAngles)
		{
			switch (nWeaponID)
			{
			case TF_WEAPON_MEDIGUN:
			//case TF_WEAPON_LASER_POINTER: // we can psilent with the wrangler though probably with some hacks
				G::SilentAngles = false, G::PSilentAngles = true;
			}
		}
		break;
	}
}
