#pragma once
#include "../TextStyle.h"
#include "../Render.h"
#include "../../../SDK/Helpers/Draw/Draw.h"
#include "Menu.h"
#include "SectionLayout.h"
#include "../Fonts/MaterialDesign/IconDefinitions.h"
#include "../../Binds/Binds.h"
#include "../../Aimbot/AimModes.h"
#include "../../Visuals/Materials/Materials.h"
#include <ImGui/imgui_internal.h>
#include <ImGui/imgui_stdlib.h>
#include <numeric>
#include <functional>

inline ImVec4 MenuTitleColour()
{
    return { Workspace::TitleTextChannel(0), Workspace::TitleTextChannel(1), Workspace::TitleTextChannel(2), 1.f };
}

Enum(FTabs, None = 0, Horizontal = 0, Vertical = 1 << 0, HorizontalIcons = 0, VerticalIcons = 1 << 1, AlignCenter = 0, AlignLeft = 1 << 2, AlignRight = 1 << 3, AlignTop = 1 << 4, AlignBottom = 1 << 5, AlignForward = 0, AlignReverse = 1 << 6, BarLeft = 1 << 7, BarRight = 1 << 8, BarTop = 1 << 9, BarBottom = 1 << 10, Fit = 1 << 11);
Enum(FText, None = 0, Middle = 1 << 0, Right = 1 << 1, SameLine = 1 << 2);
Enum(FButton, None = 0, Left = 1 << 0, Right = 1 << 1, Fit = 1 << 2, SameLine = 1 << 3, NoUpper = 1 << 4, Compact = 1 << 6);
Enum(FKeybind, None = 0, AllowNone = 1 << 5);
Enum(FToggle, None = 0, Left = 1 << 0, Right = 1 << 1, PlainColor = 1 << 2, Invert = TOGGLE_INVERT);
Enum(FSlider, None = 0, Left = 1 << 0, Right = 1 << 1, Clamp = 1 << 2, Min = 1 << 3, Max = 1 << 4, Precision = 1 << 5, NoAutoUpdate = 1 << 6);
Enum(FDropdown, None = 0, Left = 1 << 0, Right = 1 << 1, Multi = 1 << 2, Modifiable = 1 << 3, NoSanitization = 1 << 4, InlineTitle = 1 << 5);
Enum(FSDropdown, None = 0, Custom = 1 << 2, AutoUpdate = 1 << 3);
Enum(FColorPicker, None = 0, Left = 1 << 0, Right = 1 << 1, Full = 1 << 2, SameLine = 1 << 3, Tooltip = 1 << 4, NoTooltip = 1 << 5, RetainPosition = 1 << 6, HoverContents = 1 << 7, RemoveVisuals = 1 << 8);

Enum(Widget, Invalid, FToggle, FSlider, FISlider = FSlider, FFSlider, FIRSlider, FFRSlider, FDropdown, FSDropdown, FMDropdown, FColorPicker, FGColorPicker, FKeybind);

struct WidgetWindow_t
{
	std::string m_sName;
	ImVec2 m_vPos;
	ImVec2 m_vSize;
	int m_iWindowFlags;
	int m_iChildFlags;
};

//#define ALTERNATE_FULL_SLIDER

static inline bool    operator==(const ImVec2& lhs, const ImVec2& rhs) { return lhs.x == rhs.x && lhs.y == rhs.y; }
static inline bool    operator!=(const ImVec2& lhs, const ImVec2& rhs) { return lhs.x != rhs.x || lhs.y != rhs.y; }
static inline ImVec2  operator*(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x * rhs, lhs.y * rhs); }
static inline ImVec2  operator/(const ImVec2& lhs, const float rhs) { return ImVec2(lhs.x / rhs, lhs.y / rhs); }
static inline ImVec2  operator+(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x + rhs.x, lhs.y + rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x - rhs.x, lhs.y - rhs.y); }
static inline ImVec2  operator*(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x * rhs.x, lhs.y * rhs.y); }
static inline ImVec2  operator/(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x / rhs.x, lhs.y / rhs.y); }
static inline ImVec2  operator-(const ImVec2& lhs) { return ImVec2(-lhs.x, -lhs.y); }
static inline ImVec2& operator*=(ImVec2& lhs, const float rhs) { lhs.x *= rhs; lhs.y *= rhs; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const float rhs) { lhs.x /= rhs; lhs.y /= rhs; return lhs; }
static inline ImVec2& operator+=(ImVec2& lhs, const ImVec2& rhs) { lhs.x += rhs.x; lhs.y += rhs.y; return lhs; }
static inline ImVec2& operator-=(ImVec2& lhs, const ImVec2& rhs) { lhs.x -= rhs.x; lhs.y -= rhs.y; return lhs; }
static inline ImVec2& operator*=(ImVec2& lhs, const ImVec2& rhs) { lhs.x *= rhs.x; lhs.y *= rhs.y; return lhs; }
static inline ImVec2& operator/=(ImVec2& lhs, const ImVec2& rhs) { lhs.x /= rhs.x; lhs.y /= rhs.y; return lhs; }

namespace ImGui
{
	inline std::unordered_map<uint32_t, int> ActiveMap = {};

	inline bool Disabled = false, Transparent = false;
	inline int CurrentBind = DEFAULT_BIND;
	inline bool Hovered = false;

	inline std::vector<bool> DisabledVec = {}, TransparentVec = {};
	inline void PushDisabled(bool bDisabled)
	{
		DisabledVec.push_back(Disabled = bDisabled);
	}
	inline void PopDisabled(int count = 1)
	{
		int iSize = int(DisabledVec.size());
		if (iSize < count)
		{
			IM_ASSERT_USER_ERROR(0, "Calling PopDisabled() too many times: stack underflow.");
			count = iSize;
		}
		for (int i = 0; i < count; i++)
			DisabledVec.pop_back();
		Disabled = !DisabledVec.empty() ? DisabledVec.back() : false;
	}
	inline void PushTransparent(bool bTransparent, bool bPushAlpha = false)
	{
		TransparentVec.push_back(Transparent = bTransparent);

		if (bPushAlpha)
			PushStyleVar(ImGuiStyleVar_Alpha, !bTransparent ? 1.f : 0.5f);
	}
	inline void PopTransparent(int count = 1, int iPopAlpha = false)
	{
		int iSize = int(TransparentVec.size());
		if (iSize < count)
		{
			IM_ASSERT_USER_ERROR(0, "Calling PopTransparent() too many times: stack underflow.");
			count = iSize;
		}
		for (int i = 0; i < count; i++)
			TransparentVec.pop_back();
		Transparent = !TransparentVec.empty() ? TransparentVec.back() : false;

		if (iPopAlpha)
			PopStyleVar(iPopAlpha);
	}

	inline ImVec2 GetDrawPos()
	{
		return GetWindowPos() - GetCurrentWindow()->Scroll;
	}
	inline float GetDrawPosX()
	{
		return GetWindowPos().x - GetCurrentWindow()->Scroll.x;
	}
	inline float GetDrawPosY()
	{
		return GetWindowPos().y - GetCurrentWindow()->Scroll.y;
	}

	struct Row_t
	{
		ImVec2 m_vPos;
		ImVec2 m_vSize;
	};
	inline std::vector<Row_t> vRowSizesRegular = {}, vRowSizesPopup = {};
	inline std::vector<Row_t>* pRowSizes = &vRowSizesRegular;
	inline void AddRowSize(ImVec2 vPos, ImVec2 vSize)
	{
		pRowSizes = GetCurrentWindow()->Flags & ImGuiWindowFlags_Popup ? &vRowSizesPopup : &vRowSizesRegular;

		vPos += GetDrawPos();
		if (!pRowSizes->empty() && pRowSizes->back().m_vPos.y != vPos.y)
			pRowSizes->clear();
		pRowSizes->emplace_back(vPos, vSize);
	}
	inline float GetRowPos(bool bDrawPos = false)
	{
		if (!pRowSizes->empty())
			return pRowSizes->front().m_vPos.y - (!bDrawPos ? GetDrawPos().y : 0.f);
		else
			return GetCursorPosY() + (bDrawPos ? GetDrawPos().y : 0.f);
	}
	inline float GetRowSize(float flDefault = 0.f)
	{
		pRowSizes = GetCurrentWindow()->Flags & ImGuiWindowFlags_Popup ? &vRowSizesPopup : &vRowSizesRegular;

		float flMax = 0.f;
		for (auto& [_, vSize] : *pRowSizes)
			flMax = std::max(flMax, vSize.y);
		return flMax;
	}

	inline bool IsColorBright(ImColor tColor, float flValue = 0.686f, float flRed = 0.299f, float flGreen = 0.587f, float flBlue = 0.114f)
	{
		return tColor.Value.x * flRed + tColor.Value.y * flGreen + tColor.Value.z * flBlue > flValue;
	}
	inline bool IsColorDark(ImColor tColor, float flValue = 0.313f, float flRed = 0.299f, float flGreen = 0.587f, float flBlue = 0.114f)
	{
		return tColor.Value.x * flRed + tColor.Value.y * flGreen + tColor.Value.z * flBlue < flValue;
	}

	inline ImU32 ColorByteToInt(Color_t tColor)
	{
		return tColor.r << IM_COL32_R_SHIFT | tColor.g << IM_COL32_G_SHIFT | tColor.b << IM_COL32_B_SHIFT | tColor.a << IM_COL32_A_SHIFT;
	}

	inline Color_t ColorIntToByte(ImU32 tColor)
	{
		return { byte(tColor >> IM_COL32_R_SHIFT), byte(tColor >> IM_COL32_G_SHIFT), byte(tColor >> IM_COL32_B_SHIFT), byte(tColor >> IM_COL32_A_SHIFT) };
	}

	inline ImVec4 ColorByteToVec(Color_t tColor)
	{
		return { tColor.r / 255.f, tColor.g / 255.f, tColor.b / 255.f, tColor.a / 255.f };
	}

	inline Color_t ColorVecToByte(ImVec4 tColor)
	{
		return { byte(tColor.x * 255), byte(tColor.y * 255), byte(tColor.z * 255), byte(tColor.w * 255) };
	}

	inline ImColor ColorByteToFloat(Color_t tColor)
	{
		return { tColor.r / 255.f, tColor.g / 255.f, tColor.b / 255.f, tColor.a / 255.f };
	}

	inline Color_t ColorFloatToByte(ImColor tColor)
	{
		return { byte(tColor.Value.x * 255), byte(tColor.Value.y * 255), byte(tColor.Value.z * 255), byte(tColor.Value.w * 255) };
	}

	inline void DebugDummy(ImVec2 vSize)
	{
		/*
		ImDrawList* pDrawList = GetWindowDrawList();
		ImVec2 vDrawPos = GetDrawPos() + GetCursorPos();
		pDrawList->AddRectFilled(vDrawPos, vDrawPos + ImVec2(std::max(vSize.x, 2.f), std::max(vSize.y, 2.f)), ImColor(0.f, 0.f, 0.f, 0.5f));
		*/

		Dummy(vSize);
	}
	inline void DebugShift(ImVec2 vSize)
	{
		/*
		ImDrawList* pDrawList = GetWindowDrawList();
		ImVec2 vDrawPos = GetDrawPos() + GetCursorPos();
		pDrawList->AddRectFilled(vDrawPos, vDrawPos + ImVec2(std::max(vSize.x, 2.f), std::max(vSize.y, 2.f)), ImColor(1.f, 1.f, 1.f, 0.5f));
		*/

		SetCursorPos(GetCursorPos() + vSize);
	}

	inline bool IsMouseWithin(float x, float y, float w, float h)
	{
		ImVec2 vMouse = GetMousePos();
		bool bWithin = x <= vMouse.x && vMouse.x < x + w
					&& y <= vMouse.y && vMouse.y < y + h;

		/*
		ImDrawList* pDrawList = GetWindowDrawList();
		ImVec2 vDrawPos = GetDrawPos() - GetWindowPos();
		pDrawList->AddRectFilled(vDrawPos + ImVec2(x, y), vDrawPos + ImVec2(x + w, y + h), bWithin ? ImColor(1.f, 0.f, 0.f, 0.5f) : ImColor(0.f, 1.f, 1.f, 0.5f));
		*/

		return bWithin;
	}

	inline std::string StripDoubleHash(const char* sText)
	{
		std::string sBegin = sText, sEnd = FindRenderedTextEnd(sText);
		return sBegin.replace(sBegin.end() - sEnd.size(), sBegin.end(), "");
	}



	inline void RenderBackground(ImU32 uBackground)
	{
		ImVec2 vSize = GetWindowSize();
		ImVec2 vDrawPos = GetDrawPos();
		ImDrawList* pDrawList = GetWindowDrawList();

		pDrawList->AddRectFilled(vDrawPos, vDrawPos + vSize, uBackground, MenuMode::DrawingMoonlit ? H::Draw.Scale(10) : 0.f);
	}
	inline void RenderBackground(ImU32 uBackground, ImU32 uBorder, float flInset = H::Draw.Scale())
	{
		ImVec2 vSize = GetWindowSize();
		ImVec2 vDrawPos = GetDrawPos();
		ImDrawList* pDrawList = GetWindowDrawList();

		pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), uBackground, MenuMode::DrawingMoonlit ? H::Draw.Scale(10) : 0.f);
		
		flInset += H::Draw.Scale(0.5f) - 0.5f - H::Draw.Scale();
		pDrawList->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), uBorder, MenuMode::DrawingMoonlit ? H::Draw.Scale(10) : 0.f, ImDrawFlags_None, H::Draw.Scale());
	}
	inline void RenderTwoToneBackground(float flSize, ImU32 uTitle, ImU32 uBackground, bool bHorizontal = false)
	{
		ImVec2 vSize = GetWindowSize();
		ImVec2 vDrawPos = GetDrawPos();
		ImDrawList* pDrawList = GetWindowDrawList();

		if (!bHorizontal)
		{
			pDrawList->AddRectFilled(vDrawPos, vDrawPos + ImVec2(vSize.x, flSize), uTitle, 0.f, ImDrawFlags_RoundCornersTop);
			pDrawList->AddRectFilled(vDrawPos + ImVec2(0, flSize), vDrawPos + vSize, uBackground, 0.f, ImDrawFlags_RoundCornersBottom);
		}
		else
		{
			pDrawList->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flSize, vSize.y), uTitle, 0.f, ImDrawFlags_RoundCornersLeft);
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flSize, 0), vDrawPos + vSize, uBackground, 0.f, ImDrawFlags_RoundCornersRight);
		}
	}
	inline void RenderTwoToneBackground(float flSize, ImU32 uTitle, ImU32 uBackground, ImU32 uBorder, float flInset = H::Draw.Scale(), bool bVertical = true, bool bTwoToneBorder = true)
	{
		ImVec2 vSize = GetWindowSize();
		ImVec2 vDrawPos = GetDrawPos();
		ImDrawList* pDrawList = GetWindowDrawList();

		if (bVertical)
		{
			if (!bTwoToneBorder)
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(vSize.x - flInset, flSize), uTitle, 0.f, ImDrawFlags_RoundCornersTop);
			else
			{
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(vSize.x - flInset, flSize - H::Draw.Scale()), uTitle, 0.f, ImDrawFlags_RoundCornersTop);
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flSize - H::Draw.Scale()), vDrawPos + ImVec2(vSize.x - flInset, flSize), uBorder);
			}
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flSize), vDrawPos + vSize - ImVec2(flInset, flInset), uBackground, 0.f, ImDrawFlags_RoundCornersBottom);
		}
		else
		{
			if (!bTwoToneBorder)
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(flSize, vSize.y - flInset), uTitle, 0.f, ImDrawFlags_RoundCornersLeft);
			else
			{
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(flSize - H::Draw.Scale(), vSize.y - flInset), uTitle, 0.f, ImDrawFlags_RoundCornersLeft);
				pDrawList->AddRectFilled(vDrawPos + ImVec2(flSize - H::Draw.Scale(), flInset), vDrawPos + ImVec2(flSize, vSize.y - flInset), uBorder);
			}
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flSize, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), uBackground, 0.f, ImDrawFlags_RoundCornersRight);
		}
		
		flInset += H::Draw.Scale(0.5f) - 0.5f - H::Draw.Scale();
		pDrawList->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), uBorder, 0.f, ImDrawFlags_None, H::Draw.Scale());
	}
	inline void Divider(float flPrePadding = H::Draw.Scale(8), float flPostPadding = H::Draw.Scale(7), float flInset = H::Draw.Scale(), ImU32 uBorder = F::Render.Background2)
	{
		ImVec2 vSize = GetWindowSize();
		ImVec2 vDrawPos = GetDrawPos() + ImVec2(0, GetCursorPosY());
		ImDrawList* pDrawList = GetWindowDrawList();

		pDrawList->AddRectFilled(vDrawPos + ImVec2(flInset, flPrePadding - H::Draw.Scale()), vDrawPos + ImVec2(vSize.x - flInset, flPrePadding), uBorder);
		DebugDummy({ 0, flPrePadding + flPostPadding });
	}

	inline void AddSteppedRect(ImVec2 vPos, ImVec2 vPosMin, ImVec2 vPosMax, ImVec2 vClipMin, ImVec2 vClipMax, float flVMin, float flVMax, float flStep, ImU32 uPrimary, ImU32 uSecondary, float flStepWidth)
	{
		ImDrawList* pDrawList = GetWindowDrawList();
		pDrawList->PushClipRect(vPos + vClipMin, vPos + vClipMax, true);

		bool bValid = !MenuMode::DrawingMoonlit && flStep > 0.f && flVMax > flVMin; // Moonlit draws a continuous rail; snapping is unchanged.
		int iSteps = bValid ? int((flVMax - flVMin) / flStep) : 0;
		if (bValid && (iSteps < 21 || (vPosMax.x - vPosMin.x) / iSteps > 6.f))
		{
			std::vector<std::pair<float, float>> vSteps;

			// steps are relative to the minimum, matching how the slider snaps
			float flMin = flVMin, max = flVMin + (flVMax - flVMin) - fnmodf(flVMax - flVMin + flStep / 2, flStep) + flStep / 2;

			if (fabsf(flVMin - flMin) < 0.001f)
				vSteps.emplace_back(vPosMin.x, vPosMin.x + flStepWidth);
			while (true)
			{
				flMin += flStep;
				if (flMin + flStep / 2 > flVMax)
					break;

				float flPercent = std::clamp((flMin - flVMin) / (flVMax - flVMin), 0.f, 1.f);
				float flPosition = vPosMin.x + (vPosMax.x - vPosMin.x) * flPercent;
				vSteps.emplace_back(roundf(flPosition - flStepWidth / 2), roundf(flPosition + flStepWidth / 2));
			}
			if (fabsf(flVMax - max) < 0.001f)
				vSteps.emplace_back(vPosMax.x - flStepWidth, vPosMax.x);

			if (!vSteps.empty())
			{
				for (size_t i = 0; i < vSteps.size(); i++)
				{
					if (!i)
						pDrawList->AddRectFilled(vPos + vPosMin, vPos + ImVec2(vSteps.front().first, vPosMax.y), uPrimary);
					else
						pDrawList->AddRectFilled(vPos + ImVec2(vSteps[i - 1].second, vPosMin.y), vPos + ImVec2(vSteps[i].first, vPosMax.y), uPrimary);
					pDrawList->AddRectFilled(vPos + ImVec2(vSteps[i].first, vPosMin.y), vPos + ImVec2(vSteps[i].second, vPosMax.y), uSecondary);
				}
				pDrawList->AddRectFilled(vPos + ImVec2(vSteps.back().second, vPosMin.y), vPos + vPosMax, uPrimary);

				return pDrawList->PopClipRect();
			}
		}
		pDrawList->AddRectFilled(vPos + vPosMin, vPos + vPosMax, uPrimary);

		pDrawList->PopClipRect();
	}

	inline ImVec2 FCalcTextSize(const char* sText, ImFont* pFont = nullptr)
	{
		if (pFont) PushFont(pFont);
		auto vTextSize = CalcTextSize(sText);
		if (pFont) PopFont();
		return vTextSize;
	}

	inline ImVec2 IconSize(const char* sIcon)
	{
		PushFont(F::Render.IconFont);
		ImVec2 vTextSize = CalcTextSize(sIcon);
		PopFont();
		return vTextSize;
	}

	inline const char* FormatText(const char* fmt, ...)
	{
		va_list args;
		va_start(args, fmt);

		const char* sText;
		ImFormatStringToTempBufferV(&sText, nullptr, fmt, args);
		va_end(args);

		return sText;
	}

	inline std::string TruncateText(const std::string& sText, int iPixels, ImFont* pFont = nullptr, const char* sEnd = "...", int iMin = 0, int* pLength = nullptr)
	{
		if (sText.empty() || FCalcTextSize(sText.c_str(), pFont).x < iPixels) // no unnecessary truncation
			return sText;

		std::string sTruncated = "";
		int i = 0; while (i < sText.length())
		{
			// advance by whole UTF-8 characters so a multi-byte character is never cut in half
			int iNext = i + 1;
			while (iNext < sText.length() && (sText[iNext] & 0xC0) == 0x80)
				iNext++;
			if (i >= iMin && FCalcTextSize(std::format("{}{}{}", sTruncated, std::string_view(sText).substr(i, iNext - i), sEnd).c_str(), pFont).x >= iPixels)
				break;
			sTruncated.append(sText, i, iNext - i);
			i = iNext;
		}
		if (i)
			sTruncated += sEnd;
		if (pLength)
			*pLength = i;

		return sTruncated;
	}

	inline std::vector<std::string> WrapText(const std::string& sText, std::vector<int> vPixels, ImFont* pFont = nullptr)
	{
		if (vPixels.empty())
		{
			IM_ASSERT_USER_ERROR(0, "WrapText() vPixels empty.");
			return {};
		}

		if (sText.empty() || sText.find("\n") == std::string::npos && FCalcTextSize(sText.c_str(), pFont).x < vPixels.front()) // no unnecessary wrapping
			return { sText };

		std::vector<std::string> vWords = { "" };
		for (char iChar : sText)
		{
			if (iChar == ' ' || iChar == '\n' || iChar == '\t')
				vWords.push_back(std::string(1, iChar));
			else
				vWords.back().push_back(iChar);
		}

		std::vector<std::string> vWrapped = { "" };
		int iWord = 0; for (auto& sWord : vWords)
		{
		begin:
			if (sWord.empty())
				continue;

			int iPixels = vPixels[std::min(vWrapped.size(), vPixels.size()) - 1];
			bool bForce = sWord[0] == '\n';
			if (!bForce && FCalcTextSize(std::format("{}{}", vWrapped.back(), sWord).c_str(), pFont).x < iPixels)
			{
				vWrapped.back() += sWord;
				iWord++;
			}
			else
			{
				if (sWord[0] == ' ' || sWord[0] == '\t' || bForce)
					sWord.erase(0, 1);

				if (!iWord && !bForce)
				{
					int i = 0; vWrapped.back() += TruncateText(sWord, iPixels, pFont, "-", 1, &i);
					sWord = sWord.substr(i, sWord.length() - i);
				}
				if (!sWord.empty() || bForce)
				{
					vWrapped.push_back(""); iWord = 0;
					goto begin;
				}
			}
		}

		return vWrapped;
	}
	inline std::vector<std::string> WrapText(const std::string& sText, int iPixels, ImFont* pFont = nullptr)
	{
		return WrapText(sText, std::vector<int>({ iPixels }), pFont);
	}

	inline void FTooltip(const char* sTooltip, bool bCondition = IsItemHovered(), float flWrapWidth = 300, ImFont* pFont = F::Render.FontSmall, ImVec2* pPosOverride = nullptr, ImVec2* pSizeOverride = nullptr)
	{
		if (bCondition)
		{
			PushFont(pFont);

			ImDrawList* pDrawList = GetForegroundDrawList();
			ImVec2 vPos = pPosOverride ? *pPosOverride : !pRowSizes->empty() ? pRowSizes->back().m_vPos : ImVec2((GetItemRectMin().x + GetItemRectMax().x) / 2, GetItemRectMax().y);
			ImVec2 vSize = pSizeOverride ? *pSizeOverride : !pRowSizes->empty() ? pRowSizes->back().m_vSize : ImVec2();

			auto vWraps = WrapText(sTooltip, H::Draw.Scale(flWrapWidth));
			ImVec2 vText = { 0, H::Draw.Scale(9) };
			for (auto& sText : vWraps)
			{
				auto vSize = CalcTextSize(sText.c_str());
				vText.x = std::max(vSize.x, vText.x);
				vText.y += vSize.y + H::Draw.Scale(5);
			}
			vText.x += GetStyle().WindowPadding.x * 2;
			if (fmodf(vText.x, 2.f))
				vText.x += 1;

			vPos += ImVec2(vSize.x / 2, vSize.y + GetStyle().WindowPadding.y);
			vPos.x -= vText.x / 2;

			ImVec2 vP1 = vPos + ImVec2(vText.x / 2 - H::Draw.Scale(8), H::Draw.Scale(1) - 0.5f), vP2 = vPos + ImVec2(vText.x / 2 + H::Draw.Scale(8), H::Draw.Scale(1) - 0.5f), vP3 = vPos + ImVec2(vText.x / 2, H::Draw.Scale(-7) - 0.5f);

			/*
			float flInset = H::Draw.Scale(0.5f) - 0.5f;
			pDrawList->AddRect(vPos + ImVec2(flInset, flInset), vPos + ImVec2(vText.x - flInset, vText.y - flInset), F::Render.Background2, 0.f, ImDrawFlags_None, H::Draw.Scale());
			flInset = H::Draw.Scale();
			pDrawList->AddTriangle(vP1 + ImVec2(-flInset / 2, 0), vP2 + ImVec2(flInset / 2, 0), vP3 + ImVec2(0, -flInset / 2), F::Render.Background2, H::Draw.Scale());
			
			pDrawList->AddRectFilled(vPos + ImVec2(flInset, flInset), vPos + ImVec2(vText.x-flInset, vText.y - flInset), F::Render.Background1p5, 0.f);
			flInset = 1;
			pDrawList->AddTriangleFilled(vP1 + ImVec2(flInset / 2, 0), vP2 + ImVec2(-flInset / 2, 0), vP3 + ImVec2(0, flInset / 2), F::Render.Background1p5);
			*/

			pDrawList->AddRectFilled(vPos, { vPos.x + vText.x, vPos.y + vText.y }, F::Render.Background2, 0.f);
			pDrawList->AddTriangleFilled(vP1, vP2, vP3, F::Render.Background2);

			vPos.x += vText.x / 2;
			vPos.x += GetStyle().WindowPadding.x;
			for (size_t i = 0; i < vWraps.size(); i++)
			{
				auto& sText = vWraps[i];
				//vTextSize.x = CalcTextSize(sText.c_str()).x;
				pDrawList->AddText(vPos + ImVec2(-vText.x / 2, H::Draw.Scale(6) + H::Draw.Scale(16) * i), F::Render.Active, sText.c_str());
			}

			PopFont();
		}
	}

	inline void FText(const char* sText, ImVec2 vOffset = {}, int iFlags = FTextEnum::None, ImFont * pFont = nullptr)
	{
		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		if (pFont)
			PushFont(pFont);

		if (iFlags & FTextEnum::SameLine)
			SameLine();
		if (iFlags & (FTextEnum::Middle | FTextEnum::Right))
		{
			float flWindowWidth = GetWindowWidth();
			float flTextWidth = CalcTextSize(sText).x;
			if (iFlags & FTextEnum::Middle)
				SetCursorPosX((flWindowWidth - flTextWidth) * 0.5f);
			else if (iFlags & FTextEnum::Right)
				SetCursorPosX(flWindowWidth - flTextWidth - GetStyle().WindowPadding.x);
		}
		SetCursorPos(GetCursorPos() + vOffset * H::Draw.Scale());
		TextUnformatted(sText);

		if (pFont)
			PopFont();

		if (Transparent || Disabled)
			PopStyleVar();
	}

	inline bool FInputText(const char* sLabel, std::string& sText, float flWidth = H::Draw.Scale(150), ImGuiInputTextFlags iFlags = ImGuiInputTextFlags_None, ImGuiInputTextCallback fCallback = nullptr)
	{
		PushStyleVar(ImGuiStyleVar_FramePadding, { H::Draw.Scale(8), H::Draw.Scale(8) });
		PushItemWidth(flWidth);
		ImVec2 vDrawPos = GetCursorPos() + GetDrawPos();

		bool bReturn = InputText(std::format("##{}", sLabel).c_str(), &sText, iFlags | ImGuiInputTextFlags_NoKeyboardNavigate, fCallback);
		ImVec2 vSize = GetItemRectSize();
		float flInset = H::Draw.Scale(0.5f) - 0.5f;
		GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(vSize.x - flInset, vSize.y - flInset), F::Render.Background2, 0.f, ImDrawFlags_None, H::Draw.Scale());

		if (sText.empty())
			GetWindowDrawList()->AddText(vDrawPos + GetStyle().FramePadding, F::Render.Inactive, sLabel);
		PopItemWidth();
		PopStyleVar();

		return bReturn;
	}

	inline void IconImage(const char* sIcon, ImVec4 tColor = { 1, 1, 1, -1 })
	{
		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		if (tColor.w >= 0.f)
			PushStyleColor(ImGuiCol_Text, tColor);
		PushFont(F::Render.IconFont);

		TextUnformatted(sIcon);

		PopFont();
		if (tColor.w >= 0.f)
			PopStyleColor();

		if (Transparent || Disabled)
			PopStyleVar();
	}

	inline bool IconButton(const char* sIcon, float flSize = H::Draw.Scale(24), ImVec4 tColor = { 1, 1, 1, -1 }, bool* pHovered = nullptr)
	{
		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		if (tColor.w >= 0.f)
			PushStyleColor(ImGuiCol_Text, tColor);
		PushFont(F::Render.IconFont);

		ImVec2 vOriginalPos = GetCursorPos();
		bool bReturn;
		if (MenuMode::DrawingMoonlit)
		{
			// Tiny HUD buttons cannot inherit the roomy menu's FramePadding.
			const auto pos = GetCursorScreenPos();
			bReturn = InvisibleButton(std::format("{}##{}:{}", sIcon, vOriginalPos.x, vOriginalPos.y).c_str(), {flSize, flSize});
			const float glyphSize = std::max(1.f, std::min(GetFontSize(), flSize - H::Draw.Scale(2)));
			const auto extent = GetFont()->CalcTextSizeA(glyphSize, FLT_MAX, 0.f, sIcon);
			GetWindowDrawList()->AddText(GetFont(), glyphSize, pos + (ImVec2(flSize, flSize) - extent) * .5f,
				GetColorU32(ImGuiCol_Text), sIcon);
		}
		else bReturn = Button(std::format("{}##{}:{}", sIcon, vOriginalPos.x, vOriginalPos.y).c_str(), { flSize, flSize });

		if (!Disabled && IsItemHovered() && GetMouseCursor() != ImGuiMouseCursor_Hand)
		{
			SetMouseCursor(ImGuiMouseCursor_Hand);

			ImColor tTransparent = GetStyle().Colors[ImGuiCol_Text];
			tTransparent.Value.w *= (IsMouseDown(ImGuiMouseButton_Left) ? 0.1f : 0.05f) * GetStyle().Alpha;
			ImDrawList* pDrawList = GetWindowDrawList();
			ImVec2 vDrawPos = GetDrawPos() + vOriginalPos + ImVec2(flSize / 2, flSize / 2);
			pDrawList->AddCircleFilled(vDrawPos, flSize / 2, tTransparent);
		}
		if (pHovered)
			*pHovered = IsItemHovered();
		PopFont();
		if (tColor.w >= 0.f)
			PopStyleColor();

		if (Transparent || Disabled)
			PopStyleVar();

		return Disabled ? false : bReturn;
	}

	inline bool CompactManagerIcon(const char* icon, float boxSize = 20.f)
	{
		const ImVec2 pos = GetCursorScreenPos();
		const float size = H::Draw.Scale(boxSize), glyphSize = H::Draw.Scale(16);
		const bool clicked = InvisibleButton(std::format("{}##{}:{}", icon, pos.x, pos.y).c_str(), { size, size });
		auto* draw = GetWindowDrawList();
		if (IsItemHovered()) { SetMouseCursor(ImGuiMouseCursor_Hand); draw->AddRectFilled(pos, pos + ImVec2(size, size), GetColorU32(F::Render.Background2.Value)); }
		draw->AddRect(pos, pos + ImVec2(size, size), GetColorU32(F::Render.Accent.Value));
		const ImVec2 extent = F::Render.IconFont->CalcTextSizeA(glyphSize, FLT_MAX, 0.f, icon);
		ImVec4 color = F::Render.Accent.Value;
		color.w *= Transparent || Disabled ? 0.5f : 1.f;
		draw->AddText(F::Render.IconFont, glyphSize, pos + (ImVec2(size, size) - extent) * 0.5f, GetColorU32(color), icon);
		return clicked && !Disabled;
	}

	inline bool FBeginPopup(const char* sLabel, float flOffset = 0.f, ImGuiWindowFlags iFlags = ImGuiWindowFlags_NoSavedSettings)
	{
		bool bReturn = BeginPopup(sLabel, iFlags | ImGuiWindowFlags_NoBackground);

		if (bReturn)
		{
			RenderBackground(F::Render.Background0p5, F::Render.Background2);

			if (flOffset)
				SetCursorPosY(GetCursorPosY() + H::Draw.Scale(flOffset));
		}

		return bReturn;
	}

	inline bool FBeginPopupModal(const char* sLabel, float flOffset = 0.f, bool* pOpen = nullptr, ImGuiWindowFlags iFlags = ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings)
	{
		bool bReturn = BeginPopupModal(sLabel, pOpen, iFlags | ImGuiWindowFlags_NoBackground);

		if (bReturn)
		{
			RenderBackground(F::Render.Background0p5, F::Render.Background2);

			if (flOffset)
				SetCursorPosY(GetCursorPosY() + H::Draw.Scale(flOffset));
		}

		return bReturn;
	}

	inline bool FPopupButton(const char* sLabel, ImVec2 vOffset = {}, float flOffset = 0.f, int iFlags = FButtonEnum::SameLine, const char* sIcon = nullptr)
	{
		if (iFlags & FButtonEnum::SameLine)
			SameLine(GetWindowWidth() - H::Draw.Scale(33));
		SetCursorPos(GetCursorPos() + vOffset * H::Draw.Scale());

		ImVec2 vIdealPosition = GetDrawPos() + ImVec2(0, GetCursorPosY() + H::Draw.Scale(23) + GetStyle().WindowPadding.y);
		ImVec2 vIdealSize = { GetWindowWidth(), 0 };

		if (!sIcon)
			sIcon = IsPopupOpen(sLabel) ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN;
		if (IconButton(sIcon))
			OpenPopup(sLabel);

		SetNextWindowPos(vIdealPosition, ImGuiCond_Appearing);
		SetNextWindowSize(vIdealSize, ImGuiCond_Appearing);
		return FBeginPopup(sLabel, flOffset);
	}

	inline bool FGroupPopupButton(const char* label)
	{
		const float size = H::Draw.Scale(12);
		const ImVec2 rowBottom = GetItemRectMax();
		const float panelWidth = GetWindowWidth();
		const float panelLeft = GetWindowPos().x;
		SameLine(GetWindowWidth() - GetStyle().WindowPadding.x - size - H::Draw.Scale(2));
		SetCursorPosY(GetCursorPosY() + H::Draw.Scale(3.5f));
		const ImVec2 pos = GetCursorScreenPos();
		const bool active = IsPopupOpen(label);
		PushID(label);
		const bool pressed = InvisibleButton("##Expand", { size, size });
		if (IsItemHovered()) SetMouseCursor(ImGuiMouseCursor_Hand);
		PopID();
		auto* draw = GetWindowDrawList();
		if (active || IsItemHovered()) draw->AddRectFilled(pos, pos + ImVec2(size, size), GetColorU32(F::Render.Background2.Value));
		const ImU32 accent = GetColorU32(F::Render.Accent.Value);
		draw->AddRect(pos, pos + ImVec2(size, size), accent);
		const float y1 = size * (active ? 0.6f : 0.4f), y2 = size * (active ? 0.4f : 0.6f);
		draw->AddLine(pos + ImVec2(size * 0.3f, y1), pos + ImVec2(size * 0.5f, y2), accent);
		draw->AddLine(pos + ImVec2(size * 0.5f, y2), pos + ImVec2(size * 0.7f, y1), accent);
		if (pressed) OpenPopup(label);
		SetNextWindowPos({ panelLeft, rowBottom.y + H::Draw.Scale(2) }, ImGuiCond_Appearing);
		SetNextWindowSize({ panelWidth, 0 }, ImGuiCond_Appearing);
		PushStyleVar(ImGuiStyleVar_WindowPadding, { H::Draw.Scale(6), H::Draw.Scale(4) });
		const bool open = BeginPopup(label, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground);
		PopStyleVar();
		if (open) RenderBackground(F::Render.Background0, F::Render.Accent);
		return open;
	}

	inline bool FSelectable(const char* sLabel, ImVec4* pColor, float flRounding = 0.f, bool bSelected = false, ImGuiSelectableFlags iFlags = ImGuiSelectableFlags_None, const ImVec2& vSize = {})
	{
		PushStyleVar(ImGuiStyleVar_FrameRounding, flRounding);
		if (pColor)
		{
			auto tColor = *pColor;
			PushStyleColor(ImGuiCol_HeaderHovered, tColor);
			tColor.x /= 1.1f; tColor.y /= 1.1f; tColor.z /= 1.1f;
			PushStyleColor(ImGuiCol_HeaderActive, tColor);
		}

		bool bReturn = Selectable(sLabel, bSelected, iFlags, vSize);

		if (pColor)
			PopStyleColor(2);
		PopStyleVar();

		return bReturn;
	}

	inline bool FSelectable(const char* sLabel, ImVec4 tColor = { 0.2f, 0.6f, 0.85f, 1.f }, float flRounding = 0.f, bool bSelected = false, ImGuiSelectableFlags iFlags = ImGuiSelectableFlags_None, const ImVec2& vSize = {})
	{
		return FSelectable(sLabel, &tColor, flRounding, bSelected, iFlags, vSize);
	}

	inline bool FBeginMenu(const char* sLabel, ImVec4* pColor, float flRounding = 0.f, bool bEnabled = true)
	{
		ImDrawList* pDrawList = GetWindowDrawList();
		ImVec2 vDrawPos = GetDrawPos();
		ImVec2 vOriginalPos = GetCursorPos();
		ImVec2 vPos = vOriginalPos + vDrawPos + ImVec2(GetWindowWidth() - H::Draw.Scale(30), H::Draw.Scale(-1));

		PushStyleVar(ImGuiStyleVar_FrameRounding, flRounding);
		if (pColor)
		{
			auto tColor = *pColor;
			PushStyleColor(ImGuiCol_HeaderHovered, tColor);
			tColor.x /= 1.1f; tColor.y /= 1.1f; tColor.z /= 1.1f;
			PushStyleColor(ImGuiCol_HeaderActive, tColor);
		}
		PushStyleColor(ImGuiCol_PopupBg, {});

		bool bReturn = BeginMenu(sLabel, bEnabled, false);

		PopStyleColor();
		if (pColor)
			PopStyleColor(2);
		PopStyleVar();
		if (bReturn)
			RenderBackground(F::Render.Background0p5, F::Render.Background2);

		pDrawList->AddText(F::Render.IconFont, F::Render.IconFont->LegacySize, vPos, F::Render.Inactive, ICON_MD_KEYBOARD_ARROW_RIGHT);
		return bReturn;
	}

	inline bool FBeginMenu(const char* sLabel, ImVec4 tColor = { 0.2f, 0.6f, 0.85f, 1.f }, float flRounding = 0.f, bool bEnabled = true)
	{
		return FBeginMenu(sLabel, &tColor, flRounding, bEnabled);
	}

	inline std::unordered_map<uint32_t, float> mLastHeights = {};
	inline std::vector<uint32_t> vStoredLabels = {};
	inline bool Section(const char* sLabel, float flPaddingMod = 0.f, float flMinHeight = 28.f, bool bForceHeight = false)
	{
		// Scope cached heights to this window/table, not every matching title.
		uint32_t uHash = GetID(sLabel);
		vStoredLabels.push_back(uHash);

		if (!bForceHeight && mLastHeights.contains(uHash) && mLastHeights[uHash] > flMinHeight)
			flMinHeight = mLastHeights[uHash];
		PushStyleVar(ImGuiStyleVar_CellPadding, { 0, 0 });

		bool bReturn = BeginChild(sLabel, { GetColumnWidth(), flMinHeight }, ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
		if (bReturn)
		{
			RenderBackground(F::Render.Background0, F::Render.Background2);
		}

		PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), MenuMode::DrawingMoonlit ? H::Draw.Scale(8) : 0.f });
		if (sLabel[0] != '#')
		{
			ImVec2 vOriginalPos = GetCursorPos();

			PushFont(F::Render.FontSmall);
			const ImVec2 titlePadding(H::Draw.Scale(3), H::Draw.Scale(2));
			const ImVec2 titleMin = GetCursorScreenPos();
			const std::string title = TruncateText(StripDoubleHash(sLabel),
				std::max(1.f, GetContentRegionAvail().x - titlePadding.x * 2));
			// Keep the existing divider/control geometry, but center the label in
			// the full header strip rather than offsetting it from content padding.
			const float textHeight = GetTextLineHeight();
			const ImVec2 titleMax = titleMin + ImVec2(0, textHeight + titlePadding.y * 2);
			// The section's outer frame supplies the header's top and sides.
			// Draw its bottom edge across the full section, beyond the content padding.
			// OuterRectClipped still respects the parent window/scroll viewport.
			auto* sectionWindow = GetCurrentWindow();
			auto* sectionDraw = GetWindowDrawList();
			const float borderInset = H::Draw.Scale(1);
			sectionDraw->PushClipRect(sectionWindow->OuterRectClipped.Min, sectionWindow->OuterRectClipped.Max, false);
			const float headerTop = sectionWindow->Pos.y + borderInset;
			const float textY = headerTop + (titleMax.y - headerTop - textHeight) * 0.5f;
			sectionDraw->AddText(GetFont(), GetFontSize(), ImVec2(titleMin.x + titlePadding.x, textY),
				GetColorU32(MenuTitleColour()), title.c_str());
			sectionDraw->AddLine(
				ImVec2(sectionWindow->Pos.x + borderInset, titleMax.y),
				ImVec2(sectionWindow->Pos.x + sectionWindow->Size.x - borderInset, titleMax.y),
				GetColorU32(ImGuiCol_Border));
			sectionDraw->PopClipRect();
			const float titleHeight = titleMax.y - titleMin.y;
			PopFont();

			SetCursorPos(vOriginalPos);
			DebugDummy({ 0, titleHeight + H::Draw.Scale((MenuMode::DrawingMoonlit ? 8 : 2) + flPaddingMod) });
		}
		else if (flPaddingMod)
			SetCursorPosY(GetCursorPosY() + H::Draw.Scale(flPaddingMod));

		return bReturn;
	}
	inline void EndSection()
	{
		uint32_t uHash = vStoredLabels.back();
		vStoredLabels.pop_back();
		auto* sectionWindow = GetCurrentWindow();
		const float flHeight = SectionLayout::ContentHeight(sectionWindow);
		if (!sectionWindow->SkipItems && flHeight > 0.f)
			mLastHeights[uHash] = flHeight;

		PopStyleVar();
		EndChild();
		PopStyleVar();
	}

	inline std::vector<WidgetWindow_t> WidgetTable(int iCount, float flHeight, std::vector<float> vWidths = {}, ImGuiChildFlags iWindowFlags = ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags iChildFlags = ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse, bool comfortable = false)
	{
		std::vector<WidgetWindow_t> vReturn = {};

		if (vWidths.empty())
		{
			for (int i = 0; i < iCount; i++)
				vWidths.push_back(GetWindowWidth() / iCount);
		}
		else if (vWidths.size() < iCount)
		{
			int iSize = int(vWidths.size());
			float flTotalWidth = std::reduce(vWidths.begin(), vWidths.end());
			int iCountLeft = iCount - iSize;
			for (int i = iSize; i < iCount; i++)
				vWidths.push_back((GetWindowWidth() - flTotalWidth) / iCountLeft);
		}

		flHeight += H::Draw.Scale(8);
		if (MenuMode::DrawingMoonlit && !comfortable)
			flHeight += GetStyle().WindowPadding.y * 2 + H::Draw.Scale(16);
		if (MenuMode::DrawingMoonlit && comfortable)
		{
			// Respect the containing section's inset instead of drawing over its header.
			const ImVec2 origin = GetCursorPos();
			const float available = GetContentRegionAvail().x, gap = H::Draw.Scale(14);
			const bool stacked = available < H::Draw.Scale(820) && iCount > 1;
			const float weight = std::reduce(vWidths.begin(), vWidths.end());
			float x = origin.x;
			for (int i = 0; i < iCount; ++i)
			{
				const float width = stacked ? available : (available - gap * (iCount - 1)) * vWidths[i] / weight;
				vReturn.emplace_back(std::format("{}", i), ImVec2(stacked ? origin.x : x, origin.y + (stacked ? i * (flHeight + gap) : 0.f)),
					ImVec2(width, flHeight), iWindowFlags, iChildFlags);
				x += width + gap;
			}
			return vReturn;
		}
		float flTotalWidth = GetStyle().WindowPadding.x / 2;
		for (int i = 0; i < iCount; i++)
		{
			float flWidth = vWidths[i] + GetStyle().WindowPadding.x * (iCount - 1) / iCount;
			vReturn.emplace_back(
				std::format("{}", i),
				ImVec2(flTotalWidth - GetStyle().WindowPadding.x / 2, GetCursorPos().y),
				ImVec2(flWidth, flHeight),
				iWindowFlags,
				iChildFlags
			);
			flTotalWidth += flWidth - GetStyle().WindowPadding.x;
		}

		return vReturn;
	}

	inline bool BeginWidgetTable(int iIndex, std::vector<WidgetWindow_t>& vTable, bool comfortable = false)
	{
		SetCursorPos(vTable[iIndex].m_vPos);
		if (MenuMode::DrawingMoonlit && comfortable) PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
		bool bReturn = BeginChild(vTable[iIndex].m_sName.c_str(), vTable[iIndex].m_vSize, vTable[iIndex].m_iWindowFlags, vTable[iIndex].m_iChildFlags);
		if (MenuMode::DrawingMoonlit && comfortable) PopStyleColor();

		if (bReturn && !(MenuMode::DrawingMoonlit && comfortable))
			SetCursorPosY(GetCursorPosY() - H::Draw.Scale(8));

		return bReturn;
	}

	// widgets
	inline bool FTabs(std::vector<std::vector<const char*>> vEntries, std::vector<int*> vVars, const ImVec2 vSize, const ImVec2 vPos, int iFlags = FTabsEnum::None, std::vector<std::vector<const char*>> vIcons = {}, ImVec2 vAllTextOffset = {}, ImVec2 vAllBarOffset = {}, ImVec2 vSubTextOffset = {}, ImVec2 vSubBarOffset = {}, float flBarSizeMod = 0.f, float flBarThickness = 1.f)
	{	// WOW fuck this
		if (!vIcons.empty() && vIcons.size() != vEntries.size())
		{
			IM_ASSERT_USER_ERROR(0, "FTabs() vIcons size mismatch to vEntries.");
			return false;
		}

		ImDrawList* pDrawList = GetWindowDrawList();
		bool bChanged = false;
		std::pair<int, int> paOriginal;
		{
			auto pVar1 = !vVars.empty() ? vVars[0] : nullptr;
			auto pVar2 = pVar1 && vEntries[*pVar1].size() > 1 && *pVar1 + 1 < vVars.size() ? vVars[*pVar1 + 1] : nullptr;
			paOriginal = { pVar1 ? *pVar1 : -1, pVar2 ? *pVar2 : -1 };
		}

		bool bIcons = !vIcons.empty();
		bool bVertical = iFlags & FTabsEnum::Vertical;
		bool bVerticalIcons = iFlags & FTabsEnum::VerticalIcons;
		bool bFit = iFlags & FTabsEnum::Fit;
		bool bReverse = iFlags & FTabsEnum::AlignReverse;
		int iAlign = iFlags & FTabsEnum::AlignLeft ? 1 : iFlags & FTabsEnum::AlignRight ? 2 : iFlags & FTabsEnum::AlignTop ? 3 : iFlags & FTabsEnum::AlignBottom ? 4 : 0;
		int iBar = iFlags & FTabsEnum::BarLeft ? 1 : iFlags & FTabsEnum::BarRight ? 2 : iFlags & FTabsEnum::BarTop ? 3 : iFlags & FTabsEnum::BarBottom ? 4 : bVertical ? 2 : 4;

		ImVec2 vOffset = vPos;
		for (size_t i = bReverse ? vEntries.size() - 1 : 0; i < vEntries.size(); (bReverse ? i-- : i++))
		{
			for (size_t j = bReverse ? vEntries[i].size() - 1 : 0; j < vEntries[i].size(); (bReverse ? j-- : j++))
			{
				if (j && i != paOriginal.first)
					continue;

				int iTabState = 0;
				if (vEntries[i].size() <= 1)
				{
					if (i == paOriginal.first)
						iTabState = 2;
				}
				else if (!j)
				{
					if (i == paOriginal.first)
						iTabState = 1;
				}
				else
				{
					if (i == paOriginal.first && j - 1 == paOriginal.second)
						iTabState = 2;
				}

				auto sEntry = vEntries[i][j];
				auto sIcon = i < vIcons.size() && j < vIcons[i].size() ? vIcons[i][j] : nullptr;
				int* pVar = nullptr;
				if (!vVars.empty())
				{
					if (!j)
						pVar = vVars[0];
					else if (i + 1 < vVars.size())
						pVar = vVars[i + 1];
				}

				ImVec2 vNewSize = vSize;
				if (bFit)
				{
					if (!bVertical)
						vNewSize.x += FCalcTextSize(StripDoubleHash(sEntry).c_str()).x + (sIcon && !bVerticalIcons ? IconSize(sIcon).x : 0.f);
					else
						vNewSize.y += FCalcTextSize(StripDoubleHash(sEntry).c_str()).y + (sIcon && bVerticalIcons ? IconSize(sIcon).x : 0.f);
				}
				if (bReverse)
				{
					if (!bVertical)
						vOffset.x -= vNewSize.x;
					else
						vOffset.y -= vNewSize.y;
				}
				ImVec2 vDrawPos = GetDrawPos() + vOffset;
				ImVec2 vCurTextOffset = vAllTextOffset + (j ? vSubTextOffset : ImVec2());
				ImVec2 vCurBarOffset = vAllBarOffset + (j ? vSubBarOffset : ImVec2());

				if (!iTabState)
					PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
				else if (iTabState == 2)
				{
					switch (iBar)
					{
					case 1: // left
						pDrawList->AddRectFilled(
							vDrawPos + vCurBarOffset + ImVec2(0, flBarSizeMod),
							vDrawPos + vCurBarOffset + ImVec2(H::Draw.Scale(flBarThickness), vNewSize.y - flBarSizeMod),
							F::Render.Accent
						);
						break;
					case 2: // right
						pDrawList->AddRectFilled(
							vDrawPos + vCurBarOffset + ImVec2(vNewSize.x - H::Draw.Scale(flBarThickness), flBarSizeMod),
							vDrawPos + vCurBarOffset + ImVec2(vNewSize.x, vNewSize.y - flBarSizeMod),
							F::Render.Accent
						);
						break;
					case 3: // top
						pDrawList->AddRectFilled(
							vDrawPos + vCurBarOffset + ImVec2(flBarSizeMod, 0),
							vDrawPos + vCurBarOffset + ImVec2(vNewSize.x - flBarSizeMod, H::Draw.Scale(flBarThickness)),
							F::Render.Accent
						);
						break;
					case 4: // bottom
						pDrawList->AddRectFilled(
							vDrawPos + vCurBarOffset + ImVec2(flBarSizeMod, vNewSize.y - H::Draw.Scale(flBarThickness)),
							vDrawPos + vCurBarOffset + ImVec2(vNewSize.x - flBarSizeMod, vNewSize.y),
							F::Render.Accent
						);
						break;
					}
				}

				SetCursorPos(vOffset);
				if (Button(std::format("##{}", sEntry).c_str(), vNewSize) && !iTabState && pVar)
				{
					*pVar = int(!j ? i : j - 1);
					bChanged = true;
					if (vStoredLabels.empty())
						mLastHeights.clear();
				}
				if (!Disabled && IsItemHovered())
					SetMouseCursor(ImGuiMouseCursor_Hand);

				ImVec2 vOriginalPos = GetCursorPos();
				std::string sStripped = StripDoubleHash(sEntry);

				ImVec2 vTextSize = FCalcTextSize(sStripped.c_str());
				ImVec2 vIconSize = { H::Draw.Scale(16), H::Draw.Scale(16) }; //IconSize(vIcons[i]);

				ImVec2 vTextOffset, vIconOffset;
				if (bIcons)
				{
					if (!bVerticalIcons)
					{
						switch (iAlign)
						{
						case 0: // center
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2 + vIconSize.x / 1.5f, (vNewSize.y - vTextSize.y) / 2 };
							vIconOffset = { (vNewSize.x - vTextSize.x) / 2 - vIconSize.x / 1.5f, (vNewSize.y - vIconSize.y) / 2 };
							break;
						case 1: // left
							vTextOffset = { vIconSize.x * 1.5f, (vNewSize.y - vTextSize.y) / 2 };
							vIconOffset = { 0.f, (vNewSize.y - vIconSize.y) / 2 };
							break;
						case 2: // right
							vTextOffset = { vNewSize.x - vTextSize.x, (vNewSize.y - vTextSize.y) / 2 };
							vIconOffset = { vNewSize.x - vTextSize.x - vIconSize.x * 1.5f, (vNewSize.y - vIconSize.y) / 2 };
							break;
						case 3: // top
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2 + vIconSize.x / 1.5f, { (vIconSize.y - vTextSize.y) / 2 } };
							vIconOffset = { (vNewSize.x - vTextSize.x) / 2 - vIconSize.x / 1.5f, 0.f };
							break;
						case 4: // bottom
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2 + vIconSize.x / 1.5f, vNewSize.y - vTextSize.y - (vIconSize.y - vTextSize.y) / 2 };
							vIconOffset = { (vNewSize.x - vTextSize.x) / 2 - vIconSize.x / 1.5f, vNewSize.y - vIconSize.y };
							break;
						}
					}
					else
					{
						switch (iAlign)
						{
						case 0: // center
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2, (vNewSize.y - vTextSize.y) / 2 + vIconSize.y / 1.5f };
							vIconOffset = { (vNewSize.x - vIconSize.x) / 2, (vNewSize.y - vTextSize.y) / 2 - vIconSize.y / 1.5f };
							break;
						case 1: // left
							vTextOffset = { 0.f, (vNewSize.y - vTextSize.y) / 2 + vIconSize.y / 1.5f };
							vIconOffset = { (vTextSize.x - vIconSize.x) / 2, (vNewSize.y - vTextSize.y) / 2 - vIconSize.y / 1.5f };
							break;
						case 2: // right
							vTextOffset = { vNewSize.x - vTextSize.x, (vNewSize.y - vTextSize.y) / 2 + vIconSize.y / 1.5f };
							vIconOffset = { vNewSize.x - (vTextSize.x + vIconSize.x) / 2, (vNewSize.y - vTextSize.y) / 2 - vIconSize.y / 1.5f };
							break;
						case 3: // top
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2, vIconSize.y * 1.5f };
							vIconOffset = { (vNewSize.x - vIconSize.x) / 2, 0.f };
							break;
						case 4: // bottom
							vTextOffset = { (vNewSize.x - vTextSize.x) / 2, vNewSize.y - vTextSize.y };
							vIconOffset = { (vNewSize.x - vIconSize.x) / 2, vNewSize.y - vTextSize.y - vIconSize.y * 1.5f };
							break;
						}
					}
				}
				else
				{
					switch (iAlign)
					{
					case 0: // center
						vTextOffset = { (vNewSize.x - vTextSize.x) / 2, (vNewSize.y - vTextSize.y) / 2 };
						break;
					case 1: // left
						vTextOffset = { 0.f, (vNewSize.y - vTextSize.y) / 2 };
						break;
					case 2: // right
						vTextOffset = { vNewSize.x - vTextSize.x, (vNewSize.y - vTextSize.y) / 2 };
						break;
					case 3: // top
						vTextOffset = { (vNewSize.x - vTextSize.x) / 2, 0.f };
						break;
					case 4: // bottom
						vTextOffset = { (vNewSize.x - vTextSize.x) / 2, vNewSize.y - vTextSize.y };
						break;
					}
				}

				SetCursorPos(vOffset + vCurTextOffset + vTextOffset);
				TextUnformatted(sStripped.c_str());

				if (sIcon)
				{
					SetCursorPos(vOffset + vCurTextOffset + vIconOffset);
					IconImage(sIcon);
				}

				SetCursorPos(vOriginalPos);

				if (!iTabState)
					PopStyleColor();

				if (!bReverse)
				{
					if (!bVertical)
						vOffset.x += vNewSize.x;
					else
						vOffset.y += vNewSize.y;
				}
			}
		}

		return bChanged;
	}

	inline bool FTabs(std::vector<const char*> vEntries, int* pVar, const ImVec2 vSize, const ImVec2 vPos, int iFlags = FTabsEnum::None, std::vector<const char*> vIcons = {}, ImVec2 vAllTextOffset = {}, ImVec2 vAllBarOffset = {}, ImVec2 vSubTextOffset = {}, ImVec2 vSubBarOffset = {}, float flBarSizeMod = 0.f, float flBarThickness = 1.f)
	{
		std::vector<std::vector<const char*>> vNewEntries;
		for (auto& sEntry : vEntries)
			vNewEntries.push_back({ sEntry });
		std::vector<std::vector<const char*>> vNewIcons;
		for (auto& sIcon : vIcons)
			vNewIcons.push_back({ sIcon });

		return FTabs(vNewEntries, { pVar }, vSize, vPos, iFlags, vNewIcons, vAllTextOffset, vAllBarOffset, vSubTextOffset, vSubBarOffset, flBarSizeMod, flBarThickness);
	}

	inline bool FButton(const char* sLabel, int iFlags = FButtonEnum::None, ImVec2 vSize = { 0, 30 }, int iSizeOffset = 0, ImFont* pFont = nullptr, bool* pHovered = nullptr)
	{
		if (pFont)
			PushFont(pFont);

		std::string sLabel2 = sLabel;
		if (!(iFlags & FButtonEnum::NoUpper))
		{
			std::transform(sLabel2.begin(), sLabel2.end(), sLabel2.begin(), [](unsigned char c) { return char(std::toupper(c)); });
			sLabel = sLabel2.c_str();
		}

		if (!vSize.x)
		{
			vSize.x = GetWindowWidth();
			if (iFlags & (FButtonEnum::Left | FButtonEnum::Right))
				vSize.x = vSize.x / 2 - GetStyle().WindowPadding.x * 1.5f;
			else if (iFlags & FButtonEnum::Fit)
				vSize.x = FCalcTextSize(sLabel).x + H::Draw.Scale(vSize.y - 12);
			else
				vSize.x -= GetStyle().WindowPadding.x * 2;
			if (MenuMode::DrawingMoonlit && (iFlags & FButtonEnum::Right))
				SameLine(vSize.x + GetStyle().WindowPadding.x * 2);
			else if (iFlags & FButtonEnum::SameLine)
				SameLine();
			else if (iFlags & FButtonEnum::Right)
				SetCursorPosX(vSize.x + 20);
		}
		else
		{
			vSize.x = H::Draw.Scale(vSize.x);
			if (iFlags & FButtonEnum::SameLine)
				SameLine();
		}
		vSize.x += H::Draw.Scale(iSizeOffset); vSize.y = H::Draw.Scale(vSize.y);

		ImVec2 vOriginalPos = GetCursorPos();
		const float topPadding = iFlags & FButtonEnum::Compact ? H::Draw.Scale(3) : GetStyle().WindowPadding.y;
		DebugShift({ 0, topPadding });

		ImColor tColor = !Disabled && !Transparent ? F::Render.Accent : F::Render.Background2;
		ImVec2 vDrawPos = GetCursorPos() + GetDrawPos();
		bool bClicked = IsMouseDown(ImGuiMouseButton_Left);
		bool bWithin = !Disabled && (IsWindowHovered() || bClicked) && IsMouseWithin(vDrawPos.x, vDrawPos.y, vSize.x, vSize.y);

		PushStyleColor(ImGuiCol_Text, tColor.Value);
		bool bReturn = Button(sLabel, vSize);
		float flInset = H::Draw.Scale(0.5f) - 0.5f;
		GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), tColor, 0.f, ImDrawFlags_None, H::Draw.Scale());
		if (bWithin)
		{
			if (bClicked)
				tColor.Value.w /= 10;
			else
				tColor.Value.w /= 20;
			flInset = H::Draw.Scale();
			GetWindowDrawList()->AddRectFilled(vDrawPos + ImVec2(flInset, flInset), vDrawPos + vSize - ImVec2(flInset, flInset), tColor, 0.f);
		}
		PopStyleColor();

		if (!Disabled && IsItemHovered())
			SetMouseCursor(ImGuiMouseCursor_Hand);
		if (pHovered)
			*pHovered = IsItemHovered();

		SetCursorPos(vOriginalPos);
		AddRowSize(vOriginalPos, vSize + ImVec2(0, topPadding));
		DebugDummy({ vSize.x, GetRowSize(vSize.y + topPadding) });

		if (pFont)
			PopFont();

		return Disabled ? false : bReturn;
	}

	inline bool FToggle(const char* sLabel, bool* pVar, int iFlags = FToggleEnum::None, bool* pHovered = nullptr)
	{
		if (Transparent || Disabled) PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);
		ImVec2 size = { GetWindowWidth() - GetStyle().WindowPadding.x * 2, 0 };
		if (iFlags & (FToggleEnum::Left | FToggleEnum::Right))
			size.x = GetWindowWidth() / 2 - GetStyle().WindowPadding.x * 1.5f;
		if (iFlags & FToggleEnum::Right) SameLine(size.x + GetStyle().WindowPadding.x * 2);
		const ImVec2 origin = GetCursorPos();
		auto lines = WrapText(StripDoubleHash(sLabel), size.x - H::Draw.Scale(20));
		const int count = std::min(int(lines.size()), 2);
		const float textHeight = GetTextLineHeight();
		size.y = std::max(H::Draw.Scale(19), count * textHeight + H::Draw.Scale(4));
		if (MenuMode::DrawingMoonlit) size.y = std::max(H::Draw.Scale(36), count * textHeight + H::Draw.Scale(12));
		const bool clicked = InvisibleButton(std::format("##{}", sLabel).c_str(), size);
		if (pHovered) *pHovered = IsItemHovered();
		const bool changed = clicked && !Disabled;
		if (changed) *pVar = !*pVar;
		const bool checked = (iFlags & FToggleEnum::Invert) ? !*pVar : *pVar;
		if (IsItemHovered() && !Disabled) SetMouseCursor(ImGuiMouseCursor_Hand);
		auto* draw = GetWindowDrawList();
		const ImVec2 pos = GetDrawPos() + origin;
		const float box = H::Draw.Scale(MenuMode::DrawingMoonlit ? 16 : 12);
		const ImVec2 boxPos = pos + ImVec2(size.x - box - H::Draw.Scale(2), (size.y - box) / 2);
		draw->AddRect(boxPos, boxPos + ImVec2(box, box), GetColorU32(F::Render.Accent.Value));
		if (checked) draw->AddRectFilled(boxPos + ImVec2(2, 2), boxPos + ImVec2(box - 2, box - 2), GetColorU32(F::Render.Accent.Value));
		for (int i = 0; i < count; ++i)
		{
			SetCursorPos(origin + ImVec2(H::Draw.Scale(2), (MenuMode::DrawingMoonlit ? (size.y - count * textHeight) * .5f : H::Draw.Scale(2)) + i * textHeight));
			PushStyleColor(ImGuiCol_Text, (checked ? F::Render.Active : F::Render.Inactive).Value);
			TextUnformatted(lines[i].c_str());
			PopStyleColor();
		}
		SetCursorPos(origin);
		AddRowSize(origin, size);
		DebugDummy({ size.x, GetRowSize(size.y) });
		if (Transparent || Disabled) PopStyleVar();
		return changed;
	}

	inline bool FToggle(const char* sLabel, int* pVar, int iBit, int iFlags = FToggleEnum::None, bool* pHovered = nullptr)
	{
		bool bActive = *pVar & iBit;
		if (FToggle(sLabel, &bActive, iFlags, pHovered))
		{
			if (bActive)
				*pVar |= iBit;
			else
				*pVar &= ~iBit;
			return true;
		}
		return false;
	}

	inline bool FSlider(const char* sLabel, float* pVar1, float* pVar2, float flMin, float flMax, float flStep = 1.f, const char* fmt = "%g", int iFlags = FSliderEnum::None, bool* pHovered = nullptr)
	{
		auto uHash = FNV1A::Hash32Const(sLabel);

		ImDrawList* pDrawList = GetWindowDrawList();
		float flOriginal1 = *pVar1, flOriginal2 = pVar2 ? *pVar2 : 0.f;

		static std::unordered_map<uint32_t, std::pair<float, float>> mStaticVars = {};
		if (!ActiveMap[uHash])
			mStaticVars[uHash] = { flOriginal1, flOriginal2 };

		// guard against a zero step or an empty range, which would otherwise divide by zero
		bool bStep = flStep > 0.f;
		float flRange = flMax != flMin ? flMax - flMin : 1.f;
		float& flSVar1 = mStaticVars[uHash].first, &flSVar2 = mStaticVars[uHash].second;

		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		ImVec2 vSize;
		bool bFull = !(iFlags & (FSliderEnum::Left | FSliderEnum::Right));

		vSize.x = GetWindowWidth();
		if (!bFull)
			vSize.x = vSize.x / 2 - GetStyle().WindowPadding.x * 1.5f;
		else
			vSize.x -= GetStyle().WindowPadding.x * 2;
		if (iFlags & FSliderEnum::Right)
			SameLine(vSize.x + GetStyle().WindowPadding.x * 2);

		ImVec2 vOriginalPos = GetCursorPos(), vDrawPos = GetDrawPos();
		PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);

		static std::unordered_map<uint32_t, float> mEntryWidth = {};
		float& flEntryWidth = mEntryWidth[FNV1A::Hash32(sLabel)];
#ifdef ALTERNATE_FULL_SLIDER
		auto vWrapped = WrapText(StripDoubleHash(sLabel), bFull ? vSize.x / 2 - H::Draw.Scale(24) : vSize.x - flEntryWidth - H::Draw.Scale(20));
#else
		auto vWrapped = WrapText(StripDoubleHash(sLabel), vSize.x - H::Draw.Scale(14) - flEntryWidth);
#endif
		int iWraps = std::min(int(vWrapped.size()), 2); // prevent too many wraps
#ifdef ALTERNATE_FULL_SLIDER
		vSize.y = H::Draw.Scale(H::Draw.Scale(bFull ? 6 : 14) + 18 * iWraps);
#else
		vSize.y = H::Draw.Scale(14 + 18 * iWraps);
#endif

		if (MenuMode::DrawingMoonlit) vSize.y = iWraps * GetTextLineHeight() + H::Draw.Scale(30);
		for (size_t i = 0; i < iWraps; i++)
		{
#ifdef ALTERNATE_FULL_SLIDER
			SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(6), H::Draw.Scale((bFull ? 5 : 3) + 18 * i)));
#else
			SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(6), H::Draw.Scale(3 + 18 * i)));
#endif
			if (MenuMode::DrawingMoonlit)
				SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(6), H::Draw.Scale(3) + GetTextLineHeight() * i));
			TextColored(MenuTitleColour(), "%s", vWrapped[i].c_str());
		}

#ifdef ALTERNATE_FULL_SLIDER
		float flTextY = vOriginalPos.y + H::Draw.Scale(bFull ? -4 + 9 * iWraps : -15 + 18 * iWraps);
#else
		float flTextY = vOriginalPos.y + H::Draw.Scale(-15 + 18 * iWraps);
#endif
		if (MenuMode::DrawingMoonlit) flTextY = vOriginalPos.y + H::Draw.Scale(3);
		{
			auto uHash2 = FNV1A::Hash32Const(std::format("{}## Text", sLabel).c_str());

			static std::string sText, sInput;
			if (!ActiveMap[uHash2])
				sText = pVar2 ? FormatText(fmt, flSVar1, flSVar2) : FormatText(fmt, flSVar1);
			else
			{
				SetCursorPos({ -1000, flTextY }); // lol
				SetKeyboardFocusHere();
				InputText("##SliderText", &sInput, ImGuiInputTextFlags_CharsDecimal); sText = sInput;

				bool bEnter = U::KeyHandler.Pressed(VK_RETURN);
				if (bEnter)
				{
					try
					{
						bool bVar1 = ActiveMap[uHash2] == 1;
						float& pVar = bVar1 ? flSVar1 : flSVar2;

						pVar = sText.length() ? std::stof(sText) : 0.f;
						if (pVar2)
						{
							if (bVar1)
								pVar = std::min(pVar, *pVar2 - flStep);
							else
								pVar = std::max(pVar, *pVar1 + flStep);
						}
						if (!(iFlags & FSliderEnum::Precision) && bStep)
							pVar = flMin + (pVar - flMin) - fnmodf(pVar - flMin - flStep / 2, flStep) + flStep / 2;
						if (iFlags & FSliderEnum::Clamp)
							pVar = std::clamp(pVar, flMin, flMax);
						else if (iFlags & FSliderEnum::Min)
							pVar = std::max(pVar, flMin);
						else if (iFlags & FSliderEnum::Max)
							pVar = std::min(pVar, flMax);

						*pVar1 = flSVar1;
						if (pVar2)
							*pVar2 = flSVar2;
					}
					catch (...) {}
				}
				if (bEnter || IsMouseClicked(ImGuiMouseButton_Left) || U::KeyHandler.Pressed(VK_ESCAPE))
					ActiveMap[uHash2] = false;
			}
			float flWidth = FCalcTextSize(sText.c_str()).x;
#ifdef ALTERNATE_FULL_SLIDER
			if (bFull)
				SetCursorPos({ vOriginalPos.x + vSize.x - H::Draw.Scale(36), flTextY });
			else
				SetCursorPos({ vOriginalPos.x + vSize.x - flWidth - H::Draw.Scale(6), flTextY });
#else
				SetCursorPos({ vOriginalPos.x + vSize.x - flWidth - H::Draw.Scale(6), flTextY });
#endif

			ImVec2 vOriginalPos2 = GetCursorPos();
			flEntryWidth = FCalcTextSize(sText.c_str()).x;
			TextUnformatted(sText.c_str());
			if (!Disabled)
			{
				if (!Disabled && IsItemHovered() && IsWindowHovered())
					SetMouseCursor(ImGuiMouseCursor_TextInput);
				if (ActiveMap[uHash2])
					pDrawList->AddRectFilled(vDrawPos + vOriginalPos2 + ImVec2(0, H::Draw.Scale(14)), vDrawPos + vOriginalPos2 + ImVec2(flWidth, H::Draw.Scale(15)), GetColorU32(ImVec4(Workspace::BorderChannel(0), Workspace::BorderChannel(1), Workspace::BorderChannel(2), 1.f)));
				else if (IsItemClicked())
				{
					float* pVar = !pVar2 || GetMousePos().x - vDrawPos.x - vOriginalPos2.x < flWidth / 2 ? pVar1 : pVar2;
					sInput = std::format("{}", *pVar); // would use to_string but i don't like its formatting
					ActiveMap[uHash2] = pVar == pVar1 ? 1 : 2;
				}
			}
		}

		vDrawPos += vOriginalPos;
#ifdef ALTERNATE_FULL_SLIDER
		ImVec2 vMins = { vSize.x / 2 - H::Draw.Scale(10), vSize.y / 2 - H::Draw.Scale(1) }, vMaxs = { vSize.x - H::Draw.Scale(50), vSize.y / 2 + H::Draw.Scale(1) };
		if (!bFull)
			vMins = { H::Draw.Scale(6), vSize.y - H::Draw.Scale(8) }, vMaxs = { vSize.x - H::Draw.Scale(6), vSize.y - H::Draw.Scale(6) };
#else
		ImVec2 vMins = { H::Draw.Scale(6), vSize.y - H::Draw.Scale(8) }, vMaxs = { vSize.x - H::Draw.Scale(6), vSize.y - H::Draw.Scale(6) };
#endif
		ImColor tAccent = F::Render.Accent, tMuted = tAccent, tWashed = tAccent, tTransparent = tAccent;
		if (MenuMode::DrawingMoonlit)
		{
			vMins.y = vSize.y - H::Draw.Scale(12);
			vMaxs.y = vSize.y - H::Draw.Scale(8);
		}
		{
			float flA = GetStyle().Alpha;
			tAccent.Value.w *= flA, tMuted.Value.w *= 0.8f * flA, tWashed.Value.w *= 0.4f * flA, tTransparent.Value.w *= 0.1f * flA;
		}

		bool bWithin = IsWindowHovered() && IsMouseWithin(vDrawPos.x + vMins.x - H::Draw.Scale(6), vDrawPos.y + vMins.y - H::Draw.Scale(6), (vMaxs.x - vMins.x) + H::Draw.Scale(12), (vMaxs.y - vMins.y) + H::Draw.Scale(12));
		if (!Disabled && bWithin)
			SetMouseCursor(ImGuiMouseCursor_Hand);
		ImVec2 vMouse = GetMousePos();
		float flMousePerc = (vMouse.x - (vDrawPos.x + vMins.x)) / ((vDrawPos.x + vMaxs.x) - (vDrawPos.x + vMins.x)) + (flStep / 2) / flRange;
		if (pVar2)
		{
			float flLowerPerc = std::clamp((flSVar1 - flMin) / flRange, 0.f, 1.f), flUpperPerc = std::clamp((flSVar2 - flMin) / flRange, 0.f, 1.f);
			float flLowerPos = vMins.x + (vMaxs.x - vMins.x) * flLowerPerc, flUpperPos = vMins.x + (vMaxs.x - vMins.x) * flUpperPerc;

			AddSteppedRect(vDrawPos, vMins, vMaxs, vMins, { flLowerPos, vMaxs.y }, flMin, flMax, flStep, tWashed, tMuted, H::Draw.Scale(2));
			AddSteppedRect(vDrawPos, vMins, vMaxs, { flLowerPos, vMins.y }, { flUpperPos, vMaxs.y }, flMin, flMax, flStep, tAccent, tWashed, H::Draw.Scale(2));
			AddSteppedRect(vDrawPos, vMins, vMaxs, { flUpperPos, vMins.y }, vMaxs, flMin, flMax, flStep, tWashed, tMuted, H::Draw.Scale(2));
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flLowerPos, vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), vDrawPos + ImVec2(flLowerPos, vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), tAccent);
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flUpperPos, vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), vDrawPos + ImVec2(flUpperPos, vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), tAccent);

			if (!Disabled)
			{
				if (bWithin && !ActiveMap[uHash])
				{
					int iVar = vMouse.x - vDrawPos.x < (flLowerPos + flUpperPos) / 2 ? 1 : 2;
					if (IsMouseClicked(ImGuiMouseButton_Left))
						ActiveMap[uHash] = iVar;
					pDrawList->AddRectFilled(vDrawPos + ImVec2((iVar == 1 ? flLowerPos : flUpperPos), vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), vDrawPos + ImVec2((iVar == 1 ? flLowerPos : flUpperPos), vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), tTransparent);
				}
				else if (ActiveMap[uHash] && IsMouseDown(ImGuiMouseButton_Left))
				{
					bool bVar1 = ActiveMap[uHash] == 1;
					float& flVar = bVar1 ? flSVar1 : flSVar2;
					flVar = flMin + (flMax - flMin) * flMousePerc;
					flVar = std::clamp(bStep ? flVar - fnmodf(flVar - flMin, flStep) : flVar, !bVar1 ? flSVar1 + flStep : flMin, bVar1 ? flSVar2 - flStep : flMax);
					pDrawList->AddRectFilled(vDrawPos + ImVec2((bVar1 ? flLowerPos : flUpperPos), vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), vDrawPos + ImVec2((bVar1 ? flLowerPos : flUpperPos), vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), tTransparent);
				}
				else
					ActiveMap[uHash] = false;

				if (iFlags & FSliderEnum::NoAutoUpdate ? !ActiveMap[uHash] : true)
				{
					*pVar1 = flSVar1;
					*pVar2 = flSVar2;
				}
			}
		}
		else
		{
			float flPercent = std::clamp((flSVar1 - flMin) / flRange, 0.f, 1.f);
			float flPos = vMins.x + (vMaxs.x - vMins.x) * flPercent;

			AddSteppedRect(vDrawPos, vMins, vMaxs, vMins, { flPos, vMaxs.y }, flMin, flMax, flStep, tAccent, tWashed, H::Draw.Scale(2));
			AddSteppedRect(vDrawPos, vMins, vMaxs, { flPos, vMins.y }, vMaxs, flMin, flMax, flStep, tWashed, tMuted, H::Draw.Scale(2));
			pDrawList->AddRectFilled(vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(3), H::Draw.Scale(3)), tAccent);

			if (!Disabled)
			{
				if (bWithin && !ActiveMap[uHash])
				{
					if (IsMouseClicked(ImGuiMouseButton_Left))
						ActiveMap[uHash] = 1;
					pDrawList->AddRectFilled(vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), tTransparent);
				}
				else if (ActiveMap[uHash] && IsMouseDown(ImGuiMouseButton_Left))
				{
					flSVar1 = flMin + (flMax - flMin) * flMousePerc;
					flSVar1 = std::clamp(bStep ? flSVar1 - fnmodf(flSVar1 - flMin, flStep) : flSVar1, flMin, flMax);
					pDrawList->AddRectFilled(vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) - ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), vDrawPos + ImVec2(flPos, vMins.y + H::Draw.Scale(1)) + ImVec2(H::Draw.Scale(5), H::Draw.Scale(5)), tTransparent);
				}
				else
					ActiveMap[uHash] = false;

				if (iFlags & FSliderEnum::NoAutoUpdate ? !ActiveMap[uHash] : true)
					*pVar1 = flSVar1;
			}
		}

		PopStyleColor();
		SetCursorPos(vOriginalPos + vMins - ImVec2(H::Draw.Scale(6), H::Draw.Scale(6)));
		// Input only: a normal Button paints its hover/active fill over the track drawn above.
		InvisibleButton("##", { vMaxs.x - vMins.x + H::Draw.Scale(12), H::Draw.Scale(14) });
		if (!MenuMode::DrawingMoonlit) GetWindowDrawList()->AddRect(GetItemRectMin(), GetItemRectMax(), GetColorU32(ImGuiCol_Border));
		SetCursorPos(vOriginalPos);
		AddRowSize(vOriginalPos, vSize);
		DebugDummy({ vSize.x, GetRowSize(vSize.y) });

		if (pHovered)
			*pHovered = IsItemHovered();

		if (Transparent || Disabled)
			PopStyleVar();

		return *pVar1 != flOriginal1 || pVar2 && *pVar2 != flOriginal2;
	}

	inline bool FSlider(const char* sLabel, int* pVar1, int* pVar2, int iMin, int iMax, int iStep = 1, const char* fmt = "%i", int iFlags = FSliderEnum::None, bool* pHovered = nullptr)
	{
		// replace incorrect formats as it will be converted to float
		std::string sReplace = fmt;

		std::string sFrom = "%d", sTo = "%g";
		auto iFind = sReplace.find(sFrom);
		while (iFind != std::string::npos)
		{
			sReplace.replace(iFind, sFrom.length(), sTo);
			iFind = sReplace.find(sFrom);
		}
		sFrom = "%i";
		iFind = sReplace.find(sFrom);
		while (iFind != std::string::npos)
		{
			sReplace.replace(iFind, sFrom.length(), sTo);
			iFind = sReplace.find(sFrom);
		}

		fmt = sReplace.c_str();

		float flRedir1 = *pVar1; float flRedir2 = pVar2 ? *pVar2 : 0;
		bool bReturn = FSlider(sLabel, &flRedir1, pVar2 ? &flRedir2 : nullptr, iMin, iMax, iStep, fmt, iFlags, pHovered);
		*pVar1 = flRedir1; if (pVar2) *pVar2 = flRedir2;
		return bReturn;
	}

	inline bool FSlider(const char* sLabel, float* pVar, float flMin, float flMax, float flStep = 1.f, const char* fmt = "%g", int iFlags = FSliderEnum::None, bool* pHovered = nullptr)
	{
		return FSlider(sLabel, pVar, nullptr, flMin, flMax, flStep, fmt, iFlags, pHovered);
	}

	inline bool FSlider(const char* sLabel, int* pVar, int iMin, int iMax, int iStep = 1, const char* fmt = "%i", int iFlags = FSliderEnum::None, bool* pHovered = nullptr)
	{
		return FSlider(sLabel, pVar, nullptr, iMin, iMax, iStep, fmt, iFlags, pHovered);
	}

	inline bool FBeginCompactCombo(const char* label, const char* preview, ImGuiComboFlags flags)
	{
		auto* ownerDraw = GetWindowDrawList();
		const ImVec2 framePos = GetCursorScreenPos();
		const ImVec2 frameSize(CalcItemWidth(), GetFrameHeight());
		// Selectable extends half the eight-unit row spacing below its content.
		// Matching popup padding to that edge avoids an empty footer.
		PushStyleVar(ImGuiStyleVar_WindowPadding, { GetStyle().WindowPadding.x, H::Draw.Scale(4) });
		const bool open = BeginCombo(label, preview, flags);
		PopStyleVar();
		if (open) ownerDraw->AddRect(framePos, framePos + frameSize, GetColorU32(F::Render.Accent.Value));
		return open;
	}

	inline void FFinishCompactComboLayout()
	{
		// Overlay labels restore the cursor to the next row, beyond actual content.
		// Submit a zero-size item at the existing content edge, not at that cursor:
		// this validates the layout without adding a blank footer.
		auto* window = GetCurrentWindow();
		SetCursorScreenPos({ window->DC.CursorStartPos.x, window->DC.CursorMaxPos.y });
		Dummy({ 0, 0 });
	}

	// Compact bordered options, scoped to dropdowns (not context menus).
	inline void FDropdownIcon(const char* icon, ImVec4 color = { 1, 1, 1, -1 })
	{
		// Decorative glyphs belong to the selectable row; their font line box
		// must not extend popup content below the final option.
		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);
		if (color.w >= 0.f)
			PushStyleColor(ImGuiCol_Text, color);
		PushFont(F::Render.IconFont);
		GetWindowDrawList()->AddText(GetFont(), GetFontSize(), GetCursorScreenPos(), GetColorU32(ImGuiCol_Text), icon);
		PopFont();
		if (color.w >= 0.f)
			PopStyleColor();
		if (Transparent || Disabled)
			PopStyleVar();
	}

	inline bool FDropdownSelectable(const char* label, ImVec4* color, float rounding = 0.f, bool selected = false, ImGuiSelectableFlags flags = ImGuiSelectableFlags_None, const ImVec2& size = {})
	{
		const bool pressed = FSelectable(label, color, rounding, selected, flags, size);
		GetWindowDrawList()->AddRect(GetItemRectMin(), GetItemRectMax(), GetColorU32(ImGuiCol_Border));
		return pressed;
	}

	inline float AttachedDropdownWidth = 0.f;
	inline ImVec2 AttachedDropdownOrigin;
	inline float AttachedDropdownHeight = 0.f;
	inline constexpr int AttachedColorPicker = 1 << 9;

	inline float CompactDropdownHeight(bool hasTitle)
	{
		const float valueHeight = GetTextLineHeight();
		PushFont(F::Render.FontSmall);
		const float labelHeight = GetTextLineHeight();
		PopFont();
		if (MenuMode::DrawingMoonlit)
			return hasTitle ? labelHeight + valueHeight + H::Draw.Scale(20) : valueHeight + H::Draw.Scale(16);
		return hasTitle ? std::max(H::Draw.Scale(32), labelHeight + valueHeight + H::Draw.Scale(8))
			: std::max(H::Draw.Scale(20), valueHeight + H::Draw.Scale(6));
	}

	inline bool FDropdown(const char* sLabel, int* pVar, std::vector<const char*> vEntries, std::vector<int> vValues = {}, int iFlags = FDropdownEnum::None, int iSizeOffset = 0, const char* sDefaultPreview = "None", bool* pHovered = nullptr, int* pModified = nullptr, std::function<void()> rowAccessory = {}, int accessoryValue = 0, std::function<void()> extraRows = {}, std::vector<const char*> extraPreview = {})
	{
		// Consume once: bind-editor popups must not inherit the parent row's inset.
		const float leadingWidth = AttachedDropdownWidth;
		AttachedDropdownWidth = 0.f;
		bool bReturn = false;

		if (vValues.empty())
		{
			int i = 0; for (auto& sEntry : vEntries)
			{
				if (FNV1A::Hash32(sEntry) == FNV1A::Hash32Const("##Divider"))
					continue;

				vValues.push_back(iFlags & FDropdownEnum::Multi ? 1 << i : i);
				i++;
			}
		}
		if (vValues.size() != std::count_if(vEntries.begin(), vEntries.end(), [](auto sEntry) { return FNV1A::Hash32(sEntry) != FNV1A::Hash32Const("##Divider"); }))
		{
			IM_ASSERT_USER_ERROR(0, "FDropdown() vValues size mismatch to vEntries.");
			return bReturn;
		}

		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		bool bTitle = sLabel[0] != '#';

		if (!(iFlags & FDropdownEnum::NoSanitization) && !vValues.empty())
		{
			if (!(iFlags & FDropdownEnum::Multi))
			{
				bool bFound = std::find(vValues.begin(), vValues.end(), *pVar) != vValues.end();
				if (!bFound)
					*pVar = vValues.front();
			}
			else
			{
				for (int i = 0; i < sizeof(int) * 8; i++)
				{
					bool bFound = *pVar & (1 << i) && std::find(vValues.begin(), vValues.end(), (1 << i)) != vValues.end();
					if (!bFound)
						*pVar &= ~(1 << i);
				}
			}
		}

		std::string sPreview = "";
		if (!(iFlags & FDropdownEnum::Multi) || *pVar)
		{
			size_t i = 0; for (auto& iValue : vValues)
			{
				while (FNV1A::Hash32(vEntries[i]) == FNV1A::Hash32Const("##Divider"))
					i++;

				if (iFlags & FDropdownEnum::Multi && *pVar & iValue)
					sPreview += std::format("{}, ", StripDoubleHash(vEntries[i]).c_str());
				else if (!(iFlags & FDropdownEnum::Multi) && *pVar == iValue)
					sPreview = std::format("{}##", StripDoubleHash(vEntries[i]).c_str());
				i++;
			}
			if (sPreview.length() > 1)
			{
				sPreview.pop_back(); sPreview.pop_back();
			}
		}
		if (!strstr(sLabel, "## Bind"))
			for (const auto* entry : extraPreview)
			{
				if (!sPreview.empty()) sPreview += ", ";
				sPreview += entry;
			}
		if (sPreview.empty())
			sPreview = sDefaultPreview;

		const bool inlineTitle = bTitle && (iFlags & FDropdownEnum::InlineTitle);
		ImVec2 vSize = { GetWindowWidth(), CompactDropdownHeight(bTitle && !inlineTitle) };
		if (iFlags & (FDropdownEnum::Left | FDropdownEnum::Right))
			vSize.x = vSize.x / 2 - GetStyle().WindowPadding.x * 1.5f;
		else
			vSize.x -= GetStyle().WindowPadding.x * 2.f;
		if (iFlags & FDropdownEnum::Right)
			SameLine(vSize.x + GetStyle().WindowPadding.x * 2.f);
		iSizeOffset = strstr(sLabel, "## Bind") ? 0 : H::Draw.Scale(iSizeOffset, Scale_Round);
		vSize.x += iSizeOffset;

		ImVec2 vOriginalPos = GetCursorPos();
		DebugShift({ 0, H::Draw.Scale(3) });
		if (leadingWidth > 0.f)
		{
			AttachedDropdownOrigin = GetCursorPos();
			AttachedDropdownHeight = vSize.y;
			vSize.x = std::max(H::Draw.Scale(30), vSize.x - leadingWidth);
			SetCursorPosX(GetCursorPosX() + leadingWidth);
		}

		if (Disabled)
		{	// lol
			const ImVec2 framePos = GetCursorPos();
			Button("##", vSize);
			SetCursorPos(framePos);
		}

		PushStyleVar(ImGuiStyleVar_FramePadding, { 0.f, std::max(0.f, (vSize.y - GetTextLineHeight()) * 0.5f) });
		PushItemWidth(vSize.x);

		bool bActive = FBeginCompactCombo(std::format("##{}", sLabel).c_str(), "", ImGuiComboFlags_CustomPreview | ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_HeightLarge);
		if (bActive)
		{
			DebugDummy({ 0, H::Draw.Scale(2) });

			PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, H::Draw.Scale(8) });
			int i = 0; for (auto& sEntry : vEntries)
			{
				if (FNV1A::Hash32(sEntry) == FNV1A::Hash32Const("##Divider"))
				{
					ImVec2 vDrawPos = GetDrawPos(); float flPosY = GetCursorPosY();
					ImColor tInactive = F::Render.Inactive; tInactive.Value.w *= GetStyle().Alpha;
					GetWindowDrawList()->AddRectFilled(vDrawPos + ImVec2(H::Draw.Scale(17), flPosY), vDrawPos + ImVec2(GetWindowWidth() - H::Draw.Scale(17), flPosY + H::Draw.Scale(1)), tInactive);
					DebugDummy({});
					continue;
				}

				std::string sStripped = StripDoubleHash(sEntry);
				if (iFlags & FDropdownEnum::Multi)
				{
					bool bFlagActive = *pVar & vValues[i];

					ImVec2 vOriginalPos2 = GetCursorPos();
					const bool hasAccessory = rowAccessory && vValues[i] == accessoryValue;
					const ImVec2 selectableSize = hasAccessory ? ImVec2(std::max(H::Draw.Scale(50), GetContentRegionAvail().x - H::Draw.Scale(28)), 0) : ImVec2();
					if (FDropdownSelectable(std::format("##{}{}", sEntry, i).c_str(), nullptr, 0, bFlagActive, ImGuiSelectableFlags_DontClosePopups, selectableSize))
					{
						if (bFlagActive)
							*pVar &= ~vValues[i];
						else
							*pVar |= vValues[i];
						bReturn = true;
					}

					ImVec2 vOriginalPos3 = GetCursorPos();
					SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(40), 0));
					TextColored(bFlagActive ? F::Render.Active : F::Render.Inactive, sStripped.c_str());
					SameLine(); DebugDummy({ H::Draw.Scale(!GetCurrentWindow()->ScrollbarY ? 16 : 9), 0 });

					SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(15), H::Draw.Scale(-1)));
					FDropdownIcon(bFlagActive ? ICON_MD_CHECK_BOX : ICON_MD_CHECK_BOX_OUTLINE_BLANK, bFlagActive ? F::Render.Accent : F::Render.Inactive);
					if (hasAccessory)
					{
						SetCursorPos({ GetContentRegionMax().x - H::Draw.Scale(20), vOriginalPos2.y });
						PushID(i);rowAccessory();PopID();
					}
					SetCursorPos(vOriginalPos3);
				}
				else
				{
					ImVec2 vOriginalPos2 = GetCursorPos();
					if (iFlags & FDropdownEnum::Modifiable)
					{
						SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(11), H::Draw.Scale(-5)));
						if (IconButton(vValues[i] == -1 ? ICON_MD_ADD_CIRCLE : ICON_MD_REMOVE_CIRCLE, H::Draw.Scale(24), {}) && pModified)
							*pModified = vValues[i];
						SetCursorPos(vOriginalPos2);
					}

					if (FDropdownSelectable(std::format("##{}{}", sEntry, i).c_str(), nullptr, 0, *pVar == vValues[i]))
						*pVar = vValues[i], bReturn = true;

					ImVec2 vOriginalPos3 = GetCursorPos();
					SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(iFlags & FDropdownEnum::Modifiable ? 40 : 18), 0));
					TextColored(*pVar == vValues[i] ? F::Render.Active : F::Render.Inactive, sStripped.c_str());
					SameLine(); DebugDummy({ H::Draw.Scale(!GetCurrentWindow()->ScrollbarY ? 16 : 9), 0 });

					if (iFlags & FDropdownEnum::Modifiable) // do second image here so as to not cover
					{
						SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(15), H::Draw.Scale(-1)));
						FDropdownIcon(vValues[i] == -1 ? ICON_MD_ADD_CIRCLE : ICON_MD_REMOVE_CIRCLE);
					}
					SetCursorPos(vOriginalPos3);
				}
				i++;
			}
			if (extraRows && !strstr(sLabel, "## Bind"))
				extraRows();
			PopStyleVar();


			FFinishCompactComboLayout();
			EndCombo();
		}
		if (!Disabled && IsItemHovered())
			SetMouseCursor(ImGuiMouseCursor_Hand);
		if (pHovered)
			*pHovered = IsItemHovered();
		if (BeginComboPreview())
		{
			ImVec2 vOriginalPos2 = GetCursorPos();
			const float previewTop = vOriginalPos2.y - GetStyle().FramePadding.y;
			const float valueY = bTitle ? previewTop + vSize.y - H::Draw.Scale(4) - GetTextLineHeight()
				: previewTop + (vSize.y - GetTextLineHeight()) * 0.5f;
			const float arrowY = previewTop + (vSize.y - H::Draw.Scale(16)) * 0.5f;

			if (inlineTitle)
			{
                PushFont(F::Render.FontSmall);
                const float padding = H::Draw.Scale(6);
                const float available = std::max(0.f, vSize.x - H::Draw.Scale(30) - padding);
                const std::string value = TruncateText(sPreview, available * .4f);
                const float valueWidth = CalcTextSize(value.c_str()).x;
                const float valueX = vOriginalPos2.x + vSize.x - H::Draw.Scale(30) - valueWidth;
                const float rowY = previewTop + (vSize.y - GetTextLineHeight()) * .5f;
                const float labelWidth = std::max(0.f, valueX - vOriginalPos2.x - padding * 2.f);
                SetCursorPos({vOriginalPos2.x + padding, rowY});
                TextColored(MenuTitleColour(), "%s", TruncateText(StripDoubleHash(sLabel), labelWidth).c_str());
                SetCursorPos({valueX, rowY});
                TextUnformatted(value.c_str());
                PopFont();
                SetCursorPos({vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY});
                IconImage(bActive ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
			}
			else if (bTitle)
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), previewTop + H::Draw.Scale(3) });
				PushFont(F::Render.FontSmall);
				TextColored(MenuTitleColour(), "%s", TruncateText(StripDoubleHash(sLabel), vSize.x - H::Draw.Scale(30)).c_str());
				PopFont();

				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(sPreview, vSize.x - H::Draw.Scale(30)).c_str());

				SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
				IconImage(bActive ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
			}
			else
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(sPreview, vSize.x - H::Draw.Scale(30)).c_str());

				SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
				IconImage(bActive ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
			}

			EndComboPreview();
		}

		PopItemWidth();
		PopStyleVar();

		SetCursorPos(vOriginalPos);
		AddRowSize(vOriginalPos, vSize + ImVec2(leadingWidth, H::Draw.Scale(3)));
		DebugDummy({ vSize.x + leadingWidth, GetRowSize(vSize.y + H::Draw.Scale(3)) });

		if (Transparent || Disabled)
			PopStyleVar();

		return bReturn;
	}

	inline bool FSDropdown(const char* sLabel, std::string* pVar, std::vector<const char*> vEntries = {}, int iFlags = FDropdownEnum::None, int iSizeOffset = 0, bool* pHovered = nullptr)
	{
		auto uHash = FNV1A::Hash32Const(sLabel);
		bool bReturn = false;

		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		bool bTitle = sLabel[0] != '#';

		ImVec2 vSize = { GetWindowWidth(), CompactDropdownHeight(bTitle) };
		if (iFlags & (FDropdownEnum::Left | FDropdownEnum::Right))
			vSize.x = vSize.x / 2 - GetStyle().WindowPadding.x * 1.5f;
		else
			vSize.x -= GetStyle().WindowPadding.x * 2.f;
		if (iFlags & FDropdownEnum::Right)
			SameLine(vSize.x + GetStyle().WindowPadding.x * 2.f);
		iSizeOffset = strstr(sLabel, "## Bind") ? 0 : H::Draw.Scale(iSizeOffset, Scale_Round);
		vSize.x += iSizeOffset;

		ImVec2 vOriginalPos = GetCursorPos();
		DebugShift({ 0, H::Draw.Scale(3) });

		if (Disabled)
		{	// lol
			Button("##", vSize);
			SetCursorPos(vOriginalPos);
			DebugShift({ 0, H::Draw.Scale(3) });
		}

		PushStyleVar(ImGuiStyleVar_FramePadding, { 0.f, std::max(0.f, (vSize.y - GetTextLineHeight()) * 0.5f) });
		if (vEntries.empty())
		{
			PushStyleColor(ImGuiCol_PopupBg, {});
			PushStyleVar(ImGuiStyleVar_WindowPadding, { GetStyle().WindowPadding.x, 0 });
		}
		PushItemWidth(vSize.x);

		static std::string sPreview = "", sInput = "", sTab = "\n";
		if (FBeginCompactCombo(std::format("##{}", sLabel).c_str(), "", ImGuiComboFlags_CustomPreview | ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_HeightLarge))
		{
			if (!ActiveMap[uHash])
				sPreview = sInput = "";

			ActiveMap[uHash] = true;

			// this textinput is being used as a temporary measure to prevent the main window drawing over the popup
			ImVec2 vOriginalPos2 = GetCursorPos();
			SetCursorPos({ -1000, vEntries.empty() ? -100 : GetScrollY() }); // lol
			if (!IsAnyItemActive())
				SetKeyboardFocusHere();
			bool bEnter = InputText("##FSDropdown", &sInput, ImGuiInputTextFlags_EnterReturnsTrue);
			if (sInput != sTab)
			{
				sPreview = sInput;
				sTab = "\n";
			}
			SetCursorPos(vOriginalPos2);

			auto uPreviewHash = FNV1A::Hash32(sPreview.c_str());
			std::deque<std::string> vValid = {};
			{
				std::string sSearch = sInput;
				std::transform(sSearch.begin(), sSearch.end(), sSearch.begin(), [](unsigned char c) { return char(std::tolower(c)); });
				for (auto& sEntry : vEntries)
				{
					if (FNV1A::Hash32(sEntry) == FNV1A::Hash32Const("##Divider"))
					{
						vValid.push_back(sEntry);
						continue;
					}

					std::string sEntryLower = sEntry;
					std::transform(sEntryLower.begin(), sEntryLower.end(), sEntryLower.begin(), [](unsigned char c) { return char(std::tolower(c)); });
					if (sEntryLower.find(sSearch) != std::string::npos)
						vValid.push_back(sEntry);
				}
			}

			if (!vValid.empty() && FNV1A::Hash32(vValid.front().c_str()) == FNV1A::Hash32Const("##Divider"))
				vValid.pop_front();
			if (!vValid.empty() && FNV1A::Hash32(vValid.back().c_str()) == FNV1A::Hash32Const("##Divider"))
				vValid.pop_back();
			if (!vValid.empty())
			{
				if (U::KeyHandler.Pressed(VK_TAB))
				{
					int iIndex = -1;
					for (int i = 0; i < vValid.size(); i++)
					{
						if (uPreviewHash == FNV1A::Hash32(vValid[i].c_str()))
							iIndex = i;
					}
					if (iIndex == -1 && U::KeyHandler.Down(VK_SHIFT))
						iIndex = 0;
					while (true)
					{
						iIndex += !U::KeyHandler.Down(VK_SHIFT) ? 1 : -1;
						if (iIndex < 0)
							iIndex += int(vValid.size());
						else if (iIndex >= vValid.size())
							iIndex -= int(vValid.size());
						if (FNV1A::Hash32(vValid[iIndex].c_str()) == FNV1A::Hash32Const("##Divider"))
							continue;
						sPreview = vValid[iIndex];
						sTab = sInput;
						break;
					}
				}

				DebugDummy({ 0, H::Draw.Scale(2) });
				PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, H::Draw.Scale(8) });

				bool bDivider = false;
				for (int i = 0; i < vValid.size(); i++)
				{
					auto& sEntry = vValid[i];
					if (FNV1A::Hash32(sEntry.c_str()) == FNV1A::Hash32Const("##Divider"))
					{
						if (!bDivider)
						{
							ImVec2 vDrawPos = GetDrawPos(); float flPosY = GetCursorPosY();
							ImColor tInactive = F::Render.Inactive; tInactive.Value.w *= GetStyle().Alpha;
							GetWindowDrawList()->AddRectFilled(vDrawPos + ImVec2(H::Draw.Scale(17), flPosY), vDrawPos + ImVec2(GetWindowWidth() - H::Draw.Scale(17), flPosY + H::Draw.Scale(1)), tInactive);
							DebugDummy({});
						}
						bDivider = true;
						continue;
					}
					else
						bDivider = false;

					if (bEnter && !(iFlags & FSDropdownEnum::Custom))
					{
						*pVar = sEntry; bReturn = true;
						CloseCurrentPopup(); break;
					}

					bool bActive = FNV1A::Hash32(pVar->c_str()) == FNV1A::Hash32(sEntry.c_str());
					ImVec2 vOriginalPos3 = GetCursorPos();
					if (FDropdownSelectable(std::format("##{}{}", sEntry, i).c_str(), nullptr, 0, bActive))
						*pVar = sEntry, bReturn = true;

					ImVec2 vOriginalPos4 = GetCursorPos();
					SetCursorPos(vOriginalPos3 + ImVec2(H::Draw.Scale(18), 0));
					TextColored(bActive ? F::Render.Active : F::Render.Inactive, sEntry.c_str());
					SameLine(); DebugDummy({ H::Draw.Scale(!GetCurrentWindow()->ScrollbarY ? 16 : 9), 0 });
					SetCursorPos(vOriginalPos4);
				}

				PopStyleVar();
				}

			if ((bEnter || iFlags & FSDropdownEnum::AutoUpdate) && (iFlags & FSDropdownEnum::Custom || vEntries.empty()))
			{
				*pVar = sPreview; bReturn = true;
			}
			if (bEnter || U::KeyHandler.Down(VK_ESCAPE))
				CloseCurrentPopup();

			FFinishCompactComboLayout();
			EndCombo();
		}
		else
			ActiveMap[uHash] = false;
		if (!Disabled && IsItemHovered())
			SetMouseCursor(ImGuiMouseCursor_TextInput);
		if (pHovered)
			*pHovered = IsItemHovered();
		if (BeginComboPreview())
		{
			ImVec2 vOriginalPos2 = GetCursorPos();
			const float previewTop = vOriginalPos2.y - GetStyle().FramePadding.y;
			const float valueY = bTitle ? previewTop + vSize.y - H::Draw.Scale(4) - GetTextLineHeight()
				: previewTop + (vSize.y - GetTextLineHeight()) * 0.5f;
			const float arrowY = previewTop + (vSize.y - H::Draw.Scale(16)) * 0.5f;

			if (bTitle)
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), previewTop + H::Draw.Scale(3) });
				PushFont(F::Render.FontSmall);
				TextColored(MenuTitleColour(), "%s", TruncateText(StripDoubleHash(sLabel), vSize.x - H::Draw.Scale(vEntries.empty() ? 12 : 30)).c_str());
				PopFont();

				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(ActiveMap[uHash] ? sPreview : *pVar, vSize.x - H::Draw.Scale(vEntries.empty() ? 12 : 30)).c_str());

				if (!vEntries.empty())
				{
					SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
					IconImage(ActiveMap[uHash] ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
				}

				if (ActiveMap[uHash] || iFlags & FSDropdownEnum::Custom || vEntries.empty())
				{
					ImVec2 vDrawPos = GetDrawPos() + ImVec2(vOriginalPos2.x + H::Draw.Scale(6), valueY + GetTextLineHeight() + H::Draw.Scale(1));
					vDrawPos.x = floorf(vDrawPos.x), vDrawPos.y = floorf(vDrawPos.y);
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(vSize.x - H::Draw.Scale(vEntries.empty() ? 12 : 30), H::Draw.Scale(2)), GetColorU32(ImVec4(Workspace::BorderChannel(0), Workspace::BorderChannel(1), Workspace::BorderChannel(2), 1.f)));
				}
			}
			else
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(ActiveMap[uHash] ? sPreview : *pVar, vSize.x - H::Draw.Scale(vEntries.empty() ? 12 : 30)).c_str());

				if (!vEntries.empty())
				{
					SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
					IconImage(ActiveMap[uHash] ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
				}

				if (ActiveMap[uHash] || iFlags & FSDropdownEnum::Custom || vEntries.empty())
				{
					ImVec2 vDrawPos = GetDrawPos() + ImVec2(vOriginalPos2.x + H::Draw.Scale(6), valueY + GetTextLineHeight() + H::Draw.Scale(1));
					vDrawPos.x = floorf(vDrawPos.x), vDrawPos.y = floorf(vDrawPos.y);
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(vSize.x - H::Draw.Scale(vEntries.empty() ? 12 : 30), H::Draw.Scale(2)), GetColorU32(ImVec4(Workspace::BorderChannel(0), Workspace::BorderChannel(1), Workspace::BorderChannel(2), 1.f)));
				}
			}

			EndComboPreview();
		}

		PopItemWidth();
		if (vEntries.empty())
		{
			PopStyleColor();
			PopStyleVar();
		}
		PopStyleVar();

		SetCursorPos(vOriginalPos);
		AddRowSize(vOriginalPos, vSize + ImVec2(0, H::Draw.Scale(3)));
		DebugDummy({ vSize.x, GetRowSize(vSize.y + H::Draw.Scale(3)) });

		if (Transparent || Disabled)
			PopStyleVar();

		return bReturn;
	}

	inline bool ColorPicker(const char* sLabel, Color_t* pColor, bool bTooltip = true, ImVec2 vSize = { H::Draw.Scale(12), H::Draw.Scale(12) })
	{
		ImVec2 vOriginalPos = GetCursorPos();
		if (Disabled)
		{	// lol
			Button("##", vSize);
			SetCursorPos(vOriginalPos);
		}

		PushStyleVar(ImGuiStyleVar_Alpha, 1.f);
		PushStyleVar(ImGuiStyleVar_FramePadding, { H::Draw.Scale(2), H::Draw.Scale(2) });
		PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, H::Draw.Scale(4) });
		PushStyleVar(ImGuiStyleVar_ItemInnerSpacing, { H::Draw.Scale(4), 0 });
		PushStyleVar(ImGuiStyleVar_PopupBorderSize, H::Draw.Scale());
		PushStyleColor(ImGuiCol_PopupBg, F::Render.Background0p5.Value);

		ImVec4 tTempColor = ColorByteToVec(*pColor);
		bool bReturn = ColorEdit4(std::format("##{}", sLabel).c_str(), &tTempColor.x, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_LargeAlphaGrid | ImGuiColorEditFlags_NoRoundRestrict | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoBorder | ImGuiColorEditFlags_NoTooltip, vSize);
		if (bReturn)
			*pColor = ColorVecToByte(tTempColor);
		if (!Disabled && IsItemHovered())
			SetMouseCursor(ImGuiMouseCursor_Hand);

		PopStyleColor();
		PopStyleVar(5);

		if (bTooltip)
		{
			vOriginalPos += GetDrawPos();
			FTooltip(StripDoubleHash(sLabel).c_str(), IsItemHovered(), 300, F::Render.FontSmall, &vOriginalPos, &vSize);
		}

		return bReturn;
	}

	// if items overlap, use before to have working input, e.g. a right toggle and a color picker
	inline bool FColorPicker(const char* sLabel, Color_t* pColor, int iFlags = FColorPickerEnum::None, ImVec2 vOffset = {}, ImVec2 vSize = { H::Draw.Scale(12), H::Draw.Scale(12) }, ImVec2 vIconOffset = {}, bool* pHovered = nullptr)
	{
		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		if (iFlags & FColorPickerEnum::RemoveVisuals)
		{
			vOffset = {};
			vSize = { H::Draw.Scale(12), H::Draw.Scale(12) };
			vIconOffset = {};
		}

		ImVec2 vOriginalPos = GetCursorPos();
		ImVec2 vContentSize = vSize;
		ImVec2 vLastSize = GetItemRectSize();

		if (iFlags & AttachedColorPicker)
		{
			iFlags |= FColorPickerEnum::RetainPosition;
		}
		else if (iFlags & (FColorPickerEnum::Left | FColorPickerEnum::Right))
		{
			vContentSize.x = GetWindowWidth() / 2 - GetStyle().WindowPadding.x * 1.5f;
			vContentSize.y = std::max(H::Draw.Scale(24), vContentSize.y);
		}
		else if (iFlags & FColorPickerEnum::Full)
		{
			vContentSize.x = GetWindowWidth() - GetStyle().WindowPadding.x * 2;
			vContentSize.y = std::max(H::Draw.Scale(24), vContentSize.y);
		}
		if (iFlags & AttachedColorPicker)
		{
			// The owning dropdown already reserved and positioned this swatch.
		}
		else if (iFlags & (FColorPickerEnum::Left | FColorPickerEnum::Full))
			iFlags |= FColorPickerEnum::HoverContents;
		else if (iFlags & FColorPickerEnum::Right)
		{
			SameLine(vContentSize.x + GetStyle().WindowPadding.x * 2.f);
			iFlags |= FColorPickerEnum::HoverContents;
		}
		else if (iFlags & FColorPickerEnum::SameLine)
		{
			SameLine();
			vOffset.x -= GetStyle().WindowPadding.x;
			vIconOffset.y += H::Draw.Scale(8);
		}
		else
		{
			SetCursorPosX(GetContentRegionMax().x - H::Draw.Scale(MenuMode::DrawingMoonlit ? 36 : 30));
			iFlags |= FColorPickerEnum::RetainPosition;
			vIconOffset.y += MenuMode::DrawingMoonlit ? (H::Draw.Scale(36) - vSize.y) * .5f : H::Draw.Scale(3.5f);
		}
		SetCursorPos(GetCursorPos() + vOffset);
		ImVec2 vOriginalPos2 = GetCursorPos();

		bool bTooltip = iFlags & FColorPickerEnum::Tooltip || !(iFlags & (FColorPickerEnum::Left | FColorPickerEnum::Right | FColorPickerEnum::Full | FColorPickerEnum::NoTooltip));
		{
			float flIconOffset;
			if (vContentSize.x > vContentSize.y)
				flIconOffset = (vContentSize.y - vSize.y) / 2;
			else
				flIconOffset = (vContentSize.x - vSize.x) / 2;
			vIconOffset += { flIconOffset, flIconOffset };
		}

		std::vector<std::string> vWrapped;
		int iWraps = 0;
		if (iFlags & (FColorPickerEnum::Left | FColorPickerEnum::Right | FColorPickerEnum::Full))
		{
			vWrapped = WrapText(StripDoubleHash(sLabel), vContentSize.x - H::Draw.Scale(24));
			iWraps = std::min(int(vWrapped.size()), 2); // prevent too many wraps
			float flNewSizeY = std::max(H::Draw.Scale(6 + 18 * iWraps), vContentSize.y);
			vIconOffset.y += (flNewSizeY - vContentSize.y) / 2;
			vContentSize.y = flNewSizeY;
		}

		SetCursorPos(vOriginalPos2 + vIconOffset);
		bool bReturn = ColorPicker(sLabel, pColor, bTooltip, vSize);
		if (pHovered && !(iFlags & FColorPickerEnum::HoverContents))
			*pHovered = IsItemHovered();

		for (size_t i = 0; i < iWraps; i++)
		{
			SetCursorPos(vOriginalPos2 + ImVec2(vIconOffset.x + vSize.x + H::Draw.Scale(6), vContentSize.y / 2 + H::Draw.Scale(2 - 9 * iWraps + 18 * int(i))));
			TextUnformatted(vWrapped[i].c_str());
		}

		if (iFlags & FColorPickerEnum::RetainPosition)
		{
			SetCursorPos(vOriginalPos);
			DebugDummy({});
		}
		else
		{
			vContentSize = { std::max(vSize.x + vIconOffset.x, vContentSize.x), std::max(vSize.y + vIconOffset.y, vContentSize.y) };
			SetCursorPos(vOriginalPos2);
			AddRowSize(vOriginalPos2, vContentSize);
			DebugDummy(vContentSize);
		}
		if (pHovered && iFlags & FColorPickerEnum::HoverContents)
			*pHovered = IsItemHovered();

		if (Transparent || Disabled)
			PopStyleVar();

		return bReturn;
	}

	inline void FKeybind(const char* sLabel, int& iOutput, int iFlags = FKeybindEnum::None, std::vector<int> vIgnore = { Vars::Menu::PrimaryKey[DEFAULT_BIND], Vars::Menu::SecondaryKey[DEFAULT_BIND] }, ImVec2 vSize = { 0, 30 }, int iSizeOffset = 0, bool* pHovered = nullptr)
	{
		ImGuiID uId = GetID(sLabel);
		PushID(sLabel);

		if (GetActiveID() == uId)
		{
			F::Menu.m_bInKeybind = true;

			bool bHovered = false;
			FButton(std::format("{}: ...", sLabel).c_str(), iFlags | FButtonEnum::NoUpper, vSize, iSizeOffset, nullptr, &bHovered);
			if (pHovered)
				*pHovered = bHovered;

			if (bHovered && IsMouseReleased(ImGuiMouseButton_Left))
				ClearActiveID();
			else
			{
				SetActiveID(uId, GetCurrentWindow());

				for (short iKey = 1; iKey < 255; iKey++)
				{
					bool bValid = U::KeyHandler.Pressed(iKey);
					if (!bValid)
						continue;

					bValid = vIgnore.empty() || std::find(vIgnore.begin(), vIgnore.end(), iKey) == vIgnore.end();
					if (!bValid)
						continue;

					switch (iKey)
					{
					case VK_LBUTTON:
						bValid = !bHovered; break;
					case VK_SHIFT:
					case VK_LSHIFT:
					case VK_RSHIFT:
					case VK_CONTROL:
					case VK_LCONTROL:
					case VK_RCONTROL:
					case VK_MENU:
					case VK_LMENU:
					case VK_RMENU:
						bValid = iKey != iOutput; break;
					}
					if (!bValid)
						continue;

					switch (iKey)
					{
					case VK_ESCAPE:
						if (iFlags & FKeybindEnum::AllowNone)
						{
							iOutput = 0x0;
							break;
						}
						[[fallthrough]];
					default:
						iOutput = iKey;
					}
					ClearActiveID();
					break;
				}

				GetCurrentContext()->ActiveIdAllowOverlap = true;
			}
		}
		else if (FButton(std::format("{}: {}", sLabel, U::KeyHandler.String(iOutput)).c_str(), iFlags | FButtonEnum::NoUpper, vSize, iSizeOffset, nullptr, pHovered))
			SetActiveID(uId, GetCurrentWindow());

		PopID();
	}
	inline void FKeybind(ConfigVar<int>& tVar, int iFlags = FKeybindEnum::None, std::vector<int> vIgnore = { Vars::Menu::PrimaryKey[DEFAULT_BIND], Vars::Menu::SecondaryKey[DEFAULT_BIND] }, ImVec2 vSize = { 0, 30 }, int iSizeOffset = 0, bool* pHovered = nullptr)
	{
		FKeybind(tVar.m_vNames.front(), tVar[DEFAULT_BIND], iFlags, vIgnore, vSize, iSizeOffset, pHovered);
	}

	// dropdown for materials
	inline bool FMDropdown(const char* sLabel, std::vector<std::pair<std::string, Color_t>>* pVar, int iFlags = FDropdownEnum::None, int iSizeOffset = 0, bool* pHovered = nullptr)
	{
		// actual dropdown
		bool bReturn = false;

		if (Transparent || Disabled)
			PushStyleVar(ImGuiStyleVar_Alpha, 0.5f);

		bool bTitle = sLabel[0] != '#';

		std::unordered_map<std::string, std::vector<std::pair<std::string, Color_t>>::iterator> mIts = {};
		for (auto it = pVar->begin(); it != pVar->end(); it++)
			mIts[it->first] = it;

		std::string sPreview = "";
		if (pVar->empty())
			sPreview = "None";
		else
		{
			for (auto& pair : *pVar)
				sPreview += std::format("{}, ", pair.first.c_str());
			sPreview.pop_back(); sPreview.pop_back();
		}

		ImVec2 vSize = { GetWindowWidth(), CompactDropdownHeight(bTitle) };
		if (iFlags & (FDropdownEnum::Left | FDropdownEnum::Right))
			vSize.x = vSize.x / 2 - GetStyle().WindowPadding.x * 1.5f;
		else
			vSize.x -= GetStyle().WindowPadding.x * 2.f;
		if (iFlags & FDropdownEnum::Right)
			SameLine(vSize.x + GetStyle().WindowPadding.x * 2.f);
		iSizeOffset = strstr(sLabel, "## Bind") ? 0 : H::Draw.Scale(iSizeOffset, Scale_Round);
		vSize.x += iSizeOffset;

		ImVec2 vOriginalPos = GetCursorPos();
		DebugShift({ 0, H::Draw.Scale(3) });

		if (Disabled)
		{	// lol
			Button("##", vSize);
			SetCursorPos(vOriginalPos);
			DebugShift({ 0, H::Draw.Scale(3) });
		}

		PushStyleVar(ImGuiStyleVar_FramePadding, { 0.f, std::max(0.f, (vSize.y - GetTextLineHeight()) * 0.5f) });
		PushItemWidth(vSize.x);

		bool bActive = false;
		if (FBeginCompactCombo(std::format("##{}", sLabel).c_str(), "", ImGuiComboFlags_CustomPreview | ImGuiComboFlags_NoArrowButton | ImGuiComboFlags_HeightLarge))
		{
			bActive = true;

			// material stuff (only gathered while the dropdown is open)
			std::vector<const Material_t*> vMaterials;
			for (auto& tMaterial : F::Materials.m_mMaterials | std::views::values)
			{
				if (FNV1A::Hash32(tMaterial.m_sName.c_str()) != FNV1A::Hash32Const("None"))
					vMaterials.push_back(&tMaterial);
			}

			std::sort(vMaterials.begin(), vMaterials.end(), [&](const auto* a, const auto* b) -> bool
			{
				// keep locked materials higher
				if (a->m_bLocked && !b->m_bLocked)
					return true;
				if (!a->m_bLocked && b->m_bLocked)
					return false;

				return a->m_sName < b->m_sName;
			});

			std::vector<std::string> vEntries = { "Original" };
			for (auto pMaterial : vMaterials)
				vEntries.push_back(pMaterial->m_sName.c_str());

			DebugDummy({ 0, H::Draw.Scale(2) });
			PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, H::Draw.Scale(8) });
			for (int i = 0; i < vEntries.size(); i++)
			{
				auto& sEntry = vEntries[i];
				if (FNV1A::Hash32(sEntry.c_str()) == FNV1A::Hash32Const("##Divider"))
				{
					ImVec2 vDrawPos = GetDrawPos(); float flPosY = GetCursorPosY();
					ImColor tInactive = F::Render.Inactive; tInactive.Value.w *= GetStyle().Alpha;
					GetWindowDrawList()->AddRectFilled(vDrawPos + ImVec2(H::Draw.Scale(17), flPosY), vDrawPos + ImVec2(GetWindowWidth() - H::Draw.Scale(17), flPosY + H::Draw.Scale(1)), tInactive);
					DebugDummy({});
					continue;
				}

				auto it = mIts.find(sEntry);
				bool bFlagActive = it != mIts.end();
				int iEntry = bFlagActive ? std::distance(pVar->begin(), mIts[sEntry]) + 1 : 0;

				ImVec2 vOriginalPos2 = GetCursorPos();
				if (bFlagActive) // do here so as to not sink input
				{
					SetCursorPos(vOriginalPos2 + ImVec2(vSize.x - H::Draw.Scale(31), H::Draw.Scale(1)));
					ColorPicker(std::format("MaterialColor{}", iEntry).c_str(), &it->second->second, false);
					SetCursorPos(vOriginalPos2);
				}
				bool bHovered = bFlagActive ? IsItemHovered() : false;

				if (FDropdownSelectable(std::format("##{}{}", sEntry, i).c_str(), nullptr, 0, bFlagActive, ImGuiSelectableFlags_DontClosePopups))
				{
					if (bFlagActive)
						pVar->erase(it->second);
					else
						pVar->emplace_back(sEntry, Color_t());
					bReturn = true;

					// the vector was modified, so the cached iterators are no longer valid
					mIts.clear();
					for (auto it2 = pVar->begin(); it2 != pVar->end(); it2++)
						mIts[it2->first] = it2;
				}
				bHovered = !bHovered && IsItemHovered();

				// shift based on number of digits in var size
				ImVec2 vOriginalPos3 = GetCursorPos();
				SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(40 + 6 * int(log10(std::max(pVar->size(), 1ui64)))), 0));
				TextColored(bFlagActive ? F::Render.Active : F::Render.Inactive, (bHovered ? sEntry : TruncateText(sEntry, vSize.x - H::Draw.Scale(bFlagActive ? 81 : 57))).c_str());
				SameLine(); DebugDummy({ H::Draw.Scale(!GetCurrentWindow()->ScrollbarY ? 16 : 9), 0 });

				if (bFlagActive)
				{
					SetCursorPos(vOriginalPos2 + ImVec2(H::Draw.Scale(18), 0));
					TextColored(F::Render.Accent, "%i", iEntry);
				}
				SetCursorPos(vOriginalPos3);
			}
			PopStyleVar();

			FFinishCompactComboLayout();
			EndCombo();
		}
		if (!Disabled && IsItemHovered())
			SetMouseCursor(ImGuiMouseCursor_Hand);
		if (pHovered)
			*pHovered = IsItemHovered();
		if (BeginComboPreview())
		{
			ImVec2 vOriginalPos2 = GetCursorPos();
			const float previewTop = vOriginalPos2.y - GetStyle().FramePadding.y;
			const float valueY = bTitle ? previewTop + vSize.y - H::Draw.Scale(4) - GetTextLineHeight()
				: previewTop + (vSize.y - GetTextLineHeight()) * 0.5f;
			const float arrowY = previewTop + (vSize.y - H::Draw.Scale(16)) * 0.5f;

			if (bTitle)
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), previewTop + H::Draw.Scale(3) });
				PushFont(F::Render.FontSmall);
				TextColored(MenuTitleColour(), "%s", TruncateText(StripDoubleHash(sLabel), vSize.x - H::Draw.Scale(30)).c_str());
				PopFont();

				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(sPreview, vSize.x - H::Draw.Scale(30)).c_str());

				SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
				IconImage(bActive ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
			}
			else
			{
				SetCursorPos({ vOriginalPos2.x + H::Draw.Scale(6), valueY });
				TextUnformatted(TruncateText(sPreview, vSize.x - H::Draw.Scale(30)).c_str());

				SetCursorPos({ vOriginalPos2.x + vSize.x - H::Draw.Scale(20), arrowY });
				IconImage(bActive ? ICON_MD_KEYBOARD_ARROW_UP : ICON_MD_KEYBOARD_ARROW_DOWN);
			}

			EndComboPreview();
		}

		PopItemWidth();
		PopStyleVar();

		SetCursorPos(vOriginalPos);
		AddRowSize(vOriginalPos, vSize + ImVec2(0, H::Draw.Scale(3)));
		DebugDummy({ vSize.x, GetRowSize(vSize.y + H::Draw.Scale(3)) });

		if (Transparent || Disabled)
			PopStyleVar();

		return bReturn;
	}

	inline void DrawConditionOptions(Bind_t& bind)
	{
		if (bind.m_iType != BindEnum::Behind && bind.m_iType != BindEnum::Threat) return;
		auto& options=bind.m_tConditions;
		PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), H::Draw.Scale(5) });
		if (bind.m_iType == BindEnum::Behind)
		{
			FDropdown("Enemy class", &options.enemyClass, { "Any enemy", "Scout", "Soldier", "Pyro", "Demoman", "Heavy", "Engineer", "Medic", "Sniper", "Spy" }, { 0, 1, 3, 7, 4, 6, 9, 5, 2, 8 });
			FSlider("Detection range", &options.behindRange, 1.f, 10000.f, 1.f, "%.0f HU", FSliderEnum::Clamp);
			FSlider("Rear arc", &options.behindArc, 1.f, 180.f, 1.f, "%.0f deg", FSliderEnum::Clamp);
			FToggle("Require clear sightline", &options.behindVisible);
			TextWrapped("Enemy class and position must match the same enemy. Behind follows your camera direction.");
		}
		else
		{
			FSlider("Aim tolerance", &options.aimTolerance, 0.f, 10.f, .1f, "%.1f deg", FSliderEnum::Clamp | FSliderEnum::Precision);
			FSlider("Projectile window", &options.projectileWindow, .01f, 1.f, .01f, "%.2f s", FSliderEnum::Clamp | FSliderEnum::Precision);
			FToggle("Any visible Sniper", &options.sniperAnyAim);
			TextWrapped("Lethal attacks with a clear damage path; projectiles use the prediction window. Any visible Sniper also triggers when enabled, regardless of scope, weapon, aim or damage. Visibility means clear line of sight, including outside your camera view. Client-side estimates, not guaranteed hits.");
		}
		options=ConditionPolicy::Normalize(options);
		PopStyleVar();
	}

	// convar wrappers
	template <class T>
	inline int GetBind(ConfigVar<T>& tVar, bool bForce = false)
	{
		if (tVar.m_iFlags & (NOSAVE | NOBIND))
			return DEFAULT_BIND;

		if (bForce)
			return CurrentBind;

		int iParent = CurrentBind;
		while (true)
		{
			if (iParent == DEFAULT_BIND || tVar.contains(iParent))
				break;
			iParent = F::Binds.GetParent(iParent);
		}
		return iParent;
	}

	template <class T>
	inline T GetParentValue(ConfigVar<T>& tVar, int iBind) // oh my god
	{
		int iParent = iBind;
		while (true)
		{
			iParent = F::Binds.GetParent(iParent);
			if (iParent == DEFAULT_BIND || tVar.contains(iParent))
				break;
		}
		return tVar[iParent];
	}

	inline bool bPushedDisabled = false, bPushedTransparent = false;

	template <class T>
	inline T& FGet(ConfigVar<T>& tVar, bool bDisable = false)
	{
		auto& routed=AimModes::Resolve(tVar);if(&routed!=&tVar)return FGet(routed,bDisable);
		int iBind = GetBind(tVar);
		if (bDisable)
		{
			bPushedDisabled = false, bPushedTransparent = false;

			if (CurrentBind == DEFAULT_BIND)
			{
				if (Vars::Menu::MenuShowsBinds.Value && tVar[DEFAULT_BIND] != tVar.Value)
				{
					for (auto& [_iBind, tVal] : tVar.Map)
					{
						if (_iBind == DEFAULT_BIND)
							continue;

						if (tVal == tVar.Value)
						{
							PushDisabled(true);
							bPushedDisabled = true;
							return tVal;
						}
					}
				}
			}
			else
			{
				PushTransparent(CurrentBind != iBind && !(tVar.m_iFlags & (NOSAVE | NOBIND)));
				bPushedTransparent = true;
			}
		}
		return tVar[iBind];
	}

	template <class T>
	inline void FSet(ConfigVar<T>& tVar, T tVal)
	{
		auto& routed=AimModes::Resolve(tVar);if(&routed!=&tVar){FSet(routed,tVal);return;}
		if (!Disabled)
		{
			int iBind = GetBind(tVar, true);
			auto _tVal = GetParentValue(tVar, iBind);

			if (tVal != _tVal)
			{
				tVar[iBind] = tVal;
				if (iBind < F::Binds.m_vBinds.size())
				{
					auto& tBind = *std::next(F::Binds.m_vBinds.begin(), iBind);
					if (std::find(tBind.m_vVars.begin(), tBind.m_vVars.end(), &tVar) == tBind.m_vVars.end())
						tBind.m_vVars.push_back(&tVar);
				}
			}
			else if (iBind != DEFAULT_BIND)
			{
				for (auto it = tVar.Map.begin(); it != tVar.Map.end();)
				{
					if (it->first == iBind)
					{
						it = tVar.Map.erase(it);
						if (iBind < F::Binds.m_vBinds.size())
						{
							auto& tBind = *std::next(F::Binds.m_vBinds.begin(), iBind);
							auto it2 = std::find(tBind.m_vVars.begin(), tBind.m_vVars.end(), &tVar);
							if (it2 != tBind.m_vVars.end())
								tBind.m_vVars.erase(it2);
						}
					}
					else
						++it;
				}
			}
		}

		if (bPushedDisabled)
			PopDisabled();
		if (bPushedTransparent)
			PopTransparent();
		// A completed edit owns these pops only once. A subsequent plain FSet
		// (e.g. a dependent colour/override update) must not reuse stale flags.
		bPushedDisabled = false, bPushedTransparent = false;
	}

	template <class T>
	inline void DrawBindInfo(ConfigVar<T>& tVar, T& tVal, const char* sType, const std::string& sBind, bool bNewPopup, bool& bLastHovered)
	{
		auto& routed=AimModes::Resolve(tVar);if(&routed!=&tVar){DrawBindInfo(routed,tVal,sType,sBind,bNewPopup,bLastHovered);return;}
		TextUnformatted(std::format("Bind '{}'", sBind).c_str());

		static int iBind = DEFAULT_BIND;
		static Bind_t tBind = {};
		if (bNewPopup)
		{
			iBind = DEFAULT_BIND;
			tBind = { sBind };
		}

		std::vector<const char*> vEntries = {};
		std::vector<int> vValues = {};

		std::vector<std::string> vStrings = {}; // prevent dangling pointers
		for (auto& _iBind : tVar.Map | std::views::keys)
		{
			if (_iBind != DEFAULT_BIND)
				vValues.push_back(_iBind);
		}
		std::sort(vValues.begin(), vValues.end(), [&](const int a, const int b) -> bool
		{
			return a < b;
		});
		for (auto _iBind : vValues)
			vStrings.push_back(std::format("{}## Bind{}", _iBind != DEFAULT_BIND && _iBind < F::Binds.m_vBinds.size() ? F::Binds.m_vBinds[_iBind].m_sName : sBind, _iBind));
		for (auto& sEntry : vStrings)
			vEntries.push_back(sEntry.c_str());

		vEntries.push_back("new bind");
		vValues.push_back(-1);

		int iModified = -2;
		if (FDropdown("##Bind", &iBind, vEntries, vValues, FDropdownEnum::Modifiable, -84, "None", nullptr, &iModified))
		{
			if (iBind != DEFAULT_BIND && iBind < F::Binds.m_vBinds.size())
				tBind = F::Binds.m_vBinds[iBind];
			else
				tBind = { sBind };
			if (tVar.contains(iBind))
				tVal = tVar[iBind];
		}
		bool bClickedNew = iBind == DEFAULT_BIND && bLastHovered && IsMouseDown(ImGuiMouseButton_Left);
		if (iModified != -2 || bClickedNew)
		{
			if (iModified == -1 || bClickedNew)
			{
				iBind = int(F::Binds.m_vBinds.size());
				tBind = { sBind };
				tBind.m_vVars.push_back(&tVar);
				F::Binds.AddBind(iBind, tBind);
			}
			else
			{
				auto it = tVar.Map.find(iModified);
				if (it != tVar.Map.end())
				{
					tVar.Map.erase(it);
					if (iModified < F::Binds.m_vBinds.size())
					{
						auto& tBind = *std::next(F::Binds.m_vBinds.begin(), iModified);
						auto it2 = std::find(tBind.m_vVars.begin(), tBind.m_vVars.end(), &tVar);
						if (it2 != tBind.m_vVars.end())
							tBind.m_vVars.erase(it2);
					}
				}

				F::Binds.RemoveBind(iModified, false);
				iBind = -1;
			}
		}
		bool bHovered = false; bLastHovered = false;

		PushTransparent(iBind == DEFAULT_BIND);

		{
			ImVec2 vOriginalPos = GetCursorPos();
			int iOffset = 12;

			PushTransparent(Transparent || !tBind.m_bEnabled, true);

			SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), H::Draw.Scale(29) });
			PushTransparent(Transparent || tBind.m_iVisibility == BindVisibilityEnum::Hidden, true);
			if (IconButton(tBind.m_iVisibility == BindVisibilityEnum::Always ? ICON_MD_VISIBILITY : ICON_MD_VISIBILITY_OFF, H::Draw.Scale(24), { 1, 1, 1, -1 }, &bHovered))
				tBind.m_iVisibility = (tBind.m_iVisibility + 1) % 3;
			PopTransparent(1, 1);
			bLastHovered |= bHovered;

			SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), H::Draw.Scale(29) });
			if (IconButton(!tBind.m_bNot ? ICON_MD_CODE : ICON_MD_CODE_OFF, H::Draw.Scale(24), { 1, 1, 1, -1 }, &bHovered))
				tBind.m_bNot = !tBind.m_bNot;
			bLastHovered |= bHovered;

			SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), H::Draw.Scale(29) });
			if (IconButton(!tBind.m_bEnabled ? ICON_MD_TOGGLE_OFF : ICON_MD_TOGGLE_ON, H::Draw.Scale(24), { 1, 1, 1, -1 }, &bHovered))
				tBind.m_bEnabled = !tBind.m_bEnabled;
			bLastHovered |= bHovered;

			PopTransparent(1, 1);

			SetCursorPos(vOriginalPos);
		}

		auto vTable = tBind.m_iType == BindEnum::Key ? WidgetTable(3, H::Draw.Scale(40), { H::Draw.Scale(80), H::Draw.Scale(104), H::Draw.Scale(116) + 1 }) : WidgetTable(2, H::Draw.Scale(40));

		if (BeginWidgetTable(0, vTable))
		{
			FDropdown("Type", &tBind.m_iType, { "Key", "Class", "Weapon type", "Item slot", "Misc", "Is behind", "On threat" }, {}, FDropdownEnum::None, 0, "None", &bHovered);
			bLastHovered |= bHovered;
		} EndChild();

		if (BeginWidgetTable(1, vTable))
		{
			switch (tBind.m_iType)
			{
			case BindEnum::Key: FDropdown("Behavior", &tBind.m_iInfo, { "Hold", "Toggle", "Double click" }, {}, FDropdownEnum::None, 0, "None", &bHovered); break;
			case BindEnum::Class: FDropdown("Class", &tBind.m_iInfo, { "Scout", "Soldier", "Pyro", "Demoman", "Heavy", "Engineer", "Medic", "Sniper", "Spy" }, {}, FDropdownEnum::None, 0, "None", &bHovered); break;
			case BindEnum::WeaponType: FDropdown("Weapon type", &tBind.m_iInfo, { "Hitscan", "Projectile", "Melee", "Throwable" }, {}, FDropdownEnum::None, 0, "None", &bHovered); break;
			case BindEnum::ItemSlot: FDropdown("Item slot", &tBind.m_iInfo, { "1", "2", "3", "4", "5", "6", "7", "8", "9" }, {}, FDropdownEnum::None, 0, "None", &bHovered); break;
			case BindEnum::Misc: FDropdown("Misc", &tBind.m_iInfo, { "Spectated", "Spectated 1st", "Spectated 3rd", "##Divider", "Zoomed", "Aiming" }, {}, FDropdownEnum::None, 0, "None", &bHovered); break;
			case BindEnum::Behind: FText("Enemies only"); break;
			case BindEnum::Threat: FText("Lethal attack"); break;
			}
			bLastHovered |= bHovered;
		} EndChild();

		if (vTable.size() == 3)
		{
			if (BeginWidgetTable(2, vTable))
			{
				FKeybind("Key", tBind.m_iKey, FKeybindEnum::None, { Vars::Menu::PrimaryKey[DEFAULT_BIND], Vars::Menu::SecondaryKey[DEFAULT_BIND] }, { 0, 40 }, 0, &bHovered);
				bLastHovered |= bHovered;
			} EndChild();
		}

		DrawConditionOptions(tBind);
		if (!Disabled && iBind != DEFAULT_BIND && iBind < F::Binds.m_vBinds.size())
		{
			tVar[iBind] = tVal;

			// don't completely override to retain misc info
			auto& _tBind = F::Binds.m_vBinds[iBind];
			_tBind.m_iType = tBind.m_iType;
			_tBind.m_iInfo = tBind.m_iInfo;
			_tBind.m_iKey = tBind.m_iKey;
			_tBind.m_bEnabled = tBind.m_bEnabled;
			_tBind.m_iVisibility = tBind.m_iVisibility;
			_tBind.m_bNot = tBind.m_bNot;
			_tBind.m_tConditions = tBind.m_tConditions;
		}

		switch (FNV1A::Hash32(sType))
		{
		case FNV1A::Hash32Const("FDropdown"):
		case FNV1A::Hash32Const("FModifierDropdown"):
		case FNV1A::Hash32Const("FSDropdown"):
		case FNV1A::Hash32Const("FMDropdown"):
			break;
		default:
			DebugDummy({ 0, GetStyle().WindowPadding.y });
		}
	}

	// Keep independent settings (and their existing config/bind keys) inside a modifier popup.
	inline bool FDropdownToggle(const char* label, bool* value, int flags = 0, bool* hovered = nullptr)
	{
		// Match the existing multi-select rows instead of placing a full-width menu toggle
		// inside a combo: identical hit area, border, left checkbox and label offsets.
		const ImVec2 rowPos = GetCursorPos();
		const bool selected = *value;
		// The selectable is only the click target. Hide its automatic label because
		// the styled label is drawn explicitly below, as with the other dropdown rows.
		const std::string selectableId = std::format("##DropdownToggle {}", label);
		const bool pressed = FDropdownSelectable(selectableId.c_str(), nullptr, 0, selected, ImGuiSelectableFlags_DontClosePopups);
		const auto rowItem = GImGui->LastItemData;
		if (hovered) *hovered = IsItemHovered();
		if (pressed && !Disabled) *value = !selected;
		const ImVec2 nextPos = GetCursorPos();
		SetCursorPos(rowPos + ImVec2(H::Draw.Scale(40), 0));
		TextColored(selected ? F::Render.Active : F::Render.Inactive, "%s", StripDoubleHash(label).c_str());
		SameLine(); DebugDummy({ H::Draw.Scale(!GetCurrentWindow()->ScrollbarY ? 16 : 9), 0 });
		SetCursorPos(rowPos + ImVec2(H::Draw.Scale(15), H::Draw.Scale(-1)));
		FDropdownIcon(selected ? ICON_MD_CHECK_BOX : ICON_MD_CHECK_BOX_OUTLINE_BLANK, selected ? F::Render.Accent : F::Render.Inactive);
		SetCursorPos(nextPos);
		// Retain the row as the hovered item for tooltips and the existing bind editor.
		GImGui->LastItemData = rowItem;
		return pressed && !Disabled;
	}

	inline bool FModifierDropdown(const char* label, int* value, std::vector<const char*> entries, std::function<void()> extraRows, std::vector<const char*> preview, int flags, int offset, const char* defaultPreview, bool* hovered)
	{
		return FDropdown(label, value, entries, {}, flags, offset, defaultPreview, hovered, nullptr, {}, 0, extraRows, preview);
	}

	#define WRAPPER(function, type, parameters, arguments) \
	inline bool function(ConfigVar<type>& tVar, parameters, bool* pHovered = nullptr, int iBindOverride = -1, int iLabelOverride = -1) \
	{ \
		const char* sLabel = iLabelOverride != -1 ? tVar.m_vNames[iLabelOverride] : tVar.m_vNames.front(); \
		int iVarFlags = tVar.m_iFlags & ~(VISUAL | NOSAVE | NOBIND | DEBUGVAR); \
		iFlags |= iVarFlags; \
		auto tVal = FGet(tVar, true); \
		bool bHovered = false; \
		bool bReturn = function(std::format("{}## {}", sLabel, tVar.Name()).c_str(), arguments, &bHovered); \
		FSet(tVar, tVal); \
		if (pHovered) \
			*pHovered = bHovered; \
		if (!(tVar.m_iFlags & (NOBIND | NOSAVE)) && !Disabled && CurrentBind == DEFAULT_BIND) \
		{	/*probably a better way to do this*/ \
			static auto tStaticVal = tVal; \
			bool bNewPopup = bHovered && IsMouseReleased(ImGuiMouseButton_Right) && !IsMouseDown(ImGuiMouseButton_Left) && !IsPopupOpen(nullptr, ImGuiPopupFlags_AnyPopupId); \
			if (bNewPopup) \
			{ \
				OpenPopup(tVar.Name()); \
				tStaticVal = tVal; \
			} \
			SetNextWindowSize({ H::Draw.Scale(300), 0 }, ImGuiCond_Always); \
			bool bPopup = FBeginPopup(tVar.Name()); \
			if (bPopup) \
			{ \
				std::string sBind = iBindOverride != -1 ? tVar.m_vNames[iBindOverride] : tVar.m_vNames.back(); \
				std::transform(sBind.begin(), sBind.end(), sBind.begin(), [](unsigned char c) { return char(std::tolower(c)); }); \
				iFlags = iVarFlags; /*get rid of any visual flags*/ \
				if (FNV1A::Hash32Const(#function) == FNV1A::Hash32Const("FColorPicker")) \
					iFlags |= FColorPickerEnum::Full | FColorPickerEnum::RemoveVisuals; \
				PushTransparent(false); \
				static bool bLastHovered = false; \
				DrawBindInfo(tVar, tStaticVal, #function, StripDoubleHash(sBind.c_str()), bNewPopup, bLastHovered); \
				tVal = tStaticVal; \
				function(std::format("{}## Bind", tVar.m_vNames.front()).c_str(), arguments, &bHovered); \
				bLastHovered |= bHovered; \
				tStaticVal = tVal; \
				PopTransparent(2); \
				EndPopup(); \
			} \
		} \
		return bReturn; \
	}

	WRAPPER(FToggle, bool, VA_LIST(int iFlags = 0), VA_LIST(&tVal, iFlags))
	WRAPPER(FDropdownToggle, bool, VA_LIST(int iFlags = 0), VA_LIST(&tVal, iFlags))
	WRAPPER(FToggle, int, VA_LIST(int iBit, int iFlags = 0), VA_LIST(&tVal, iBit, iFlags))
	WRAPPER(FSlider, FloatRange_t, VA_LIST(int iFlags = 0, const char* sFormatOverride = nullptr), VA_LIST(&tVal.Min, &tVal.Max, tVar.m_unMin.f, tVar.m_unMax.f, tVar.m_unStep.f, sFormatOverride ? sFormatOverride : tVar.m_sExtra, iFlags))
	WRAPPER(FSlider, IntRange_t, VA_LIST(int iFlags = 0, const char* sFormatOverride = nullptr), VA_LIST(&tVal.Min, &tVal.Max, tVar.m_unMin.i, tVar.m_unMax.i, tVar.m_unStep.i, sFormatOverride ? sFormatOverride : tVar.m_sExtra, iFlags))
	WRAPPER(FSlider, float, VA_LIST(int iFlags = 0, const char* sFormatOverride = nullptr), VA_LIST(&tVal, tVar.m_unMin.f, tVar.m_unMax.f, tVar.m_unStep.f, sFormatOverride ? sFormatOverride : tVar.m_sExtra, iFlags))
	WRAPPER(FSlider, int, VA_LIST(int iFlags = 0, const char* sFormatOverride = nullptr), VA_LIST(&tVal, tVar.m_unMin.i, tVar.m_unMax.i, tVar.m_unStep.i, sFormatOverride ? sFormatOverride : tVar.m_sExtra, iFlags))
	WRAPPER(FDropdown, int, VA_LIST(int iFlags = 0, int iSizeOffset = 0), VA_LIST(&tVal, tVar.m_vValues, {}, iFlags, iSizeOffset, tVar.m_sExtra ? tVar.m_sExtra : "None"))
	WRAPPER(FModifierDropdown, int, VA_LIST(std::function<void()> extraRows, std::vector<const char*> extraPreview, int iFlags = 0, int iSizeOffset = 0), VA_LIST(&tVal, tVar.m_vValues, extraRows, extraPreview, iFlags, iSizeOffset, tVar.m_sExtra ? tVar.m_sExtra : "None"))
	WRAPPER(FDropdown, int, VA_LIST(std::vector<const char*> vEntries, std::vector<int> vValues = {}, int iFlags = 0, int iSizeOffset = 0), VA_LIST(&tVal, vEntries, vValues, iFlags, iSizeOffset, tVar.m_sExtra ? tVar.m_sExtra : "None"))
	WRAPPER(FSDropdown, std::string, VA_LIST(int iFlags = 0, int iSizeOffset = 0), VA_LIST(&tVal, tVar.m_vValues, iFlags, iSizeOffset))
	WRAPPER(FMDropdown, VA_LIST(std::vector<std::pair<std::string, Color_t>>), VA_LIST(int iFlags = 0, int iSizeOffset = 0), VA_LIST(&tVal, iFlags, iSizeOffset))
	WRAPPER(FColorPicker, Color_t, VA_LIST(int iFlags = 0, ImVec2 vOffset = {}, ImVec2 vSize = { H::Draw.Scale(12), H::Draw.Scale(12) }, ImVec2 vIconOffset = {}), VA_LIST(&tVal, iFlags, vOffset, vSize, vIconOffset))
	WRAPPER(FColorPicker, Gradient_t, VA_LIST(bool bStart = true, int iFlags = 0, ImVec2 vOffset = {}, ImVec2 vSize = { H::Draw.Scale(12), H::Draw.Scale(12) }, ImVec2 vIconOffset = {}), VA_LIST(bStart ? &tVal.StartColor : &tVal.EndColor, iFlags, vOffset, vSize, vIconOffset))

	// Dedicated left-hand color grid; no hard-coded offsets into neighboring controls.
	inline bool FColoredDropdown(ConfigVar<int>& setting, std::initializer_list<ConfigVar<Color_t>*> colors, int flags = 0)
	{
		const int count = int(colors.size());
		const int columns = std::max(1, (count + 1) / 2);
		const int rows = count > 1 ? 2 : 1;
		const float cell = H::Draw.Scale(12), gap = H::Draw.Scale(2);
		AttachedDropdownWidth = columns * cell + (columns - 1) * gap + H::Draw.Scale(4);
		const bool changed = FDropdown(setting, flags);
		const ImVec2 next = GetCursorPos();
		// Swatches are overlays within the dropdown row. SameLine reads the
		// previous item baseline, not just the cursor restored below.
		auto& layout = GetCurrentWindow()->DC;
		const ImVec2 previousPosition = layout.CursorPosPrevLine;
		const ImVec2 previousSize = layout.PrevLineSize;
		const ImVec2 currentSize = layout.CurrLineSize;
		const float previousBaseline = layout.PrevLineTextBaseOffset;
		const float currentBaseline = layout.CurrLineTextBaseOffset;
		const bool sameLine = layout.IsSameLine;
		const bool setPosition = layout.IsSetPos;
		const ImVec2 origin = AttachedDropdownOrigin;
		const float top = (AttachedDropdownHeight - (rows * cell + (rows - 1) * gap)) * 0.5f;
		int index = 0;
		for (auto* color : colors)
		{
			SetCursorPos(origin + ImVec2((index / rows) * (cell + gap), top + (index % rows) * (cell + gap)));
			FColorPicker(*color, AttachedColorPicker | FColorPickerEnum::Tooltip, {}, { cell, cell });
			++index;
		}
		SetCursorPos(next);
		layout.CursorPosPrevLine = previousPosition;
		layout.PrevLineSize = previousSize;
		layout.CurrLineSize = currentSize;
		layout.PrevLineTextBaseOffset = previousBaseline;
		layout.CurrLineTextBaseOffset = currentBaseline;
		layout.IsSameLine = sameLine;
		layout.IsSetPos = setPosition;
		return changed;
	}

}
