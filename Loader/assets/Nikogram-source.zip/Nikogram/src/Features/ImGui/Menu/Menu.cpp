#include "Menu.h"
#include "BindLayout.h"
#include "../MoonlitHud.h"
#include "../../Backtrack/Backtrack.h"
#include "../../NoSpread/NoSpreadHitscan/NoSpreadHitscan.h"
#include "../../Visuals/PlayerConditions/PlayerConditions.h"

#include "Components.h"
#include "../../Triggerbot/TriggerPolicy.h"
#include "../Workspace.h"
#include "../MenuPresets.h"
#include "../Pet.h"
#include "../Notifications/Notifications.h"
#include "../../Configs/Configs.h"
#include "../../Binds/Binds.h"
#include "../../Binds/BindPresentation.h"
#include "../../CritHack/CritHack.h"
#include "../../Ticks/Ticks.h"
#include "../../Visuals/SpectatorList/SpectatorList.h"
#include "../../Visuals/Groups/Groups.h"
#include "../../Visuals/Radar/Radar.h"
#include "../../Players/PlayerUtils.h"
#include "../../Spectate/Spectate.h"
#include "../../Blockbot/Blockbot.h"
#include "../../Resolver/Resolver.h"
#include "../../Visuals/Visuals.h"
#include "../../Misc/Misc.h"
#include "../../PacketManip/RealLag/RealLag.h"
#include "../../Statistics/Statistics.h"
#include "../../SkinChanger/SkinChanger.h"
#include "../../LearningAccess.h"
#include "../../Output/Output.h"
#include "../../World/World.h"
#include "../../Simulation/ProjectileSimulation/ProjectileSimulation.h"

// bind currently loaded into the bind editor (Settings > Menu > Binds), file scope so bind removal elsewhere can keep it valid
static int s_iEditBind = DEFAULT_BIND;
static Bind_t s_tEditBind = {};

// whether iIndex is iBind or one of its children (the same set CBinds::RemoveBind removes)
static inline bool IsBindOrChild(int iIndex, int iBind)
{
	for (size_t i = 0; i <= F::Binds.m_vBinds.size() && iIndex > DEFAULT_BIND && iIndex < F::Binds.m_vBinds.size(); i++) // bounded in case of parent cycles
	{
		if (iIndex == iBind)
			return true;
		iIndex = F::Binds.m_vBinds[iIndex].m_iParent;
	}
	return false;
}

// index iIndex will have after iBind (and its children) is removed, DEFAULT_BIND if it is removed itself
static inline int RemapBindIndex(int iIndex, int iBind)
{
	if (iIndex <= DEFAULT_BIND || iIndex >= F::Binds.m_vBinds.size())
		return iIndex;
	if (IsBindOrChild(iIndex, iBind))
		return DEFAULT_BIND;

	int iNew = iIndex;
	for (int i = 0; i < iIndex; i++)
	{
		if (IsBindOrChild(i, iBind))
			iNew--;
	}
	return iNew;
}

// removes a bind and keeps the indices held by the menu (current bind, bind editor) pointing at the same binds
static inline void RemoveBindAndRemap(int iBind)
{
	if (iBind <= DEFAULT_BIND || iBind >= F::Binds.m_vBinds.size())
		return;

	int iCurrentBind = RemapBindIndex(ImGui::CurrentBind, iBind);
	int iEditBind = RemapBindIndex(s_iEditBind, iBind);
	int iEditParent = RemapBindIndex(s_tEditBind.m_iParent, iBind);

	F::Binds.RemoveBind(iBind);

	ImGui::CurrentBind = iCurrentBind;
	if (s_iEditBind != DEFAULT_BIND && iEditBind == DEFAULT_BIND)
	{
		s_iEditBind = DEFAULT_BIND;
		s_tEditBind = {};
	}
	else
	{
		s_iEditBind = iEditBind;
		s_tEditBind.m_iParent = iEditParent;
	}
}

// ActiveGroups is a 32 bit mask indexed by group, so it has to follow the groups when they are removed, inserted or moved
static inline uint32_t GroupMaskRemove(uint32_t uMask, int iIndex)
{
	if (iIndex < 0 || iIndex >= 32)
		return uMask;
	uint32_t uLow = uMask & ((1u << iIndex) - 1);
	uint32_t uHigh = iIndex < 31 ? (uMask >> (iIndex + 1)) << iIndex : 0u;
	return uLow | uHigh | 1u << 31; // unused bits default to active
}
static inline uint32_t GroupMaskInsert(uint32_t uMask, int iIndex, bool bValue)
{
	if (iIndex < 0 || iIndex >= 32)
		return uMask;
	uint32_t uLow = uMask & ((1u << iIndex) - 1);
	uint32_t uHigh = iIndex < 31 ? (uMask >> iIndex) << (iIndex + 1) : 0u;
	return uLow | uHigh | (bValue ? 1u << iIndex : 0u);
}
static inline void RemapActiveGroups(const std::function<uint32_t(uint32_t)>& fRemap)
{
	for (auto& iMask : Vars::ESP::ActiveGroups.Map | std::views::values)
		iMask = int(fRemap(uint32_t(iMask)));
	Vars::ESP::ActiveGroups.Value = int(fRemap(uint32_t(Vars::ESP::ActiveGroups.Value)));
}

// cached directory listings, refreshed at most once a second (or after invalidation) instead of walking the filesystem every frame
static std::unordered_map<std::string, std::pair<std::vector<std::filesystem::directory_entry>, double>> s_mDirectoryCache = {};
static inline void InvalidateDirectoryCache()
{
	s_mDirectoryCache.clear();
}
static inline const std::vector<std::filesystem::directory_entry>& GetDirectoryEntries(const std::string& sPath, bool* pRefreshed = nullptr)
{
	auto it = s_mDirectoryCache.find(sPath);
	double dTime = ImGui::GetTime();
	bool bRefresh = it == s_mDirectoryCache.end() || dTime - it->second.second > 1.0;
	if (pRefreshed)
		*pRefreshed = bRefresh;
	if (!bRefresh)
		return it->second.first;

	auto& [vEntries, dLastRefresh] = s_mDirectoryCache[sPath];
	vEntries.clear();
	dLastRefresh = dTime;

	std::error_code tError; // error_code overloads so a missing or locked folder doesn't throw inside the present hook
	for (auto itEntry = std::filesystem::directory_iterator(sPath, tError); !tError && itEntry != std::filesystem::directory_iterator(); itEntry.increment(tError))
		vEntries.push_back(*itEntry);
	return vEntries;
}

void CMenu::DrawMenu()
{
    using namespace ImGui;
    enum { Main, Players, Configs, Logs, Interface, About, Stats, Count };
    static const char* names[Count] = { "Main Menu", "Player Manager", "Configs", "Logs", "Interface", "About", "Statistics" };
    static const char* ids[Count] = { "Main Menu###DesktopMain", "Player Manager###DesktopPlayers", "Configs###DesktopConfigs",
        "Logs###DesktopLogs", "Interface###DesktopInterface", "About###DesktopAbout", "Statistics###DesktopStatistics" };
    static bool open[Count] = {}, minimized[Count] = {};
    static int active = -1, focus = -1, mainTab = 0, aimTab = 0, visualTab = 0, configTab = 0;
    static bool resetLayout = false;
    const bool applyReset = resetLayout;
    resetLayout = false;
    static std::string search;
    const ImVec2 screen = GetIO().DisplaySize;
	NikoPet::World.windows.clear();
    if (screen.x < 180.f || screen.y < 100.f) return;
    static bool resetPending[Count] = {};
    if (applyReset) std::fill(std::begin(resetPending), std::end(resetPending), true);
    const float barHeight = H::Draw.Scale(20) + H::Draw.Scale(3) * 2;
    const float top = Workspace::TopTaskbar ? barHeight : 0.f;
    const float bottom = screen.y - (Workspace::TopTaskbar ? 0.f : barHeight);
    const auto launch = [&](int index) { open[index] = true; minimized[index] = false; focus = index; active = index; };
    Bind_t bind;
    if (!F::Binds.GetBind(CurrentBind, &bind)) CurrentBind = DEFAULT_BIND;

    // These overrides are scoped to the desktop: HUD editor windows keep their own geometry.
    PushStyleVar(ImGuiStyleVar_WindowPadding, { H::Draw.Scale(6), H::Draw.Scale(5) });
    PushStyleVar(ImGuiStyleVar_FramePadding, { H::Draw.Scale(4), H::Draw.Scale(2) });
    PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(4), H::Draw.Scale(3) });
    PushStyleVar(ImGuiStyleVar_WindowTitleAlign, { 0.5f, 0.5f });
    PushFont(F::Render.FontSmall);

    const auto tabs = [&](const char* id, std::initializer_list<const char*> labels, int& selected) {
        PushID(id);
        int index = 0;
        for (const char* label : labels)
        {
            if (index) SameLine(0, H::Draw.Scale(2));
            PushStyleColor(ImGuiCol_Button, selected == index ? F::Render.Background1p5L.Value : F::Render.Background0.Value);
            if (Button(label)) selected = index;
            PopStyleColor();
            ++index;
        }
        PopID();
    };

    for (int i = 0; i < Count; ++i)
    {
        if (!open[i] || minimized[i]) continue;
        ImVec2 initialSize = i == Players ? ImVec2(830, 410) : i == Interface ? ImVec2(470, 390)
            : i == About ? ImVec2(300, 145) : ImVec2(730, 560);
        ImVec2 initialPos = i == Players ? ImVec2(30, 25) : i == Interface ? ImVec2(920, 320)
            : i == About ? ImVec2(840, 90) : ImVec2(285 + 22.f * i, 150 + 18.f * i);
        initialSize = initialSize * Vars::Menu::Scale.Value;
        initialSize.x = std::min(initialSize.x, screen.x - 12);
        initialSize.y = std::min(initialSize.y, bottom - top - 12);
        initialPos = initialPos * Vars::Menu::Scale.Value;
        initialPos.x = std::clamp(initialPos.x, 0.f, std::max(0.f, screen.x - initialSize.x));
        initialPos.y = std::clamp(initialPos.y + top, top, std::max(top, bottom - initialSize.y));
        SetNextWindowPos(initialPos, resetPending[i] ? ImGuiCond_Always : ImGuiCond_FirstUseEver);
        SetNextWindowSize(initialSize, resetPending[i] ? ImGuiCond_Always : ImGuiCond_FirstUseEver);
        // Constrain position BEFORE Begin calculates the window's clip/work rectangles.
        // Moving it afterwards leaves content clipped against the old off-screen position.
        if (!resetPending[i])
        {
            if (const ImGuiWindow* existing = FindWindowByName(ids[i]))
            {
                const ImVec2 size = existing->SizeFull;
                ImVec2 corrected = existing->Pos;
                const float maxX = std::max(0.f, screen.x - size.x);
                const float maxY = std::max(top, bottom - size.y);
                corrected.x = std::clamp(corrected.x, 0.f, maxX);
                corrected.y = std::clamp(corrected.y, top, maxY);
                if (Workspace::Snap && IsMouseReleased(ImGuiMouseButton_Left))
                {
                    const float distance = H::Draw.Scale(12);
                    if (corrected.x < distance) corrected.x = 0.f;
                    else if (maxX - corrected.x < distance) corrected.x = maxX;
                    if (corrected.y - top < distance) corrected.y = top;
                    else if (maxY - corrected.y < distance) corrected.y = maxY;
                }
                SetNextWindowPos(corrected, ImGuiCond_Always);
            }
        }
        resetPending[i] = false;
        SetNextWindowSizeConstraints({ std::min(H::Draw.Scale(i == About ? 250 : 410), screen.x - 12),
            std::min(H::Draw.Scale(100), bottom - top - 12) }, { screen.x - 4, bottom - top - 4 });
        if (focus == i) { SetNextWindowFocus(); focus = -1; }
        const bool visible = Begin(ids[i], &open[i], ImGuiWindowFlags_NoCollapse);
		if (visible && open[i])
		{
			const auto pos = GetWindowPos(), size = GetWindowSize();
			NikoPet::World.windows.push_back({ i, pos.x, pos.y, pos.x + size.x, pos.y + size.y });
		}
        if (IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows)) active = i;
        if (visible)
        {
            PushID(i);
            // A real title-bar item: temporarily leave the content clip rectangle.
            // Keep ImGui's native close button and dragging, with minimize beside X.
            ImGuiWindow* window = GetCurrentWindow();
            const ImRect title = window->TitleBarRect();
            const float closeLeft = title.Max.x - window->WindowBorderSize - GetStyle().FramePadding.x - GetFontSize();
            const float buttonSize = title.GetHeight();
            const ImRect minimizeRect(
                ImVec2(closeLeft - H::Draw.Scale(2) - buttonSize, title.Min.y),
                ImVec2(closeLeft - H::Draw.Scale(2), title.Max.y));
            const ImGuiID minimizeID = window->GetID("##TitleMinimize");
            PushClipRect(title.Min, title.Max, false);
            bool hovered = false, held = false;
            const ImGuiNavLayer previousLayer = window->DC.NavLayerCurrent;
            window->DC.NavLayerCurrent = ImGuiNavLayer_Menu;
            if (ItemAdd(minimizeRect, minimizeID))
            {
                if (ButtonBehavior(minimizeRect, minimizeID, &hovered, &held, ImGuiButtonFlags_NoNavFocus))
                {
                    minimized[i] = true;
                    active = -1;
                }
                auto* draw = GetWindowDrawList();
                if (hovered)
                    draw->AddRectFilled(minimizeRect.Min, minimizeRect.Max,
                        GetColorU32(held ? ImGuiCol_ButtonActive : ImGuiCol_ButtonHovered));
                draw->AddRect(minimizeRect.Min, minimizeRect.Max, GetColorU32(F::Render.Accent.Value));
                const float inset = std::max(3.f, buttonSize * 0.25f);
                const float underlineY = minimizeRect.Max.y - std::max(3.f, buttonSize * 0.2f);
                draw->AddLine(ImVec2(minimizeRect.Min.x + inset, underlineY),
                    ImVec2(minimizeRect.Max.x - inset, underlineY), GetColorU32(ImGuiCol_Text));
                // Border the neighboring native X to form a matching pair.
                draw->AddRect(ImVec2(closeLeft - H::Draw.Scale(1), title.Min.y),
                    ImVec2(title.Max.x - window->WindowBorderSize, title.Max.y), GetColorU32(F::Render.Accent.Value));
            }
            {
                ImGuiContext& g = *GImGui;
                IMGUI_TEST_ENGINE_ITEM_INFO(minimizeID, "Minimize to taskbar", g.LastItemData.StatusFlags);
            }
            window->DC.NavLayerCurrent = previousLayer;
            PopClipRect();
            if (hovered) SetTooltip("Minimize to taskbar");
            if (CurrentBind != DEFAULT_BIND)
            {
                TextColored(F::Render.Accent, "Editing bind: %s", bind.m_sName.c_str());
                SameLine();
                if (SmallButton("Stop")) CurrentBind = DEFAULT_BIND;
                Separator();
            }
            if (i == Main)
            {
                tabs("categories", { "Aim", "Triggerbot", "HvH", "Visuals", "Misc", "Tools" }, mainTab);
                if (mainTab == 0) tabs("aim", { "General", "Draw" }, aimTab);
                if (mainTab == 3) tabs("visuals", { "ESP", "World / camera", "Menu / HUD" }, visualTab);
                SetNextItemWidth(-1);
                InputTextWithHint("##Search", "Search all settings...", &search);
                if (BeginChild("SettingsPage", {}, ImGuiChildFlags_AlwaysUseWindowPadding))
                {
                    if (!search.empty()) MenuSearch(search);
                    else switch (mainTab)
                    {
                    case 0: MenuAimbot(aimTab); break;
                    case 1: MenuTriggerbot(); break;
                    case 2: MenuHVH(); break;
                    case 3: MenuVisuals(visualTab); break;
                    case 4: MenuMisc(); break;
                    case 5: MenuSettings(3); break;
                    }
                }
                EndChild();
            }
            else if (i == Players)
            {
                if (BeginChild("PlayerPage", {}, ImGuiChildFlags_AlwaysUseWindowPadding)) MenuLogs(0);
                EndChild();
            }
            else if (i == Configs)
            {
                tabs("configs", { "Configs", "Binds", "Materials" }, configTab);
                if (BeginChild("ConfigPage", {}, ImGuiChildFlags_AlwaysUseWindowPadding)) MenuSettings(configTab);
                EndChild();
            }
            else if (i == Logs)
            {
                if (BeginChild("LogPage", {}, ImGuiChildFlags_AlwaysUseWindowPadding)) MenuLogs(2);
                EndChild();
            }
            else if (i == Stats)
            {
                if (BeginChild("StatisticsPage", {}, ImGuiChildFlags_AlwaysUseWindowPadding)) Statistics::Draw();
                EndChild();
            }
            else if (i == Interface)
            {
                if (DrawInterfacePreferences()) { launch(Main); mainTab = 3; visualTab = 2; search.clear(); }
            }
            else
            {
                TextUnformatted("nikogram");
                Separator();
                TextWrapped("Desktop workspace\nIndependent windows, compact controls and a taskbar.\nBased on Amalgam.");
            }
            PopID();
        }
        End();
    }
    int openCount = 0;
    for (bool value : open) if (value) ++openCount;
    const float width = Workspace::CompactTaskbar ? std::min(screen.x, H::Draw.Scale(40 + 132 * openCount)) : screen.x;
	NikoPet::World.width = screen.x; NikoPet::World.height = screen.y;
	NikoPet::World.barWidth = width; NikoPet::World.barHeight = barHeight; NikoPet::World.top = Workspace::TopTaskbar;
    SetNextWindowPos({ 0, Workspace::TopTaskbar ? 0.f : screen.y - barHeight });
    SetNextWindowSize({ width, barHeight });
    PushStyleVar(ImGuiStyleVar_WindowPadding, { H::Draw.Scale(3), H::Draw.Scale(3) });
    // The normal minimum window height otherwise adds an empty strip below this compact bar.
    PushStyleVar(ImGuiStyleVar_WindowMinSize, { 0.f, 0.f });
    if (Begin("##NikogramTaskbar", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoScrollWithMouse))
    {
        const ImVec2 launcherPos = GetCursorScreenPos();
        if (Button("##NikoLauncher", { H::Draw.Scale(26), H::Draw.Scale(20) })) OpenPopup("Launcher");
        if (const auto icon = F::Render.NikoLauncherIcon())
            GetWindowDrawList()->AddImage(icon, launcherPos + ImVec2(H::Draw.Scale(4), H::Draw.Scale(1)),
                launcherPos + ImVec2(H::Draw.Scale(22), H::Draw.Scale(19)), { 1, 0 }, { 0, 1 });
        if (IsPopupOpen("Launcher"))
            SetNextWindowPos({ 0, Workspace::TopTaskbar ? barHeight : screen.y - barHeight }, ImGuiCond_Always,
                { 0, Workspace::TopTaskbar ? 0.f : 1.f });
        PushStyleColor(ImGuiCol_PopupBg, F::Render.Background0.Value);
        PushStyleColor(ImGuiCol_Border, F::Render.Accent.Value);
        if (BeginPopup("Launcher"))
        {
            const float launcherWidth = H::Draw.Scale(264);
            const bool privacy = Vars::Visuals::UI::StreamerMode.Value >= Vars::Visuals::UI::StreamerModeEnum::Local;
            std::string playerName = "Local";
            const bool inGame = I::EngineClient && I::EngineClient->IsInGame();
            // Do not even request identifying strings when privacy is enabled.
            if (!privacy)
            {
                player_info_t info = {};
                const int local = I::EngineClient ? I::EngineClient->GetLocalPlayer() : 0;
                if (local > 0 && I::EngineClient->GetPlayerInfo(local, &info) && info.name[0])
                    playerName = F::PlayerUtils.GetPlayerName(local, info.name);
                else if (I::SteamFriends)
                {
                    const char* persona = I::SteamFriends->GetPersonaName();
                    if (persona && *persona) playerName = persona;
                }
            }
            const ImVec2 profilePos = GetCursorScreenPos();
            const float gap = H::Draw.Scale(3);
            const float avatarSize = H::Draw.Scale(62);
            const float lineHeight = H::Draw.Scale(20);
            const ImVec2 profileSize(launcherWidth, avatarSize);
            Dummy(profileSize);
            auto* launcherDraw = GetWindowDrawList();
            const ImU32 border = GetColorU32(F::Render.Accent.Value);
            const auto avatar = F::Render.LauncherAvatar(privacy);
            if (avatar)
                launcherDraw->AddImage(avatar, profilePos + ImVec2(1, 1), profilePos + ImVec2(avatarSize - 1, avatarSize - 1));
            else
                launcherDraw->AddText(profilePos + ImVec2(H::Draw.Scale(26), H::Draw.Scale(22)), GetColorU32(ImGuiCol_Text), "?");
            launcherDraw->AddRect(profilePos, profilePos + ImVec2(avatarSize, avatarSize), border);
            const std::string profileLines[] = {
                playerName, privacy ? "Privacy mode" : inGame ? "In game" : "Main menu",
                std::format("Config: {}", F::Configs.m_sCurrentConfig)
            };
            for (int row = 0; row < 3; ++row)
            {
                const ImVec2 p = profilePos + ImVec2(avatarSize + gap, row * (lineHeight + H::Draw.Scale(1)));
                const ImVec2 end(profilePos.x + launcherWidth, p.y + lineHeight);
                launcherDraw->AddRectFilled(p, end, GetColorU32(F::Render.Background0.Value));
                launcherDraw->AddRect(p, end, border);
                launcherDraw->PushClipRect(p + ImVec2(H::Draw.Scale(4), 1), end - ImVec2(H::Draw.Scale(3), 1), true);
                launcherDraw->AddText(p + ImVec2(H::Draw.Scale(4), (lineHeight - GetTextLineHeight()) / 2),
                    GetColorU32(ImGuiCol_Text), profileLines[row].c_str());
                launcherDraw->PopClipRect();
            }
            const ImVec2 bodyPos = GetCursorScreenPos();
            const float leftWidth = H::Draw.Scale(164);
            const float rightWidth = launcherWidth - leftWidth - gap;
            const float bodyHeight = H::Draw.Scale(238);
            launcherDraw->AddRectFilled(bodyPos, bodyPos + ImVec2(leftWidth, bodyHeight), GetColorU32(F::Render.Background0.Value));
            launcherDraw->AddRectFilled(bodyPos + ImVec2(leftWidth + gap, 0), bodyPos + ImVec2(launcherWidth, bodyHeight), GetColorU32(F::Render.Background0.Value));
            launcherDraw->AddRect(bodyPos, bodyPos + ImVec2(leftWidth, bodyHeight), border);
            launcherDraw->AddRect(bodyPos + ImVec2(leftWidth + gap, 0), bodyPos + ImVec2(launcherWidth, bodyHeight), border);
            const auto launcherButton = [&](const char* label, const char* icon, ImVec2 pos, ImVec2 size)
            {
                SetCursorScreenPos(pos);
                PushStyleColor(ImGuiCol_Button, F::Render.Background0.Value);
                const bool pressed = Button(std::format("##Launcher{}", label).c_str(), size);
                PopStyleColor();
                const bool hovered = IsItemHovered();
                if (hovered) SetMouseCursor(ImGuiMouseCursor_Hand);
                launcherDraw->AddRect(pos, pos + size, border);
                const float textX = icon ? H::Draw.Scale(30) : std::max(H::Draw.Scale(3), (size.x - CalcTextSize(label).x) / 2);
                launcherDraw->PushClipRect(pos + ImVec2(2, 1), pos + size - ImVec2(2, 1), true);
                if (icon)
                    launcherDraw->AddText(F::Render.IconFont, H::Draw.Scale(16), pos + ImVec2(H::Draw.Scale(7), (size.y - H::Draw.Scale(16)) / 2),
                        GetColorU32(F::Render.Accent.Value), icon);
                launcherDraw->AddText(pos + ImVec2(textX, (size.y - GetTextLineHeight()) / 2), GetColorU32(ImGuiCol_Text), label);
                launcherDraw->PopClipRect();
                if (hovered && CalcTextSize(label).x > size.x - textX - H::Draw.Scale(3)) SetTooltip("%s", label);
                return pressed;
            };
            const int primary[] = { Main, Players, Configs, Logs, Interface, Stats, About };
            const char* primaryIcons[] = { ICON_MD_HOME, ICON_MD_PEOPLE, ICON_MD_FOLDER, ICON_MD_LIST_ALT, ICON_MD_SETTINGS, ICON_MD_LIST_ALT, ICON_MD_INFO };
            for (int row = 0; row < 7; ++row)
                if (launcherButton(names[primary[row]], primaryIcons[row],
                    bodyPos + ImVec2(0, row * H::Draw.Scale(30)), { leftWidth, H::Draw.Scale(28) }))
                {
                    launch(primary[row]); CloseCurrentPopup();
                }
            const char* shortcuts[] = { "Full update", "Retry", "Console", "Reload materials", "Minimise all", "Reset layout", "Hide" };
            for (int row = 0; row < 7; ++row)
                if (launcherButton(shortcuts[row], nullptr,
                    bodyPos + ImVec2(leftWidth + gap, row * H::Draw.Scale(26)), { rightWidth, H::Draw.Scale(24) }))
                {
                    if (row == 0) I::EngineClient->ClientCmd_Unrestricted("cl_fullupdate");
                    else if (row == 1) I::EngineClient->ClientCmd_Unrestricted("retry");
                    else if (row == 2) I::EngineClient->ClientCmd_Unrestricted("toggleconsole");
                    else if (row == 3) { if (F::Materials.m_bLoaded) F::Materials.ReloadMaterials(); }
                    else if (row == 4)
                    {
                        for (int window = 0; window < Count; ++window) if (open[window]) minimized[window] = true;
                        active = -1;
                    }
                    else if (row == 5) resetLayout = true;
                    else { m_bIsOpen = false; I::MatSystemSurface->SetCursorAlwaysVisible(false); }
                    CloseCurrentPopup();
                }
            launcherDraw->AddText(bodyPos + ImVec2(H::Draw.Scale(7), bodyHeight - H::Draw.Scale(17)),
                GetColorU32(F::Render.Inactive.Value), "nikogram");
            // Register the full two-column panel without using cursor movement as size.
            SetCursorScreenPos(bodyPos);
            Dummy({ launcherWidth, bodyHeight });
            EndPopup();
        }
        PopStyleColor(2);
        const float tabWidth = std::min(H::Draw.Scale(128), std::max(28.f, (width - H::Draw.Scale(38)) / std::max(1, openCount) - H::Draw.Scale(4)));
        for (int i = 0; i < Count; ++i)
        {
            if (!open[i]) continue;
            SameLine();
            PushID(i);
            PushStyleColor(ImGuiCol_Button, active == i && !minimized[i] ? F::Render.Background1p5L.Value : F::Render.Background0.Value);
            if (Button(names[i], { tabWidth, H::Draw.Scale(20) }))
            {
                if (active == i && !minimized[i]) { minimized[i] = true; active = -1; }
                else launch(i);
            }
            PopStyleColor();
            if (BeginPopupContextItem("WindowActions"))
            {
                if (MenuItem("Restore")) launch(i);
                if (MenuItem("Minimize")) minimized[i] = true;
                if (MenuItem("Close")) open[i] = false;
                EndPopup();
            }
            PopID();
        }
    }
    End();
    PopStyleVar(2);
    PopFont();
    PopStyleVar(4);
}

#pragma region Tabs

void CMenu::DrawMenuStyleChoice()
{
    using namespace ImGui;
    TextUnformatted("Menu style");
    int choice = MenuMode::Pending >= 0 ? MenuMode::Pending : MenuMode::Active;
    SetNextItemWidth(std::min(GetContentRegionAvail().x, H::Draw.Scale(260)));
    if (Combo("##MenuStyle", &choice, "Nullcore\0Moonlit\0")) MenuMode::Choose(choice);
    if (MenuMode::Pending >= 0) TextWrapped("Menu style will change when you close the menu.");
    if (!m_sInterfaceStatus.empty()) TextWrapped("%s", m_sInterfaceStatus.c_str());
    Separator();
}

bool CMenu::DrawInterfacePreferences(bool showStyleChoice)
{
    using namespace ImGui;
    bool openHUD = false;
    if (showStyleChoice) DrawMenuStyleChoice();
                MenuPresets::Load();
                static int selectedPreset = -2; // Existing workspace colours may not match a preset.
                static char presetName[128] = "";
                static std::string loadedPreset;
                int saveRow = -1, deleteRow = -1;
                TextUnformatted("Menu configs");
                PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4, 2));
                if (BeginChild("MenuPresetList", { 0, H::Draw.Scale(90) }, ImGuiChildFlags_Borders))
                {
                    for (int index = 0; index < int(MenuPresets::Items.size()); ++index)
                    {
                        const auto& preset = MenuPresets::Items[index];
                        PushID(index);
                        const ImVec2 pos = GetCursorScreenPos();
                        const float rowWidth = GetContentRegionAvail().x;
                        const ImVec2 rowStart = GetCursorPos();
                        GetWindowDrawList()->AddRectFilled(pos, pos + ImVec2(rowWidth, H::Draw.Scale(22)), IM_COL32(55, 55, 55, 255));
                        SetCursorPos(rowStart + ImVec2(0, H::Draw.Scale(1)));
                        if (CompactManagerIcon(loadedPreset == preset.name ? ICON_MD_REFRESH : ICON_MD_DOWNLOAD))
                        {
                            selectedPreset = index;
                            snprintf(presetName, sizeof(presetName), "%s", preset.name.c_str());
                            MenuPresets::Apply(preset);
                            loadedPreset = preset.name;
                            m_sInterfaceStatus = Workspace::Save() ? "Menu config loaded." : "Loaded, but could not save workspace preferences.";
                        }
                        if (IsItemHovered()) SetTooltip(loadedPreset == preset.name ? "Reload config" : "Load config");
                        SetCursorPos(rowStart + ImVec2(H::Draw.Scale(25), 0));
                        const float nameWidth = std::max(1.f, rowWidth - H::Draw.Scale(77));
                        if (Selectable(TruncateText(preset.name, nameWidth).c_str(), selectedPreset == index, 0, { nameWidth, H::Draw.Scale(22) }))
                        {
                            selectedPreset = index;
                            snprintf(presetName, sizeof(presetName), "%s", preset.name.c_str());
                        }
                        PushDisabled(!MenuPresets::Writable);
                        SetCursorPos(rowStart + ImVec2(rowWidth - H::Draw.Scale(47), H::Draw.Scale(1)));
                        if (CompactManagerIcon(ICON_MD_SAVE)) saveRow = index;
                        if (IsItemHovered()) SetTooltip("Save current settings / rename");
                        SetCursorPos(rowStart + ImVec2(rowWidth - H::Draw.Scale(22), H::Draw.Scale(1)));
                        if (CompactManagerIcon(ICON_MD_DELETE)) deleteRow = index;
                        if (IsItemHovered()) SetTooltip("Delete config");
                        PopDisabled();
                        SetCursorPos(rowStart); Dummy({ rowWidth, H::Draw.Scale(22) });
                        PopID();
                    }
                }
                EndChild();
                SetNextItemWidth(-1);
                InputTextWithHint("##MenuPresetName", "Config name...", presetName, sizeof(presetName));
                auto savePreset = [&](bool create)
                {
                    std::string name = presetName;
                    const auto first = name.find_first_not_of(" \t\r\n");
                    if (first == std::string::npos) { m_sInterfaceStatus = "Enter a config name first."; return; }
                    name = name.substr(first, name.find_last_not_of(" \t\r\n") - first + 1);
                    auto items = MenuPresets::Items;
                    for (int n = 0; n < int(items.size()); ++n)
                        if ((create || n != selectedPreset) && _stricmp(items[n].name.c_str(), name.c_str()) == 0)
                        { m_sInterfaceStatus = "That config name already exists."; return; }
                    const auto preset = MenuPresets::Capture(name);
                    int target = selectedPreset;
                    const bool renamingLoaded = !create && target >= 0 && items[target].name == loadedPreset;
                    if (create) { target = int(items.size()); items.push_back(preset); }
                    else items[target] = preset;
                    if (MenuPresets::Store(items))
                    {
                        selectedPreset = target;
                        if (renamingLoaded) loadedPreset = name;
                        m_sInterfaceStatus = Workspace::Save() ? "Menu config saved." : "Config saved, but workspace preferences could not be saved.";
                    }
                    else m_sInterfaceStatus = MenuPresets::Error;
                };
                BeginDisabled(!MenuPresets::Writable);
                if (Button("Create")) savePreset(true);
                EndDisabled();
                if (saveRow >= 0)
                {
                    if (selectedPreset != saveRow)
                        snprintf(presetName, sizeof(presetName), "%s", MenuPresets::Items[saveRow].name.c_str());
                    selectedPreset = saveRow;
                    savePreset(false);
                }
                if (deleteRow >= 0)
                {
                    selectedPreset = deleteRow;
                    snprintf(presetName, sizeof(presetName), "%s", MenuPresets::Items[deleteRow].name.c_str());
                    OpenPopup("Delete menu config?");
                }
                if (BeginPopupModal("Delete menu config?", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
                {
                    TextUnformatted("Delete the selected saved menu config?");
                    if (Button("Delete"))
                    {
                        auto items = MenuPresets::Items;
                        if (selectedPreset >= 0 && selectedPreset < int(items.size()))
                        {
                            const bool deletingLoaded = items[selectedPreset].name == loadedPreset;
                            items.erase(items.begin() + selectedPreset);
                            if (MenuPresets::Store(items)) { if (deletingLoaded) loadedPreset.clear(); selectedPreset = -2; presetName[0] = '\0'; m_sInterfaceStatus = "Config deleted; current appearance kept."; }
                            else m_sInterfaceStatus = MenuPresets::Error;
                        }
                        CloseCurrentPopup();
                    }
                    SameLine(); if (Button("Cancel")) CloseCurrentPopup();
                    EndPopup();
                }
                PopStyleVar();
                if (!MenuPresets::Error.empty()) TextWrapped("%s", MenuPresets::Error.c_str());
                Separator();
                TextUnformatted("Workspace preferences (separate from gameplay configs)");
                Separator();
                Checkbox("Compact taskbar", &Workspace::CompactTaskbar);
                Checkbox("Taskbar at top", &Workspace::TopTaskbar);
                Checkbox("Snap windows to screen edges", &Workspace::Snap);
                SliderFloat("Text scale", &Workspace::FontScale, 0.85f, 1.5f, "%.2fx");
                if (!MenuMode::DrawingMoonlit)
                {
                ColorEdit3("Accent", Workspace::Accent, ImGuiColorEditFlags_NoInputs);
                float borderColour[3] = { Workspace::BorderChannel(0), Workspace::BorderChannel(1), Workspace::BorderChannel(2) };
                if (ColorEdit3("Border / outline color", borderColour, ImGuiColorEditFlags_NoInputs))
                {
                    std::copy_n(borderColour, 3, Workspace::InterfaceBorderColour);
                    Workspace::InterfaceBorderCustom = true;
                    Workspace::InterfaceBorderSelected = true;
                }
                SameLine(); if (Button("Use accent##Border")) { Workspace::InterfaceBorderSelected = true; Workspace::InterfaceBorderCustom = false; }
                SameLine(); if (Button("Use config##Border")) Workspace::InterfaceBorderSelected = false;
                ColorEdit3("Background", Workspace::Background, ImGuiColorEditFlags_NoInputs);
                float activeText[3] = { Workspace::TextChannel(0), Workspace::TextChannel(1), Workspace::TextChannel(2) };
                if (ColorEdit3("Text active", activeText, ImGuiColorEditFlags_NoInputs))
                { std::copy_n(activeText, 3, Workspace::TextColour); Workspace::TextColourOverride = true; }
                SameLine(); if (Button("Use accent##ActiveText")) Workspace::TextColourOverride = false;
                float inactiveText[3] = { Workspace::InactiveTextChannel(0), Workspace::InactiveTextChannel(1), Workspace::InactiveTextChannel(2) };
                if (ColorEdit3("Text inactive color", inactiveText, ImGuiColorEditFlags_NoInputs))
                { std::copy_n(inactiveText, 3, Workspace::InactiveTextColour); Workspace::InactiveTextOverride = true; }
                SameLine(); if (Button("Use darker accent##InactiveText")) Workspace::InactiveTextOverride = false;
                float titleText[3] = { Workspace::TitleTextChannel(0), Workspace::TitleTextChannel(1), Workspace::TitleTextChannel(2) };
                if (ColorEdit3("Text Title Color", titleText, ImGuiColorEditFlags_NoInputs))
                { std::copy_n(titleText, 3, Workspace::TitleTextColour); Workspace::TitleTextOverride = true; }
                SameLine(); if (Button("Use brighter accent##TitleText")) Workspace::TitleTextOverride = false;
                }
                else TextWrapped("Moonlit uses its own palette. Your Nullcore colours are preserved and can be edited in Nullcore.");
				Separator(); TextUnformatted("Pets");
                Checkbox("Pets enabled", &Workspace::PetEnabled);
                Checkbox("Niko", &Workspace::PetNiko);SameLine();Checkbox("Alula", &Workspace::PetAlula);SameLine();Checkbox("Calamus", &Workspace::PetCalamus);
                Checkbox("Quiet interactions", &Workspace::PetSocial);
                Checkbox("Scare game", &Workspace::PetScares);SameLine();Checkbox("Chase game", &Workspace::PetChase);
                Checkbox("The World Machine", &Workspace::PetWorldMachine);
                NikoPet::GameControls();
				Separator();
				SliderInt("Pet size", &Workspace::PetSize, 32, 128, "%d px", ImGuiSliderFlags_AlwaysClamp);
				if (Button("Small##Pet")) Workspace::PetSize = 48;
				SameLine(); if (Button("Medium##Pet")) Workspace::PetSize = 64;
				SameLine(); if (Button("Large##Pet")) Workspace::PetSize = 128;
				Checkbox("Occasional running", &Workspace::PetRun); SameLine(); Checkbox("Jumping", &Workspace::PetJump);
				Checkbox("Climb windows", &Workspace::PetClimb); SameLine(); Checkbox("Pick up / throw", &Workspace::PetDrag);
				SliderInt("Rest after", &Workspace::PetRest, 15, 600, "%d sec", ImGuiSliderFlags_AlwaysClamp);
				Workspace::PetSleep = std::max(Workspace::PetSleep, Workspace::PetRest + 15);
				SliderInt("Sleep after", &Workspace::PetSleep, Workspace::PetRest + 15, 1200, "%d sec", ImGuiSliderFlags_AlwaysClamp);
				TextWrapped("Menu-only pet. Top taskbar: gentle hanging/climbing, no running, jumping or sleeping. Drag and release to drop; release while moving to throw. Closing the menu resets rest timers.");
				Separator();
                TextWrapped("Drag title bars to move windows. Drag window edges to resize. Layout is remembered automatically.");
                if (!m_sInterfaceStatus.empty()) TextWrapped("%s", m_sInterfaceStatus.c_str());
                Separator();
                if (Button("Open menu / HUD settings")) openHUD = true;
                if (Button("Save interface preferences")) m_sInterfaceStatus = Workspace::Save() ? "Interface preferences saved." : "Could not save interface preferences.";

    return openHUD;
}

void CMenu::MenuTriggerbot()
{
	using namespace ImGui;
	if (Section("General"))
	{
		FDropdown(Vars::Triggerbot::Hitboxes);
		if (IsItemHovered()) SetTooltip("Selecting any hitbox enables hitscan triggerbot. None selected disables it. Fires without aiming; respects ignored players, walls and weapon readiness. Does not override manual shots or aimbot assistance. Miniguns must already be spun up; scope-only weapons must already be scoped. Projectiles, melee and release-fired Classic shots are excluded.");
		FSlider(Vars::Triggerbot::Delay);
		if (IsItemHovered()) SetTooltip("Drag: 0 to 0.5 seconds in 0.05-second increments. Click the value to enter any finite delay, including 999 seconds. Negative values mean zero delay. Losing the target resets the timer; the selected hitbox must still be under your cursor when it fires.");
		FToggle(Vars::Triggerbot::DynamicDelay);
		PushTransparent(!Vars::Triggerbot::DynamicDelay.Value);
		FSlider(Vars::Triggerbot::DelayMin, FSliderEnum::Left);
		FSlider(Vars::Triggerbot::DelayMax, FSliderEnum::Right);
		if (IsItemHovered()) SetTooltip("Chooses one random delay per attempt, not every frame. Effective bounds stay between 0.05 and 0.5 seconds; reversed bounds are reordered, equal bounds are separated by 0.05 seconds.");
		const auto delayBounds=TriggerPolicy::Bounds(FGet(Vars::Triggerbot::DelayMin),FGet(Vars::Triggerbot::DelayMax));
		FSet(Vars::Triggerbot::DelayMin,float(delayBounds.first));
		FSet(Vars::Triggerbot::DelayMax,float(delayBounds.second));
		PopTransparent();
		FDropdown(Vars::Triggerbot::Backtrack);
		if (IsItemHovered()) SetTooltip("Current hitboxes are always checked. Last checks only the oldest valid historical record for each enemy. All searches every valid record. Uses the existing backtrack timing window and never forces expired records.");
		FToggle(Vars::Triggerbot::BacktrackToCursor);
		if (IsItemHovered()) SetTooltip("Backtrack manually fired hitscan shots when your shot ray intersects a valid historical enemy hitbox. Uses the existing backtrack window. Does not aim or fire for you, and never overrides aimbot-assisted shots.");
	} EndSection();
}

void CMenu::MenuAimbot(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// General
	case 0:
	{
		if (BeginTable("AimbotTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("General"))
				{
					if (AimModes::Editing != AimModes::None)
					{
						auto style = FGet(Vars::Aimbot::General::AimType, true);
						const bool legit = AimModes::Editing == AimModes::Legit;
						FDropdown("Aim style", &style, legit ? std::vector<const char*>{"Smooth", "Assistive"} : std::vector<const char*>{"Plain", "Silent", "Locking"},
							legit ? std::vector<int>{2, 5} : std::vector<int>{1, 3, 4}, FDropdownEnum::Left);
						FSet(Vars::Aimbot::General::AimType, style);
					}
					else FDropdown(Vars::Aimbot::General::AimType, FDropdownEnum::Left);
					FDropdown(Vars::Aimbot::General::TargetSelection, FDropdownEnum::Right);
					FDropdown(Vars::Aimbot::General::Target, FDropdownEnum::Left);
					FDropdown(Vars::Aimbot::General::Ignore, FDropdownEnum::Right);
                    FDropdown(Vars::Aimbot::General::LeadAndRestrict, FDropdownEnum::InlineTitle);
                    if(IsItemHovered()) SetTooltip("Off: restrict current target position. Strict: restrict calculated firing direction and search alternative projectile candidates. Adaptive: first search strictly, then allow bounded close-range projectile exceptions for targets inside your FOV. Hitscan and melee use Strict in Adaptive mode. Auto-airblast is unchanged. Self-damage prevention still applies.");
					FSlider(Vars::Aimbot::General::AimFOV);
					FSlider(Vars::Aimbot::General::MaxTargets, FSliderEnum::Left);
					PushTransparent(!(Vars::Aimbot::General::Ignore.Value & Vars::Aimbot::General::IgnoreEnum::Invisible));
					{
						FSlider(Vars::Aimbot::General::IgnoreInvisible, FSliderEnum::Right);
					}
					PopTransparent();
					FSlider(Vars::Aimbot::General::AssistStrength, FSliderEnum::Left);
                    if(AimModes::Editing==AimModes::Legit)
                    {
                        if(FGet(Vars::Aimbot::General::CombinedGuidance,true))
                        {
                            FSlider(Vars::Aimbot::General::SmoothAmount,FSliderEnum::Left);
                            FSlider(Vars::Aimbot::General::AssistAmount,FSliderEnum::Right);
                            FDropdown(Vars::Aimbot::General::AssistHitbox);
                            FSlider(Vars::Aimbot::General::SmoothTime);
                        }
                    }
                    if(FGet(Vars::Aimbot::General::AimType,true)==Vars::Aimbot::General::AimTypeEnum::Smooth
                        &&!(AimModes::Editing==AimModes::Legit&&FGet(Vars::Aimbot::General::CombinedGuidance,true)))
                    {
                        FDropdown(Vars::Aimbot::General::SmoothFormula);
                        if(FGet(Vars::Aimbot::General::SmoothFormula,true)==Vars::Aimbot::General::SmoothFormulaEnum::Damped)
                        {
                            FSlider(Vars::Aimbot::General::SmoothTime);
                            if(AimModes::Editing!=AimModes::Legit)
                            {
                                FSlider(Vars::Aimbot::General::SmoothSpeed,FSliderEnum::Left);
                                FSlider(Vars::Aimbot::General::SmoothAcceleration,FSliderEnum::Right);
                            }
                        }
                    }
					PushTransparent(!(Vars::Aimbot::General::Ignore.Value & Vars::Aimbot::General::IgnoreEnum::Unsimulated));
					{
						FSlider(Vars::Aimbot::General::TickTolerance, FSliderEnum::Right);
					}
					PopTransparent();
					FColorPicker(Vars::Colors::FOVCircle);
					FToggle(Vars::Aimbot::General::AutoShoot, FToggleEnum::Left);
					FToggle(Vars::Aimbot::General::FOVCircle, FToggleEnum::Right);
					FToggle(Vars::Aimbot::General::NoSpread, FToggleEnum::Left);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Aimbot"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }, -8))
						{
							FDropdown(Vars::Aimbot::General::AimHoldsFire);
							FSlider(Vars::Aimbot::General::NoSpreadOffset);
							FSlider(Vars::Aimbot::General::NoSpreadAverage);
							FSlider(Vars::Aimbot::General::NoSpreadInterval);
							FSlider(Vars::Aimbot::General::NoSpreadBackupInterval);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Backtrack"))
				{
                    FSlider(Vars::Backtrack::Window);
                    if(IsItemHovered()) SetTooltip("Requested timing-error window in milliseconds, not a tick count. Effective window is capped at 200 ms minus one simulation tick to leave room below the server's rewind-time substitution threshold. At about 66 ticks/s this is about 185 ms. Zero uses the nearest safe record only. Invalid/teleported records and records outside the effective window are never forced as a fallback. Diagnostics log requested and effective values.");
					//FToggle(Vars::Backtrack::PreferOnShot);
				} EndSection();
				if (Section("Crit Hack"))
				{
					FToggle(Vars::CritHack::ForceCrits, FToggleEnum::Left);
					FToggle(Vars::CritHack::AvoidRandomCrits, FToggleEnum::Right);
					FToggle(Vars::CritHack::AlwaysMeleeCrit, FToggleEnum::Left);
					FToggle(Vars::CritHack::CritEffects, FToggleEnum::Right);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Backtrack"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FSlider(Vars::Backtrack::Offset);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Healing"))
				{
					FDropdown(Vars::Aimbot::Healing::HealPriority, FDropdownEnum::Left);
					FDropdown(Vars::Aimbot::Healing::DangerIgnore, FDropdownEnum::Right);
					FToggle(Vars::Aimbot::Healing::AutoHeal, FToggleEnum::Left);
					FToggle(Vars::Aimbot::Healing::AutoArrow, FToggleEnum::Right);
					FToggle(Vars::Aimbot::Healing::AutoRepair, FToggleEnum::Left);
					FToggle(Vars::Aimbot::Healing::AutoSandvich, FToggleEnum::Right);
					FToggle(Vars::Aimbot::Healing::AutoVaccinator, FToggleEnum::Left);
					FToggle(Vars::Aimbot::Healing::ActivateOnVoice, FToggleEnum::Right);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Healing"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Healing::AutoVaccinatorBulletScale);
							FSlider(Vars::Aimbot::Healing::AutoVaccinatorBlastScale);
							FSlider(Vars::Aimbot::Healing::AutoVaccinatorFireScale);
							FToggle(Vars::Aimbot::Healing::AutoVaccinatorFlamethrowerDamageOnly);

							EndPopup();
						}
					} EndSection();
				}
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Hitscan"))
				{
					FDropdown(Vars::Aimbot::Hitscan::Hitboxes, FDropdownEnum::Left);
					FDropdown(Vars::Aimbot::Hitscan::MultipointHitboxes, FDropdownEnum::Right);
					std::vector<const char*> hitscanModifierPreview;
					for (auto* option : { &Vars::Aimbot::Hitscan::PrioritizeMedics, &Vars::Aimbot::Hitscan::Extrapolation, &Vars::Aimbot::Hitscan::ExtrapolationGuide })
						if (FGet(*option)) hitscanModifierPreview.push_back(option->m_vNames.front());
					FModifierDropdown(Vars::Aimbot::Hitscan::Modifiers, [] {
						FDropdownToggle(Vars::Aimbot::Hitscan::PrioritizeMedics);
						bool extrapolationHovered=false;
						FDropdownToggle(Vars::Aimbot::Hitscan::Extrapolation, 0, &extrapolationHovered);
						FTooltip("Estimate a player's current server position from recent movement. Experimental: server lag compensation can make normal targeting more accurate.", extrapolationHovered);
						FDropdownToggle(Vars::Aimbot::Hitscan::ExtrapolationGuide);
					}, hitscanModifierPreview);
					FSlider(Vars::Aimbot::Hitscan::MultipointScale);
					PushTransparent(!(Vars::Aimbot::Hitscan::Modifiers.Value & Vars::Aimbot::Hitscan::ModifiersEnum::Tapfire));
					{
						FSlider(Vars::Aimbot::Hitscan::TapfireDistance);
					}
					PopTransparent();
					PushTransparent(!Vars::Aimbot::Hitscan::Extrapolation.Value);
					FSlider(Vars::Aimbot::Hitscan::ExtrapolationRange, FSliderEnum::None, nullptr, &Hovered);
					FTooltip("Maximum estimate horizon in milliseconds. Drag: 0-100 ms; click the value to enter more. Default: 50 ms; 0 uses normal targeting. Sample-age and movement safety limits still apply. No projectile travel or future shot timestamps.", Hovered);
					PopTransparent();
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Hitscan"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }, -8))
						{
							FDropdown(Vars::Aimbot::Hitscan::PeekCheck, FDropdownEnum::None, 0, &Hovered); FTooltip("This should stay as doubletap only or off if you want to be able to target hitboxes other than the highest priority one", Hovered);
							FSlider(Vars::Aimbot::Hitscan::PeekAmount);
							FSlider(Vars::Aimbot::Hitscan::BoneSizeSubtract);
							FSlider(Vars::Aimbot::Hitscan::BoneSizeMinimumScale);

							EndPopup();
						}
					} EndSection();
				}
#ifdef NIKOGRAM_PRIVATE_LEARNING
				if (Section("Private learning")) { PrivateLearning::Draw(); } EndSection();
#endif
				if (Section("Projectile"))
				{
					FSlider(Vars::Aimbot::Projectile::AimFOV);
					const auto projectileModifierRows = [] {
					FDropdownToggle(Vars::Aimbot::Projectile::PrioritizeMedics);
					FDropdownToggle(Vars::Aimbot::Projectile::PrioritizeOnFire);
					if (IsItemHovered()) SetTooltip("Prioritize burning enemies, and burning teammates only with a helpful weapon and the existing healing/teammate-target setting enabled. Does not bypass team, ignore or visibility checks.");
					FDropdownToggle(Vars::Aimbot::Projectile::PrioritizeUbered);
					if (IsItemHovered()) SetTooltip("Allows and prioritizes invulnerable enemies with explosive knockback weapons. Overrides only Ignore invulnerable for those weapons. Flamethrowers automatically airblast eligible nearby ubered enemies; respects range, line of sight, projectile FOV, ammo and secondary cooldown. Does not make invulnerable players take damage.");
					FDropdownToggle(Vars::Aimbot::Projectile::AutoFlarePunch);
					if (IsItemHovered()) SetTooltip("With projectile aimbot and Auto shoot active: after your flamethrower damages a burning enemy, switch to an owned Flare Gun, Detonator or Scorch Shot for a normally validated shot. Return to the original flamethrower when switching is ready, then retry that burning enemy once the flare weapon's attack cooldown resets. Respects aim activation, FOV, visibility, ammo and self-damage safeguards. Manual weapon selection cancels the cycle. Target death or extinguishing cancels further flare shots, but does not prevent a pending return to the flamethrower.");
					};
					std::vector<const char*> projectileModifierPreview;
					for (auto* option : { &Vars::Aimbot::Projectile::PrioritizeMedics, &Vars::Aimbot::Projectile::PrioritizeOnFire, &Vars::Aimbot::Projectile::PrioritizeUbered, &Vars::Aimbot::Projectile::AutoFlarePunch })
						if (FGet(*option)) projectileModifierPreview.push_back(option->m_vNames.front());
					bool predictHovered = false;
					FDropdown(Vars::Aimbot::Projectile::StrafePrediction, FDropdownEnum::Left, 0, &predictHovered);
					FTooltip("Counter strafe predict: detects repeated tight left/right movement and biases prediction toward its moving centre. Hit chance uses reversal balance, not measured hit probability.\nLedge aware prediction: when recent braking or reversal suggests an uncertain walk-off, checks hull support ahead and predicts slowing near the edge. Does not hold airborne targets on ledges. Uses your existing splash setting. Both options are experimental.", predictHovered);
					FDropdown(Vars::Aimbot::Projectile::SplashPrediction, FDropdownEnum::Right);
					FDropdown(Vars::Aimbot::Projectile::SplashMode);
                    if(IsItemHovered()) SetTooltip("Trace: sample outward around the predicted target. Face: sample nearby collision surfaces and edges. Dynamic: a short Trace attempt, then Face if no fully validated shot was found, within one shared budget. Takes the first valid Dynamic shot; never waits for workers. Saves with your config. Does not bypass visibility or self-damage checks. Reflected projectiles use Trace when Dynamic is selected.");
					FDropdown(Vars::Aimbot::Projectile::AutoDetonate, FDropdownEnum::Left);
					FDropdown(Vars::Aimbot::Projectile::AutoAirblast, FDropdownEnum::Right);
					FDropdown(Vars::Aimbot::Projectile::Hitboxes, FDropdownEnum::Left);
                    if(IsItemHovered()) SetTooltip("Flare Gun, Detonator, Scorch Shot, Manmelter and Crusader's Crossbow use body aim instead of feet. True prioritize feet overrides this: feet first, with other selected hitboxes as fallback; works with Auto on or off. Normal grenade-launcher feet tuning is preserved unless the true-feet override is selected.");
					FModifierDropdown(Vars::Aimbot::Projectile::Modifiers, projectileModifierRows, projectileModifierPreview, FDropdownEnum::Right);
                    if(IsItemHovered()) SetTooltip("Allow splashbot on Direct Hit: OFF means direct shots only; ON adds splash fallback after direct candidates, independent of the global splash mode. Automatic viewmodel switching: independent of aim type, aim key and Auto shoot. Checks every command; current-direction probes cover 128 units of launch clearance. With aim off/inactive, never selects targets or changes aim. With automated aiming, validates an alternate complete trajectory, including Demo paths rejected by a nearby corner. Both sides blocked or incomplete/invalid alternate probes never switch. Supports stickybomb launchers BEFORE charging begins, with measured latency at most 150 ms; never switches an existing charge/release. No queued/choked commands or center-fire launchers. Briefly pauses attacks/automated actions until packet acknowledgement and latency grace, then rechecks. The actual near-wall firing guard remains 48 units; valid grenade impacts and sticky placements remain allowed.");
					FSlider(Vars::Aimbot::Projectile::MaxSimulationTime, FSliderEnum::Left);
					PushTransparent(!Vars::Aimbot::Projectile::StrafePrediction.Value);
					{
						FSlider(Vars::Aimbot::Projectile::HitChance, FSliderEnum::Right);
					}
					PopTransparent();
					FSlider(Vars::Aimbot::Projectile::AutodetRadius, FSliderEnum::Left);
					FSlider(Vars::Aimbot::Projectile::SplashRadius, FSliderEnum::Right);
					FSlider(Vars::Aimbot::Projectile::SelfDamageProtection);
					if(IsItemHovered()) SetTooltip("Shared by projectile and auto-detonator Prevent self damage. 0%%: no restriction. 100%%: block any estimated damage. Allowed damage = max HP * (1 - protection/100). Positive protection also blocks estimated lethal damage. Conservative estimate, not an exact damage forecast.");
					FToggle(Vars::Aimbot::Projectile::SelfDamageDiagnostics);
					if(IsItemHovered()) SetTooltip("Writes Nikogram/Logs/self-damage-diagnostic.log next to the game executable. Works with self-damage protection OFF. Samples projectile candidate, simulation, collision and firing decisions twice per second, plus shot/damage events. Local only; contains entity indices, settings, positions and commands. Keeps up to three 2 MiB logs. Disable after testing.");
					FToggle(Vars::Aimbot::Projectile::AmmoEvidenceDiagnostics);
					if(IsItemHovered()) SetTooltip("Requires Projectile / self damage diagnostics. Own pill/sticky lifetime observations and secondary-fire request edges run without aim selection or Auto shoot; held requests refresh at most four times per second. Sampled enemy exposure screening still requires an aimed candidate and Auto shoot. Logs ammo_lifetime, ammo_detonation_request, ammo_evidence and ammo_shadow. Disappearance is NOT a confirmed explosion; requests are NOT confirmed detonations. No shot suppression or target switching.");
					FDropdown(Vars::Aimbot::Projectile::AmmoEvidenceSources);
					FToggle(Vars::Aimbot::Projectile::AmmoConservation);
					if(IsItemHovered()) SetTooltip("Experimental live behavior, OFF by default. Auto shoot: rocket launchers, Direct Hit, Scorch Shot, grenade and normal stickybomb launchers. Demo weapons credit recently fired unbounced pills and pending Auto detonate of settled normal stickies aged 5 seconds. Sticky firing can switch to a normally validated target, or briefly hold an automated charge instead of releasing it. No new charge starts during a brief wait; manual/unknown charges and charges near maximum are excluded. Up to 100 ms diversion/wait, then 1 second normal firing. Rockets/Scorch use imminent fixed-world impacts. No idle-sticky kill promises, afterburn, bounces, rolling-pill fuse guesses, Scottish Resistance, Beggar's, Rocket Jumper or other charged weapons. Independent of diagnostic toggles/source selection.");
					FDropdown(Vars::Aimbot::Projectile::AmmoConservationFallback);
					if(IsItemHovered()) SetTooltip("When a conservatively covered target has no validated replacement: briefly withhold Auto shoot within the 100 ms action window, or shoot the original target anyway. A request is not a confirmed detonation; normal firing resumes when evidence is uncertain.");
					PushTransparent(!Vars::Aimbot::Projectile::AutoRelease.Value);
					{
						FSlider(Vars::Aimbot::Projectile::AutoRelease);
					}
					PopTransparent();
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Projectile"))
					{
						FText("General", { 5, 5 });
						if (FPopupButton("General", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Projectile::VelocityAverageCount, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::VerticalShift, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::DragOverride, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::TimeOverride, FSliderEnum::Right);

							Divider();
							FSlider(Vars::Aimbot::Projectile::HuntsmanLerp, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::HuntsmanLerpLow, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::HuntsmanAdd, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::HuntsmanAddLow, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::HuntsmanClamp, FSliderEnum::Left);
							FToggle(Vars::Aimbot::Projectile::HuntsmanPullPoint, FToggleEnum::Left);
							FToggle(Vars::Aimbot::Projectile::HuntsmanPullNoZ, FToggleEnum::Right);

							EndPopup();
						}

						FText("Splash", { 5, 5 });
						if (FPopupButton("Splash", { 0, -5 }, -8))
						{
							PushTransparent(Vars::Aimbot::Projectile::SplashMode.Value == Vars::Aimbot::Projectile::SplashModeEnum::Face);
							{
								FSlider(Vars::Aimbot::Projectile::SplashPointsDirect, FSliderEnum::Left);
								FSlider(Vars::Aimbot::Projectile::SplashPointsArc, FSliderEnum::Right);
								FSlider(Vars::Aimbot::Projectile::SplashRotateX, FSliderEnum::Left, Vars::Aimbot::Projectile::SplashRotateX[DEFAULT_BIND] < 0.f ? "random" : "%g");
								FSlider(Vars::Aimbot::Projectile::SplashRotateY, FSliderEnum::Right, Vars::Aimbot::Projectile::SplashRotateY[DEFAULT_BIND] < 0.f ? "random" : "%g");
							}
							PopTransparent();
							PushTransparent(Vars::Aimbot::Projectile::SplashMode.Value == Vars::Aimbot::Projectile::SplashModeEnum::Trace);
							{
								FSlider(Vars::Aimbot::Projectile::SplashDensityDirect, FSliderEnum::Left);
								FSlider(Vars::Aimbot::Projectile::SplashDensityArc, FSliderEnum::Right);
								FSlider(Vars::Aimbot::Projectile::SplashSamplesCutoff);
							}
							PopTransparent();
							FSlider(Vars::Aimbot::Projectile::SplashAirCount, FSliderEnum::None, !Vars::Aimbot::Projectile::SplashAirCount[DEFAULT_BIND] ? "random" : "%i");

							Divider();
							FSlider(Vars::Aimbot::Projectile::SplashRestrictDirect);
							FSlider(Vars::Aimbot::Projectile::SplashRestrictArc);
							FSlider(Vars::Aimbot::Projectile::SplashRestrictFirst);

							Divider();
							FSlider(Vars::Aimbot::Projectile::DirectTraceInterval);
							FSlider(Vars::Aimbot::Projectile::SplashTraceInterval);
							FSlider(Vars::Aimbot::Projectile::LobTraceInterval);
							FToggle(Vars::Aimbot::Projectile::IntervalRetest);

							EndPopup();
						}

						FText("Ground", { 5, 5 });
						if (FPopupButton("Ground", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Projectile::GroundSamples, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::GroundStraightFuzzyValue, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::GroundLowMinimumSamples, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::GroundHighMinimumSamples, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::GroundLowMinimumDistance, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::GroundHighMinimumDistance, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::GroundMaxChanges, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::GroundMaxChangeTime, FSliderEnum::Right);

							EndPopup();
						}

						FText("Air", { 5, 5 });
						if (FPopupButton("Air", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Projectile::AirSamples, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::AirStraightFuzzyValue, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::AirLowMinimumSamples, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::AirHighMinimumSamples, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::AirLowMinimumDistance, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::AirHighMinimumDistance, FSliderEnum::Right);
							FSlider(Vars::Aimbot::Projectile::AirMaxChanges, FSliderEnum::Left);
							FSlider(Vars::Aimbot::Projectile::AirMaxChangeTime, FSliderEnum::Right);

							EndPopup();
						}

						FText("Misc", { 5, 5 });
						if (FPopupButton("Misc", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Projectile::DeltaCount, FSliderEnum::Left);
							FDropdown(Vars::Aimbot::Projectile::DeltaMode, FDropdownEnum::Right);
							FDropdown(Vars::Aimbot::Projectile::MovesimFrictionFlags);

							EndPopup();
						}
					} EndSection();
				}
                if (Section("Melee"))
                {
                    FSlider(Vars::Aimbot::Melee::AimFOV);
                    if(IsItemHovered()) SetTooltip("Separate melee targeting cone, independent of the general aim FOV. Defaults to 20 degrees. Zero disables automatic melee targeting; range, wall and backstab checks still apply.");
					std::vector<const char*> meleeModifierPreview;
					for (auto* option : { &Vars::Aimbot::Melee::AutoBackstab, &Vars::Aimbot::Melee::SwingPrediction, &Vars::Aimbot::Melee::IgnoreRazorback, &Vars::Aimbot::Melee::WhipTeam, &Vars::Aimbot::Melee::PrioritizeMedics })
						if (FGet(*option)) meleeModifierPreview.push_back(option->m_vNames.front());
					int meleeModifiers = 0;
					FDropdown("Modifiers##Melee modifiers", &meleeModifiers, {}, {}, FDropdownEnum::Multi, 0, "None", nullptr, nullptr, {}, 0,
						[] {
							FDropdownToggle(Vars::Aimbot::Melee::AutoBackstab);
							FDropdownToggle(Vars::Aimbot::Melee::SwingPrediction);
							FDropdownToggle(Vars::Aimbot::Melee::IgnoreRazorback);
							FDropdownToggle(Vars::Aimbot::Melee::WhipTeam);
							FDropdownToggle(Vars::Aimbot::Melee::PrioritizeMedics);
						}, meleeModifierPreview);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Melee"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FSlider(Vars::Aimbot::Melee::SwingTicks, FSliderEnum::Left);
							FToggle(Vars::Aimbot::Melee::SwingPredictLag, FToggleEnum::Right);
							FDropdown(Vars::Aimbot::Melee::SwingValidateMode, FDropdownEnum::Left);
							FDropdown(Vars::Aimbot::Melee::BackstabFlags, FDropdownEnum::Right);

							EndPopup();
						}
					} EndSection();
				}
			}
			EndTable();
		}
		break;
	}
	// Draw
	case 1:
	{
		if (BeginTable("DrawTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("Line"))
				{
					FColorPicker(Vars::Colors::LineIgnoreZ, FColorPickerEnum::None, { 0, H::Draw.Scale(6) }, { H::Draw.Scale(12), H::Draw.Scale(6) });
					FColorPicker(Vars::Colors::Line, FColorPickerEnum::None, {}, { H::Draw.Scale(12), H::Draw.Scale(6) });
					FToggle(Vars::Visuals::Line::TracersEnabled);
					FSlider(Vars::Visuals::Line::DrawDuration);
				} EndSection();
				if (Section("Hitbox"))
				{
					FColoredDropdown(Vars::Visuals::Hitbox::BonesEnabled, { &Vars::Colors::TargetHitboxEdgeIgnoreZ, &Vars::Colors::TargetHitboxEdge, &Vars::Colors::BoneHitboxEdgeIgnoreZ, &Vars::Colors::BoneHitboxEdge, &Vars::Colors::TargetHitboxFaceIgnoreZ, &Vars::Colors::TargetHitboxFace, &Vars::Colors::BoneHitboxFaceIgnoreZ, &Vars::Colors::BoneHitboxFace }, FDropdownEnum::None);

					FColoredDropdown(Vars::Visuals::Hitbox::BoundsEnabled, { &Vars::Colors::BoundHitboxEdgeIgnoreZ, &Vars::Colors::BoundHitboxEdge, &Vars::Colors::BoundHitboxFaceIgnoreZ, &Vars::Colors::BoundHitboxFace }, FDropdownEnum::None);

					FSlider(Vars::Visuals::Hitbox::DrawDuration);
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Prediction"))
				{
					FColoredDropdown(Vars::Visuals::Prediction::PlayerPath, { &Vars::Colors::PlayerPathIgnoreZ, &Vars::Colors::PlayerPath }, FDropdownEnum::Left);
					FColoredDropdown(Vars::Visuals::Prediction::ProjectilePath, { &Vars::Colors::ProjectilePathIgnoreZ, &Vars::Colors::ProjectilePath }, FDropdownEnum::Right);
					FToggle(Vars::Visuals::Prediction::SwingLines);
					FSlider(Vars::Visuals::Prediction::PlayerDrawDuration, FSliderEnum::Left, !Vars::Visuals::Prediction::PlayerDrawDuration[DEFAULT_BIND] ? "timed" : "%g");
					FSlider(Vars::Visuals::Prediction::ProjectileDrawDuration, FSliderEnum::Right, !Vars::Visuals::Prediction::ProjectileDrawDuration[DEFAULT_BIND] ? "timed" : "%g");
				} EndSection();
				if (Section("Simulation"))
				{
					FColoredDropdown(Vars::Visuals::Simulation::TrajectoryPath, { &Vars::Colors::TrajectoryPathIgnoreZ, &Vars::Colors::TrajectoryPath }, FDropdownEnum::Left);
					FColoredDropdown(Vars::Visuals::Simulation::ShotPath, { &Vars::Colors::ShotPathIgnoreZ, &Vars::Colors::ShotPath }, FDropdownEnum::Right);
					FColoredDropdown(Vars::Visuals::Simulation::SplashRadius, { &Vars::Colors::SplashRadiusIgnoreZ, &Vars::Colors::SplashRadius }, FDropdownEnum::None);
					FToggle(Vars::Visuals::Simulation::ProjectileCamera, FToggleEnum::Left);
					FToggle(Vars::Visuals::Simulation::Box, FToggleEnum::Right);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug"))
					{
						FText("Extra", { 5, 5 });
						if (FPopupButton("Extra", { 0, -5 }, -8))
						{
							FColoredDropdown(Vars::Visuals::Prediction::RealPath, { &Vars::Colors::RealPath, &Vars::Colors::RealPathIgnoreZ }, FDropdownEnum::None);

							FSlider(Vars::Visuals::Path::SeparatorSpacing, FSliderEnum::Left);
							FSlider(Vars::Visuals::Path::SeparatorLength, FSliderEnum::Right);

							EndPopup();
						}

						FText("Simulation", { 5, 5 });
						if (FPopupButton("Simulation", { 0, -5 }))
						{
							FToggle(Vars::Visuals::Trajectory::Override);
							bool bApply = FButton("Apply current");
							FSDropdown(Vars::Visuals::Trajectory::Type);
							FSlider(Vars::Visuals::Trajectory::OffsetX);
							FSlider(Vars::Visuals::Trajectory::OffsetY);
							FSlider(Vars::Visuals::Trajectory::OffsetZ);
							FSlider(Vars::Visuals::Trajectory::ForwardRedirect);
							FSlider(Vars::Visuals::Trajectory::ForwardCutoff);
							FSlider(Vars::Visuals::Trajectory::Hull);
							FSlider(Vars::Visuals::Trajectory::Speed);
							FSlider(Vars::Visuals::Trajectory::Gravity);
							FSlider(Vars::Visuals::Trajectory::LifeTime);
							FSlider(Vars::Visuals::Trajectory::UpVelocity);
							FSlider(Vars::Visuals::Trajectory::AngularVelocityX);
							FSlider(Vars::Visuals::Trajectory::AngularVelocityY);
							FSlider(Vars::Visuals::Trajectory::AngularVelocityZ);
							FSlider(Vars::Visuals::Trajectory::Drag);
							FSlider(Vars::Visuals::Trajectory::DragX);
							FSlider(Vars::Visuals::Trajectory::DragY);
							FSlider(Vars::Visuals::Trajectory::DragZ);
							FSlider(Vars::Visuals::Trajectory::AngularDragX);
							FSlider(Vars::Visuals::Trajectory::AngularDragY);
							FSlider(Vars::Visuals::Trajectory::AngularDragZ);
							FSlider(Vars::Visuals::Trajectory::MaxVelocity);
							FSlider(Vars::Visuals::Trajectory::MaxAngularVelocity);

							if (bApply)
							{
								auto pLocal = H::Entities.GetLocal();
								auto pWeapon = H::Entities.GetWeapon();
								if (pLocal && pWeapon)
								{
									ProjectileInfo tProjInfo = {};
									bool bOriginal = Vars::Visuals::Trajectory::Override.Value;
									Vars::Visuals::Trajectory::Override.Value = false;
									bool bSetup = F::ProjSim.GetInfo(pLocal, pWeapon, {}, tProjInfo, ProjSimEnum::Interp)
											   && F::ProjSim.Initialize(tProjInfo, false);
									Vars::Visuals::Trajectory::Override.Value = bOriginal;
									if (bSetup)
									{
										Vec3 vLocalEye = pLocal->GetEyePosition();
										Vec3 vOffset = tProjInfo.m_vPos - vLocalEye; vOffset.y *= -1;
										float flForwardRedirect = 0.f, flForwardCutoff = 0.f;
										switch (tProjInfo.m_uType)
										{
										case FNV1A::Hash32Const("models/weapons/w_models/w_rocket.mdl"):
										case FNV1A::Hash32Const("models/weapons/w_models/w_drg_ball.mdl"):
										case FNV1A::Hash32Const("models/weapons/w_models/w_flaregun_shell.mdl"):
										case FNV1A::Hash32Const("models/weapons/w_models/w_arrow.mdl"):
										case FNV1A::Hash32Const("models/weapons/w_models/w_syringe_proj.mdl"):
										case FNV1A::Hash32Const("models/weapons/w_models/w_repair_claw.mdl"):
											flForwardRedirect = 2000.f, flForwardCutoff = 0.1f; break;
										case FNV1A::Hash32Const("models/weapons/c_models/c_flameball/c_flameball.mdl"):
										{
											auto pFireballDistance = H::ConVars.FindVar("tf_fireball_distance");
											flForwardRedirect = pFireballDistance ? pFireballDistance->GetFloat() : 0.f, flForwardCutoff = 1.f;
											break;
										}
										}
										physics_performanceparams_t params = {}; F::ProjSim.m_pEnv->GetPerformanceSettings(&params);
										Vec3 vVelocity, vAngVelocity; F::ProjSim.m_pObj->GetVelocity(&vVelocity, &vAngVelocity);

										Vars::Visuals::Trajectory::OffsetX[DEFAULT_BIND] = vOffset.x;
										Vars::Visuals::Trajectory::OffsetY[DEFAULT_BIND] = vOffset.y;
										Vars::Visuals::Trajectory::OffsetZ[DEFAULT_BIND] = vOffset.z;
										Vars::Visuals::Trajectory::ForwardRedirect[DEFAULT_BIND] = flForwardRedirect;
										Vars::Visuals::Trajectory::ForwardCutoff[DEFAULT_BIND] = flForwardCutoff;
										Vars::Visuals::Trajectory::Hull[DEFAULT_BIND] = tProjInfo.m_vHull.x;
										Vars::Visuals::Trajectory::Speed[DEFAULT_BIND] = vVelocity.x;
										Vars::Visuals::Trajectory::Gravity[DEFAULT_BIND] = tProjInfo.m_flGravity;
										Vars::Visuals::Trajectory::LifeTime[DEFAULT_BIND] = tProjInfo.m_flLifetime;
										Vars::Visuals::Trajectory::UpVelocity[DEFAULT_BIND] = vVelocity.z;
										Vars::Visuals::Trajectory::AngularVelocityX[DEFAULT_BIND] = vAngVelocity.x;
										Vars::Visuals::Trajectory::AngularVelocityY[DEFAULT_BIND] = vAngVelocity.y;
										Vars::Visuals::Trajectory::AngularVelocityZ[DEFAULT_BIND] = vAngVelocity.z;
										Vars::Visuals::Trajectory::Drag[DEFAULT_BIND] = F::ProjSim.m_pObj->m_dragCoefficient;
										Vars::Visuals::Trajectory::DragX[DEFAULT_BIND] = F::ProjSim.m_pObj->m_dragBasis.x;
										Vars::Visuals::Trajectory::DragY[DEFAULT_BIND] = F::ProjSim.m_pObj->m_dragBasis.y;
										Vars::Visuals::Trajectory::DragZ[DEFAULT_BIND] = F::ProjSim.m_pObj->m_dragBasis.z;
										Vars::Visuals::Trajectory::AngularDragX[DEFAULT_BIND] = F::ProjSim.m_pObj->m_angDragBasis.x;
										Vars::Visuals::Trajectory::AngularDragY[DEFAULT_BIND] = F::ProjSim.m_pObj->m_angDragBasis.y;
										Vars::Visuals::Trajectory::AngularDragZ[DEFAULT_BIND] = F::ProjSim.m_pObj->m_angDragBasis.z;
										Vars::Visuals::Trajectory::MaxVelocity[DEFAULT_BIND] = params.maxVelocity;
										Vars::Visuals::Trajectory::MaxAngularVelocity[DEFAULT_BIND] = params.maxAngularVelocity;
									}
								}
							}

							EndPopup();
						}
					} EndSection();
				}
			}
			EndTable();
		}
		break;
	}
	}
}

void CMenu::MenuHVH(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// HvH
	case 0:
	{
		if (BeginTable("HvHTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("Antiaim"))
				{
					FToggle(Vars::AntiAim::Enabled, FToggleEnum::Left);
					FToggle(Vars::AntiAim::HidePitchOnShot, FToggleEnum::Right);
					FDropdown(Vars::AntiAim::PitchReal, FDropdownEnum::Left);
					FDropdown(Vars::AntiAim::PitchFake, FDropdownEnum::Right);
					FDropdown(Vars::AntiAim::YawReal, FDropdownEnum::Left);
					FDropdown(Vars::AntiAim::YawFake, FDropdownEnum::Right);
					FDropdown(Vars::AntiAim::RealYawBase, FDropdownEnum::Left);
					FDropdown(Vars::AntiAim::FakeYawBase, FDropdownEnum::Right);
					FSlider(Vars::AntiAim::RealYawOffset, FSliderEnum::Left);
					FSlider(Vars::AntiAim::FakeYawOffset, FSliderEnum::Right);
					PushTransparent(Vars::AntiAim::YawReal.Value != Vars::AntiAim::YawEnum::Edge && Vars::AntiAim::YawReal.Value != Vars::AntiAim::YawEnum::Jitter);
					{
						FSlider(Vars::AntiAim::RealYawValue, FSliderEnum::Left);
					}
					PopTransparent();
					PushTransparent(Vars::AntiAim::YawFake.Value != Vars::AntiAim::YawEnum::Edge && Vars::AntiAim::YawFake.Value != Vars::AntiAim::YawEnum::Jitter);
					{
						FSlider(Vars::AntiAim::FakeYawValue, FSliderEnum::Right);
					}
					PopTransparent();
					PushTransparent(Vars::AntiAim::YawFake.Value != Vars::AntiAim::YawEnum::Spin && Vars::AntiAim::YawReal.Value != Vars::AntiAim::YawEnum::Spin);
					{
						FSlider(Vars::AntiAim::SpinSpeed, FSliderEnum::Left);
					}
					PopTransparent();
					const float afterSpinRow = GetCursorPosY();
					SetCursorPos({ GetWindowWidth() / 2 + GetStyle().WindowPadding.x / 2, GetRowPos() + H::Draw.Scale(8) });
					FToggle(Vars::AntiAim::MinWalk, FToggleEnum::Left);
					SetCursorPos({ GetStyle().WindowPadding.x, std::max(afterSpinRow, GetCursorPosY()) });
					DebugDummy({ 0, H::Draw.Scale(4) });
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Antiaim"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FToggle(Vars::AntiAim::AntiAimLines);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Resolver"))
				{
					FToggle(Vars::Resolver::Enabled, FToggleEnum::Left);
					PushTransparent(!Vars::Resolver::Enabled.Value);
					{
						FToggle(Vars::Resolver::AutoResolve, FToggleEnum::Right);
						PushTransparent(Transparent || !Vars::Resolver::AutoResolve.Value);
						{
							FToggle(Vars::Resolver::AutoResolveCheatersOnly, FToggleEnum::Left);
							FToggle(Vars::Resolver::AutoResolveHeadshotOnly, FToggleEnum::Right);
							PushTransparent(Transparent || !Vars::Resolver::AutoResolveYawAmount.Value);
							{
								FSlider(Vars::Resolver::AutoResolveYawAmount, FSliderEnum::Left);
							}
							PopTransparent();
							PushTransparent(Transparent || !Vars::Resolver::AutoResolvePitchAmount.Value);
							{
								FSlider(Vars::Resolver::AutoResolvePitchAmount, FSliderEnum::Right);
							}
							PopTransparent();
						}
						PopTransparent();
						FSlider(Vars::Resolver::CycleYaw, FSliderEnum::Left);
						FSlider(Vars::Resolver::CyclePitch, FSliderEnum::Right);
						FToggle(Vars::Resolver::CycleView, FToggleEnum::Left);
						FToggle(Vars::Resolver::CycleMinwalk, FToggleEnum::Right);
					}
					PopTransparent();
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Doubletap"))
				{
					FToggle(Vars::Doubletap::Doubletap, FToggleEnum::Left);
					FToggle(Vars::Doubletap::Warp, FToggleEnum::Right);
					FToggle(Vars::Doubletap::RechargeTicks, FToggleEnum::Left);
					FToggle(Vars::Doubletap::AntiWarp, FToggleEnum::Right);
					FSlider(Vars::Doubletap::TickLimit, FSliderEnum::Left);
					FSlider(Vars::Doubletap::WarpRate, FSliderEnum::Right);
					FSlider(Vars::Doubletap::RechargeLimit, FSliderEnum::Left);
					FSlider(Vars::Doubletap::PassiveRecharge, FSliderEnum::Right);
				} EndSection();
				if (Section("Fakelag"))
				{
					FDropdown(Vars::Fakelag::Fakelag, FDropdownEnum::Left);
					FDropdown(Vars::Fakelag::Options, FDropdownEnum::Right);
					PushTransparent(Vars::Fakelag::Fakelag.Value != Vars::Fakelag::FakelagEnum::Plain);
					{
						FSlider(Vars::Fakelag::PlainTicks, FSliderEnum::Left);
					}
					PopTransparent();
					PushTransparent(Vars::Fakelag::Fakelag.Value != Vars::Fakelag::FakelagEnum::Random);
					{
						FSlider(Vars::Fakelag::RandomTicks, FSliderEnum::Right);
					}
					PopTransparent();
					FToggle(Vars::Fakelag::UnchokeOnAttack, FToggleEnum::Left);
					FToggle(Vars::Fakelag::RetainBlastJump, FToggleEnum::Right);
					FSlider(Vars::Backtrack::Latency, FSliderEnum::Left);
					FSlider(Vars::Backtrack::Interp, FSliderEnum::Right);
					FSlider(Vars::Backtrack::RealLag);
					if (Vars::Backtrack::RealLag.Value > 0) ImGui::TextWrapped("%s", RealLag::Status().c_str());
					if (Vars::Backtrack::RealLag.Value > 0) ImGui::TextWrapped("Log: %s", RealLag::DiagnosticPath().c_str());
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug Fakelag"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FToggle(Vars::Fakelag::RetainSoldierOnly);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Auto Peek"))
				{
					FToggle(Vars::AutoPeek::Enabled);
				} EndSection();
				if (Section("Speedhack"))
				{
					PushTransparent(Vars::Speedhack::Scale.Value == 1);
					{
						FSlider(Vars::Speedhack::Scale);
					}
					PopTransparent();
				} EndSection();
			}
			EndTable();
		}
		break;
	}
	}
}

void CMenu::MenuVisuals(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// ESP
	case 0:
	{
		// fake angle/viewmodel visuals, pickup timers?
		static size_t iCurrentGroup = 0;

		if (Section("Groups"))
		{
			static std::string sStaticName;
			const ImVec2 groupRow = GetCursorPos();
			const float createHeight = CompactDropdownHeight(true);
			const float createWidth = FCalcTextSize("CREATE").x + H::Draw.Scale(20);

			PushDisabled(F::Groups.m_vGroups.size() >= sizeof(int) * 8); // for active groups flags
			{
				FSDropdown("Name", &sStaticName, {}, FDropdownEnum::Left | FSDropdownEnum::AutoUpdate, -H::Draw.Unscale(createWidth) - 8);

				PushDisabled(Disabled || sStaticName.empty());
				{
					SetCursorPos({ groupRow.x + GetWindowWidth() / 2 - GetStyle().WindowPadding.x * 1.5f - createWidth,
						groupRow.y + H::Draw.Scale(3) - GetStyle().WindowPadding.y });
					if (FButton("Create", FButtonEnum::None, { H::Draw.Unscale(createWidth), H::Draw.Unscale(createHeight) }))
					{
						F::Groups.m_vGroups.emplace_back(sStaticName);
						sStaticName.clear();

						iCurrentGroup = F::Groups.m_vGroups.size() - 1;
					}
				}
				PopDisabled();
			}
			PopDisabled();

			// Keep the right-hand dropdown anchored to the original row, not the button's padding offset.
			SetCursorPos(groupRow);
			Dummy({ 0, createHeight + H::Draw.Scale(3) });
			FDropdown(Vars::ESP::ActiveGroups, FDropdownEnum::Right | FDropdownEnum::Multi);

			PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
			SetCursorPos({ H::Draw.Scale(13), H::Draw.Scale(80) });
			FText("Groups");
			PopStyleColor();

			const float groupTop = GetCursorPosY() + H::Draw.Scale(4);
			const float groupHeight = std::max(H::Draw.Scale(18), GetTextLineHeight() + H::Draw.Scale(4));
			auto fPositionToIndex = [&](ImVec2 vPos)
			{
				if (F::Groups.m_vGroups.empty()) return -1;
				int iIndex = int(floorf((vPos.y - groupTop) / groupHeight));
				iIndex = std::clamp(iIndex, 0, int(F::Groups.m_vGroups.size() - 1));
				return iIndex;
			};

			static int iDragging = -1;
			if (!IsMouseDown(ImGuiMouseButton_Left) || iDragging >= int(F::Groups.m_vGroups.size()))
				iDragging = -1;
			else if (iDragging != -1)
			{
				int iTo = fPositionToIndex(GetMousePos() - GetDrawPos());
				if (iDragging != iTo)
				{
					F::Groups.Move(iDragging, iTo);
					{
						const int iFrom = iDragging, iTarget = iTo;
						RemapActiveGroups([&](uint32_t uMask) { return GroupMaskInsert(GroupMaskRemove(uMask, iFrom), iTarget, iFrom < 32 && uMask & 1u << iFrom); });
					}
					if (iCurrentGroup == iDragging)
						iCurrentGroup = iTo;
					else if (iCurrentGroup < iDragging && iCurrentGroup >= iTo)
						iCurrentGroup++;
					else if (iCurrentGroup > iDragging && iCurrentGroup <= iTo)
						iCurrentGroup--;
					iDragging = iTo;
				}
			}

			for (auto it = F::Groups.m_vGroups.begin(); it < F::Groups.m_vGroups.end();)
			{
				int iGroup = std::distance(F::Groups.m_vGroups.begin(), it);
				auto& tGroup = *it;

				ImVec2 vOriginalPos = { GetStyle().WindowPadding.x, groupTop + iGroup * groupHeight };
				const float deleteGap = H::Draw.Scale(4);
				float flWidth = GetWindowWidth() - GetStyle().WindowPadding.x * 2 - groupHeight - deleteGap;
				float flHeight = groupHeight;
				ImColor tColor = ColorByteToFloat(tGroup.m_tColor.Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha));
				ImVec2 vDrawPos = GetDrawPos() + vOriginalPos;
				if (iCurrentGroup != iGroup)
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), tColor, 0);
				else
				{
					ImColor tColor2 = { tColor.Value.x * 1.1f, tColor.Value.y * 1.1f, tColor.Value.z * 1.1f, tColor.Value.w };
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), tColor2, 0);

					tColor2 = ColorByteToFloat(tGroup.m_tColor.Lerp(Vars::Menu::Theme::Background.Value, 0.25f, LerpEnum::NoAlpha));
					float flInset = H::Draw.Scale(0.5f) - 0.5f;
					GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(flWidth - flInset, flHeight - flInset), tColor2, 0, ImDrawFlags_None, H::Draw.Scale());
				}

				GetWindowDrawList()->AddRect(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), GetColorU32(ImGuiCol_TableBorderLight));

				// text + icons
				float flTextWidth = flWidth - H::Draw.Scale(12);
				SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(6), (flHeight - GetTextLineHeight()) / 2));
				PushTransparent(!(iGroup < 32 && Vars::ESP::ActiveGroups.Value & 1 << iGroup), true); // ActiveGroups is a 32 bit mask
				{
					FText(TruncateText(tGroup.m_sName, flTextWidth).c_str());
				}
				PopTransparent(1, 1);

				SetCursorPos(vOriginalPos + ImVec2(flWidth + deleteGap, 0));
				PushID(iGroup);
				const ImVec2 deletePos = GetCursorScreenPos();
				bool bDelete = Button("##DeleteGroup", { flHeight, flHeight }), bDuplicate = false;
				if (IsItemHovered()) { SetMouseCursor(ImGuiMouseCursor_Hand); SetTooltip("Delete group"); }
				const float iconSize = std::min(H::Draw.Scale(14), flHeight - H::Draw.Scale(4));
				const ImVec2 iconExtent = F::Render.IconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.f, ICON_MD_DELETE);
				GetWindowDrawList()->AddRect(deletePos, deletePos + ImVec2(flHeight, flHeight), GetColorU32(F::Render.Accent.Value));
				GetWindowDrawList()->AddText(F::Render.IconFont, iconSize,
					deletePos + (ImVec2(flHeight, flHeight) - iconExtent) * 0.5f, GetColorU32(F::Render.Accent.Value), ICON_MD_DELETE);
				PopID();

				SetCursorPos(vOriginalPos);
				bool bClicked = InvisibleButton(std::format("##GroupRow{}", iGroup).c_str(), { flWidth, flHeight });
				if (IsItemHovered())
				{
					SetMouseCursor(ImGuiMouseCursor_Hand);
					GetWindowDrawList()->AddRect(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), GetColorU32(F::Render.Accent.Value));
				}
				bool bPopup = IsItemClicked(ImGuiMouseButton_Right);

				if (bClicked)
					iCurrentGroup = iGroup;
				else if (bPopup)
					OpenPopup(std::format("RightClicked{}", iGroup).c_str());
				else if (iDragging == -1 && IsItemHovered() && IsMouseDown(ImGuiMouseButton_Left))
					iDragging = iGroup;

				if (FBeginPopup(std::format("RightClicked{}", iGroup).c_str()))
				{
					PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), 0 });

					{
						static std::string sInput = "";

						bool bEnter = FInputText("Name...", sInput, H::Draw.Scale(284), ImGuiInputTextFlags_EnterReturnsTrue);
						if (!IsItemFocused())
							sInput = tGroup.m_sName;
						if (bEnter)
							tGroup.m_sName = sInput;
					}

					PushDisabled(F::Groups.m_vGroups.size() >= sizeof(int) * 8);
					{
						bDuplicate = FButton("Duplicate");
					}
					PopDisabled();

					PopStyleVar();
					EndPopup();
				}

				if (bDelete)
				{
					it = F::Groups.m_vGroups.erase(it);
					RemapActiveGroups([&](uint32_t uMask) { return GroupMaskRemove(uMask, iGroup); });
					if (iCurrentGroup > iGroup)
						iCurrentGroup--;
				}
				else if (bDuplicate)
				{
					it = F::Groups.m_vGroups.insert(it + 1, tGroup);
					it->m_sName += " duplicate";
					RemapActiveGroups([&](uint32_t uMask) { return GroupMaskInsert(uMask, iGroup + 1, iGroup < 32 && uMask & 1u << iGroup); });
					if (iCurrentGroup > iGroup)
						iCurrentGroup++;
				}
				else
					++it;
			}
			SetCursorPos({ GetStyle().WindowPadding.x, groupTop });
			Dummy({ GetWindowWidth() - GetStyle().WindowPadding.x * 2, groupHeight * F::Groups.m_vGroups.size() });
		} EndSection();

		if (!F::Groups.m_vGroups.empty()
			&& BeginTable("VisualsESPTable", 2))
		{
			iCurrentGroup = std::clamp(iCurrentGroup, 0ui64, F::Groups.m_vGroups.size() - 1);
			auto& tGroup = F::Groups.m_vGroups[iCurrentGroup];

			/* Column 1 */
			TableNextColumn();
			{
				if (Section("Color"))
				{
					FColorPicker("Group color", &tGroup.m_tColor, FColorPickerEnum::Left);
					FToggle("Tags override color", &tGroup.m_bTagsOverrideColor, FToggleEnum::Right);
				} EndSection();
				if (Section("Targets"))
				{
					FDropdown("Targets", &tGroup.m_iTargets, { "Players", "Buildings", "Projectiles", "Ragdolls", "Objective", "NPCs", "Health", "Ammo", "Money", "Powerups", "Spellbook", "Bombs", "Gargoyle", "##Divider", "Fake angle", "Viewmodel weapon", "Viewmodel hands" }, {}, FDropdownEnum::Multi);
				} EndSection();
				if (Section("Conditions"))
				{
					FDropdown("Conditions", &tGroup.m_iConditions, { "Enemy", "Team", "BLU", "RED", "##Divider", "Local", "Friends", "Party", "Priority", "Target", "##Divider", "Dormant" }, {}, FDropdownEnum::Multi);
					Divider(H::Draw.Scale(8), H::Draw.Scale(-1));
					PushTransparent(!(tGroup.m_iTargets & TargetsEnum::Players));
					{
						FDropdown("Players", &tGroup.m_iPlayers, { "Scout", "Soldier", "Pyro", "Demoman", "Heavy", "Engineer", "Medic", "Sniper", "Spy", "##Divider", "Invulnerable", "Crits", "Invisible", "Disguise", "Hurt" }, {}, FDropdownEnum::Multi, 0, "All");
					}
					PopTransparent();
					PushTransparent(!(tGroup.m_iTargets & TargetsEnum::Buildings));
					{
						FDropdown("Buildings", &tGroup.m_iBuildings, { "Sentry", "Dispenser", "Teleporter", "##Divider", "Hurt" }, {}, FDropdownEnum::Multi, 0, "All");
					}
					PopTransparent();
					PushTransparent(!(tGroup.m_iTargets & TargetsEnum::Projectiles));
					{
						FDropdown("Projectiles", &tGroup.m_iProjectiles, { "Rocket", "Sticky", "Pipe", "Arrow", "Heal", "Flare", "Fire", "Repair", "Cleaver", "Milk", "Jarate", "Gas", "Bauble", "Baseball", "Energy", "Short circuit", "Meteor shower", "Lightning", "Fireball", "Bomb", "Bats", "Pumpkin", "Monoculus", "Skeleton", "Misc", "##Divider", "Crit", "Minicrit" }, {}, FDropdownEnum::Multi, 0, "All");
					}
					PopTransparent();
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("ESP"))
				{
					std::vector<const char*> vEntries = { "Name", "Box", "Distance" };
					std::vector<int> vValues = { ESPEnum::Name, ESPEnum::Box, ESPEnum::Distance };
					if (tGroup.m_iTargets & TargetsEnum::Players)
					{
						vEntries.insert(vEntries.end(), { "Bones" });
						vValues.insert(vValues.end(), { ESPEnum::Bones });
					}
					if (tGroup.m_iTargets & (TargetsEnum::Players | TargetsEnum::Buildings))
					{
						vEntries.insert(vEntries.end(), { "Health bar", "Health text" });
						vValues.insert(vValues.end(), { ESPEnum::HealthBar, ESPEnum::HealthText });
					}
					if (tGroup.m_iTargets & TargetsEnum::Players)
					{
						vEntries.insert(vEntries.end(), { "Uber bar", "Uber text", "Class icon", "Class text", "Weapon icon", "Weapon text", "Priority", "Labels", "Buffs", "Debuffs" });
						vValues.insert(vValues.end(), { ESPEnum::UberBar, ESPEnum::UberText, ESPEnum::ClassIcon, ESPEnum::ClassText, ESPEnum::WeaponIcon, ESPEnum::WeaponText, ESPEnum::Priority, ESPEnum::Labels, ESPEnum::Buffs, ESPEnum::Debuffs });
					}
					if (tGroup.m_iTargets & (TargetsEnum::Players | TargetsEnum::Buildings | TargetsEnum::Projectiles | TargetsEnum::Objective))
					{
						vEntries.insert(vEntries.end(), { "Flags" });
						vValues.insert(vValues.end(), { ESPEnum::Flags });
					}
					if (tGroup.m_iTargets & TargetsEnum::Players)
					{
						vEntries.insert(vEntries.end(), { "Lag compensation", "Ping", "KDR" });
						vValues.insert(vValues.end(), { ESPEnum::LagCompensation, ESPEnum::Ping, ESPEnum::KDR });
					}
					if (tGroup.m_iTargets & (TargetsEnum::Buildings | TargetsEnum::Projectiles))
					{
						vEntries.insert(vEntries.end(), { "Owner" });
						vValues.insert(vValues.end(), { ESPEnum::Owner });
					}
					if (tGroup.m_iTargets & TargetsEnum::Buildings)
					{
						vEntries.insert(vEntries.end(), { "Level", "Ammo bars", "Ammo text" });
						vValues.insert(vValues.end(), { ESPEnum::Level, ESPEnum::AmmoBars, ESPEnum::AmmoText });
					}
					if (tGroup.m_iTargets & TargetsEnum::Objective)
					{
						vEntries.insert(vEntries.end(), { "Intel return time" });
						vValues.insert(vValues.end(), { ESPEnum::IntelReturnTime });
					}

					PushTransparent(tGroup.m_iTargets && !(tGroup.m_iTargets & TargetsEnum::ESP));
					{
						FDropdown("Draw", &tGroup.m_iESP, vEntries, vValues, FDropdownEnum::Multi, 0, "None", nullptr, nullptr, [&]
						{
							// Display inheritance without committing an override on open.
							auto colour = tGroup.NameColor();
							if (FColorPicker("##NameColour", &colour, AttachedColorPicker | FColorPickerEnum::NoTooltip))
							{
								tGroup.m_tNameColor = colour;
								tGroup.m_bCustomNameColor = true;
							}
						}, ESPEnum::Name);
					}
					PopTransparent();
					if(tGroup.m_iTargets & TargetsEnum::Players)
						FDropdown("Dapper Mann ESP", &tGroup.m_iDapperESP, {"Off", "Dapper Mann", "Dapper Mann - Money", "Giga Mann"});
				} EndSection();
				if (Section("Chams"))
				{
					if (!tGroup.m_iTargets || tGroup.m_iTargets & TargetsEnum::Occluded)
					{
						FMDropdown("Visible material", &tGroup.m_tChams.Visible, FDropdownEnum::Left);
						FMDropdown("Occluded material", &tGroup.m_tChams.Occluded, FDropdownEnum::Right);
					}
					else
						FMDropdown("Material", &tGroup.m_tChams.Visible);
				} EndSection();
				if (Section("Glow"))
				{
					PushTransparent(!tGroup.m_tGlow.Stencil);
					{
						FSlider("Stencil scale", &tGroup.m_tGlow.Stencil, 0, 10, 1, "%i", FSliderEnum::Left | FSliderEnum::Min);
					}
					PopTransparent();
					PushTransparent(!tGroup.m_tGlow.Blur);
					{
						FSlider("Blur scale", &tGroup.m_tGlow.Blur, 0.f, 10.f, 1.f, "%g", FSliderEnum::Right | FSliderEnum::Min | FSliderEnum::Precision);
					}
					PopTransparent();
				} EndSection();
				if (Section("Misc"))
				{
					FToggle("Offscreen arrows", &tGroup.m_bOffscreenArrows, FToggleEnum::Left);
					if (FGroupPopupButton("OffscreenArrows"))
					{
						FSlider("Offset", &tGroup.m_iOffscreenArrowsOffset, 0, 1000, 25, "%i", FSliderEnum::Precision);
						FSlider("Max distance", &tGroup.m_flOffscreenArrowsMaxDistance, 0.f, 5000.f, 50.f, "%g", FSliderEnum::Min | FSliderEnum::Precision);

						EndPopup();
					}

					FToggle("Pickup timer", &tGroup.m_bPickupTimer, FToggleEnum::Left);

					FToggle("Backtrack", &tGroup.m_iBacktrack, BacktrackEnum::Enabled, FToggleEnum::Left);
					if (FGroupPopupButton("Backtrack"))
					{
						FDropdown("##Draw", &tGroup.m_iBacktrack, { "Last", "First", "##Divider", "Always" }, { BacktrackEnum::Last, BacktrackEnum::First, BacktrackEnum::Always }, FDropdownEnum::Multi | FDropdownEnum::NoSanitization, 0, "All");

						FMDropdown("Visible material", &tGroup.m_tBacktrackChams.Visible, FDropdownEnum::Left);
						FMDropdown("Occluded material", &tGroup.m_tBacktrackChams.Occluded, FDropdownEnum::Right);

						PushTransparent(!tGroup.m_tBacktrackGlow.Stencil);
						{
							FSlider("Stencil scale## Backtrack", &tGroup.m_tBacktrackGlow.Stencil, 0, 10, 1, "%i", FSliderEnum::Left | FSliderEnum::Min);
						}
						PopTransparent();
						PushTransparent(!tGroup.m_tBacktrackGlow.Blur);
						{
							FSlider("Blur scale## Backtrack", &tGroup.m_tBacktrackGlow.Blur, 0.f, 10.f, 1.f, "%g", FSliderEnum::Right | FSliderEnum::Min | FSliderEnum::Precision);
						}
						PopTransparent();

						EndPopup();
					}

					FToggle("Trajectory", &tGroup.m_iTrajectory, TrajectoryEnum::Enabled, FToggleEnum::Left);
					if (FGroupPopupButton("Trajectory"))
					{
						FDropdown("Flags", &tGroup.m_iTrajectory, { "Predict", "Radius", "Trace", "Sphere", "Path" }, { TrajectoryEnum::Predict, TrajectoryEnum::Radius, TrajectoryEnum::Trace, TrajectoryEnum::Sphere, TrajectoryEnum::Path }, FDropdownEnum::Multi | FDropdownEnum::NoSanitization);
						FToggle("Ignore Z", &tGroup.m_iTrajectory, TrajectoryEnum::IgnoreZ);

						EndPopup();
					}

					FToggle("Sightlines", &tGroup.m_iSightlines, SightlinesEnum::Enabled, FToggleEnum::Left);
					if (FGroupPopupButton("Sightlines"))
					{
						FToggle("Ignore Z", &tGroup.m_iSightlines, SightlinesEnum::IgnoreZ);

						EndPopup();
					}
				} EndSection();
			}
			EndTable();
		}
		break;
	}
	// Misc
	case 1:
	{
		if (BeginTable("VisualsMiscTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("UI"))
				{
					FDropdown(Vars::Visuals::UI::StreamerMode, FDropdownEnum::Left);
					FColoredDropdown(Vars::Visuals::UI::ChatTags, { &Vars::Colors::Local }, FDropdownEnum::Right);
					PushTransparent(!Vars::Visuals::UI::FieldOfView.Value);
					{
						FSlider(Vars::Visuals::UI::FieldOfView);
					}
					PopTransparent();
					PushTransparent(!Vars::Visuals::UI::ZoomFieldOfView.Value);
					{
						FSlider(Vars::Visuals::UI::ZoomFieldOfView);
					}
					PopTransparent();
					/*
					PushTransparent(!Vars::Visuals::UI::AspectRatio.Value);
					{
						FSlider(Vars::Visuals::UI::AspectRatio);
					}
					PopTransparent();
					*/
					FToggle(Vars::Visuals::UI::RevealScoreboard, FToggleEnum::Left);
					FToggle(Vars::Visuals::UI::ScoreboardUtility, FToggleEnum::Right);
					FToggle(Vars::Visuals::UI::ScoreboardColors, FToggleEnum::Left);
					FToggle(Vars::Visuals::UI::CleanScreenshots, FToggleEnum::Right);
				} EndSection();
				if (Section("Thirdperson"))
				{
					FToggle(Vars::Visuals::Thirdperson::Enabled, FToggleEnum::Left);
					FToggle(Vars::Visuals::Thirdperson::Crosshair, FToggleEnum::Right);
					FSlider(Vars::Visuals::Thirdperson::Distance);
					FSlider(Vars::Visuals::Thirdperson::Right);
					FSlider(Vars::Visuals::Thirdperson::Up);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FToggle(Vars::Visuals::Thirdperson::Scale, FToggleEnum::Left);
							FToggle(Vars::Visuals::Thirdperson::Collide, FToggleEnum::Right);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Effects"))
				{
					// https://developer.valvesoftware.com/wiki/Team_Fortress_2/Particles
					// https://forums.alliedmods.net/showthread.php?t=127111
					FSDropdown(Vars::Visuals::Effects::BulletTracer, FDropdownEnum::Left);
					FSDropdown(Vars::Visuals::Effects::CritTracer, FDropdownEnum::Right);
					FSDropdown(Vars::Visuals::Effects::MedigunBeam, FDropdownEnum::Left);
					FSDropdown(Vars::Visuals::Effects::MedigunCharge, FDropdownEnum::Right);
					FSDropdown(Vars::Visuals::Effects::ProjectileTrail, FDropdownEnum::Left);
					FColoredDropdown(Vars::Visuals::Effects::SpellFootsteps, { &Vars::Colors::SpellFootstep }, FDropdownEnum::Right);
					FDropdown(Vars::Visuals::Effects::RagdollEffects);
					FToggle(Vars::Visuals::Effects::DrawIconsThroughWalls);
					FToggle(Vars::Visuals::Effects::DrawDamageNumbersThroughWalls);
				} EndSection();
				if (Section("Radar"))
				{
					FToggle(Vars::Visuals::Radar::Enabled);
					FDropdown(Vars::Visuals::Radar::Mode);
					FDropdown(Vars::Visuals::Radar::Shape, FDropdownEnum::Left);
					FDropdown(Vars::Visuals::Radar::Position, FDropdownEnum::Right);
					FDropdown(Vars::Visuals::Radar::Orientation);
					FSlider(Vars::Visuals::Radar::Size, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::Range, FSliderEnum::Right);
					FSlider(Vars::Visuals::Radar::OffsetX, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::OffsetY, FSliderEnum::Right);
					FDropdown(Vars::Visuals::Radar::Players);
					FToggle(Vars::Visuals::Radar::Markers, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::ClassIcons, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::Names, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::Health, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::Height, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::Distance, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::Local, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::Rings, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::Outline, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::Crit, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::Ticks, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::Binds, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::BindBackground, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::HideStandalone, FToggleEnum::Right);
					FToggle(Vars::Visuals::Radar::ShowBindKey);
					FSlider(Vars::Visuals::Radar::IconScale, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::NameScale, FSliderEnum::Right);
					FSlider(Vars::Visuals::Radar::DistanceScale, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::HeightScale, FSliderEnum::Right);
					FSlider(Vars::Visuals::Radar::HealthWidthScale, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::HealthHeightScale, FSliderEnum::Right);
					FToggle(Vars::Visuals::Radar::InterfaceColors, FToggleEnum::Left);
					FToggle(Vars::Visuals::Radar::GroupColors, FToggleEnum::Right);
					if (FToggle(Vars::Visuals::Radar::InterfaceBorder) && FGet(Vars::Visuals::Radar::InterfaceBorder))
						FSet(Vars::Visuals::Radar::Border,Vars::Visuals::Radar::Border.Default);
					FDropdown(Vars::Visuals::Radar::BarStyle);
					FSlider(Vars::Visuals::Radar::HeightTolerance, FSliderEnum::Left);
					FSlider(Vars::Visuals::Radar::Opacity, FSliderEnum::Right);
					FColorPicker(Vars::Visuals::Radar::Background, FColorPickerEnum::Left);
					if (FColorPicker(Vars::Visuals::Radar::Border, FColorPickerEnum::Right))
						FSet(Vars::Visuals::Radar::InterfaceBorder,false);
					FColorPicker(Vars::Visuals::Radar::Text, FColorPickerEnum::Left);
					FColorPicker(Vars::Visuals::Radar::LocalColor, FColorPickerEnum::Right);
					FColorPicker(Vars::Visuals::Radar::Enemy, FColorPickerEnum::Left);
					FColorPicker(Vars::Visuals::Radar::Team, FColorPickerEnum::Right);
					FColorPicker(Vars::Visuals::Radar::HealthColor, FColorPickerEnum::Left);
					FColorPicker(Vars::Visuals::Radar::CritColor, FColorPickerEnum::Right);
					FColorPicker(Vars::Visuals::Radar::TickColor, FColorPickerEnum::Left);
					FColorPicker(Vars::Visuals::Radar::BindActive, FColorPickerEnum::Right);
					FColorPicker(Vars::Visuals::Radar::BindInactive, FColorPickerEnum::Left);
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Removals"))
				{
					FToggle(Vars::Visuals::Removals::Interpolation, FToggleEnum::Left);
					PushTransparent(Vars::Visuals::Removals::Interpolation.Value);
					{
						FToggle(Vars::Visuals::Removals::Lerp, FToggleEnum::Right);
					}
					PopTransparent();
					FToggle(Vars::Visuals::Removals::Disguises, FToggleEnum::Left);
					FToggle(Vars::Visuals::Removals::Taunts, FToggleEnum::Right);
					FToggle(Vars::Visuals::Removals::Scope, FToggleEnum::Left);
					FToggle(Vars::Visuals::Removals::PostProcessing, FToggleEnum::Right);
					FToggle(Vars::Visuals::Removals::ScreenOverlays, FToggleEnum::Left);
					FToggle(Vars::Visuals::Removals::ScreenEffects, FToggleEnum::Right);
					FToggle(Vars::Visuals::Removals::ViewPunch, FToggleEnum::Left);
					FToggle(Vars::Visuals::Removals::AngleForcing, FToggleEnum::Right);
					FToggle(Vars::Visuals::Removals::Ragdolls, FToggleEnum::Left);
					FToggle(Vars::Visuals::Removals::Gibs, FToggleEnum::Right);
					FToggle(Vars::Visuals::Removals::MOTD, FToggleEnum::Left);
					FToggle(Vars::Visuals::Animations::Interpolation, FToggleEnum::Right);
				} EndSection();
				if (Section("Viewmodel"))
				{
					FToggle(Vars::Visuals::Viewmodel::CrosshairAim, FToggleEnum::Left);
					FToggle(Vars::Visuals::Viewmodel::ViewmodelAim, FToggleEnum::Right);
					PushTransparent(!Vars::Visuals::Viewmodel::CrosshairAim.Value);
					FToggle(Vars::Visuals::Viewmodel::CrosshairCooldown, FToggleEnum::Left);
					PopTransparent();
					PushTransparent(!Vars::Visuals::Viewmodel::ViewmodelAim.Value);
					FToggle(Vars::Visuals::Viewmodel::ViewmodelCooldown, FToggleEnum::Right);
					PopTransparent();
					FSlider(Vars::Visuals::Viewmodel::OffsetX, FSliderEnum::Left);
					FSlider(Vars::Visuals::Viewmodel::Pitch, FSliderEnum::Right);
					FSlider(Vars::Visuals::Viewmodel::OffsetY, FSliderEnum::Left);
					FSlider(Vars::Visuals::Viewmodel::Yaw, FSliderEnum::Right);
					FSlider(Vars::Visuals::Viewmodel::OffsetZ, FSliderEnum::Left);
					FSlider(Vars::Visuals::Viewmodel::Roll, FSliderEnum::Right);
					PushTransparent(!Vars::Visuals::Viewmodel::SwayScale.Value || !Vars::Visuals::Viewmodel::SwayInterp.Value);
					{
						FSlider(Vars::Visuals::Viewmodel::SwayScale, FSliderEnum::Left);
						FSlider(Vars::Visuals::Viewmodel::SwayInterp, FSliderEnum::Right);
					}
					PopTransparent();
				} EndSection();
				if (Section("World"))
				{
					FDropdown(Vars::Visuals::World::Modulations);
					FSDropdown(Vars::Visuals::World::WorldTexture, FDropdownEnum::Left);
					FSDropdown(Vars::Visuals::World::SkyboxChanger, FDropdownEnum::Right);
					PushTransparent(!(Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::World));
					{
						FColorPicker(Vars::Colors::WorldModulation, FColorPickerEnum::Left);
					}
					PopTransparent();
					PushTransparent(!(Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::Sky));
					{
						FColorPicker(Vars::Colors::SkyModulation, FColorPickerEnum::Right);
					}
					PopTransparent();
					PushTransparent(!(Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::Prop));
					{
						FColorPicker(Vars::Colors::PropModulation, FColorPickerEnum::Left);
					}
					PopTransparent();
					PushTransparent(!(Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::Particle));
					{
						FColorPicker(Vars::Colors::ParticleModulation, FColorPickerEnum::Right);
					}
					PopTransparent();
					PushTransparent(!(Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::Fog));
					{
						FColorPicker(Vars::Colors::FogModulation, FColorPickerEnum::Left);
					}
					PopTransparent();
					FToggle(Vars::Visuals::World::NearPropFade, FToggleEnum::Left);
					FToggle(Vars::Visuals::World::NoPropFade, FToggleEnum::Right);
				} EndSection();
			}
			EndTable();
		}
		break;
	}
	// Menu
	case 2:
	{
		if (BeginTable("MenuTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("Settings"))
				{
					// Share the workspace values with Interface; do not duplicate them in gameplay configs.
					Color_t workspaceAccent = ColorVecToByte({ Workspace::Accent[0], Workspace::Accent[1], Workspace::Accent[2], 1.f });
					Color_t workspaceBackground = ColorVecToByte({ Workspace::Background[0], Workspace::Background[1], Workspace::Background[2], 1.f });
					if (FColorPicker("Accent", &workspaceAccent, FColorPickerEnum::Left))
					{
						Workspace::Accent[0] = workspaceAccent.r / 255.f;
						Workspace::Accent[1] = workspaceAccent.g / 255.f;
						Workspace::Accent[2] = workspaceAccent.b / 255.f;
					}
					if (FColorPicker("Background", &workspaceBackground, FColorPickerEnum::Right))
					{
						Workspace::Background[0] = workspaceBackground.r / 255.f;
						Workspace::Background[1] = workspaceBackground.g / 255.f;
						Workspace::Background[2] = workspaceBackground.b / 255.f;
					}
					const auto configBorder = Workspace::BorderColourOverride ? Workspace::BorderColour : Workspace::Accent;
					Color_t workspaceBorder(int(configBorder[0] * 255), int(configBorder[1] * 255), int(configBorder[2] * 255), 255);
					// Standalone picker: reserve a labelled row instead of attaching a swatch.
					if (FColorPicker("Border / outline color", &workspaceBorder, FColorPickerEnum::Full))
					{
						Workspace::BorderColour[0] = workspaceBorder.r / 255.f;
						Workspace::BorderColour[1] = workspaceBorder.g / 255.f;
						Workspace::BorderColour[2] = workspaceBorder.b / 255.f;
						Workspace::BorderColourOverride = true;
					}
					if (FButton("Use accent for borders")) Workspace::BorderColourOverride = false;
					Color_t activeText(int(Workspace::TextChannel(0)*255), int(Workspace::TextChannel(1)*255), int(Workspace::TextChannel(2)*255), 255);
					Color_t inactiveText(int(Workspace::InactiveTextChannel(0)*255), int(Workspace::InactiveTextChannel(1)*255), int(Workspace::InactiveTextChannel(2)*255), 255);
					if (FColorPicker("Text active", &activeText, FColorPickerEnum::Left))
					{ Workspace::TextColour[0]=activeText.r/255.f; Workspace::TextColour[1]=activeText.g/255.f; Workspace::TextColour[2]=activeText.b/255.f; Workspace::TextColourOverride=true; }
					if (FColorPicker("Text inactive color", &inactiveText, FColorPickerEnum::Right))
					{ Workspace::InactiveTextColour[0]=inactiveText.r/255.f; Workspace::InactiveTextColour[1]=inactiveText.g/255.f; Workspace::InactiveTextColour[2]=inactiveText.b/255.f; Workspace::InactiveTextOverride=true; }
					if (FButton("Use accent for text")) { Workspace::TextColourOverride=false; Workspace::InactiveTextOverride=false; }
					Color_t titleText(int(Workspace::TitleTextChannel(0)*255), int(Workspace::TitleTextChannel(1)*255), int(Workspace::TitleTextChannel(2)*255), 255);
					if (FColorPicker("Text Title Color", &titleText, FColorPickerEnum::Full))
					{ Workspace::TitleTextColour[0]=titleText.r/255.f; Workspace::TitleTextColour[1]=titleText.g/255.f; Workspace::TitleTextColour[2]=titleText.b/255.f; Workspace::TitleTextOverride=true; }
					if (FButton("Use brighter accent for titles")) Workspace::TitleTextOverride=false;

					FSDropdown(Vars::Menu::CheatTitle, FDropdownEnum::Left);
					FSDropdown(Vars::Menu::CheatTag, FDropdownEnum::Right);
					FKeybind(Vars::Menu::PrimaryKey, FButtonEnum::Left, { Vars::Menu::SecondaryKey[DEFAULT_BIND], VK_LBUTTON, VK_RBUTTON });
					FKeybind(Vars::Menu::SecondaryKey, FButtonEnum::Right | FButtonEnum::SameLine, { Vars::Menu::PrimaryKey[DEFAULT_BIND], VK_LBUTTON, VK_RBUTTON });
				} EndSection();
				if (Section("Logging"))
				{
					FDropdown(Vars::Logging::Logs);
					FDropdown(Vars::Logging::NotificationPosition);
					FSlider(Vars::Logging::NotificationTime);
					FSlider(Vars::Logging::MaxNotifications);
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Indicators"))
				{
					FDropdown(Vars::Menu::Indicators);
					if (FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::Spectators)
					{
						FDropdown(Vars::Menu::SpectatorScope);
						FDropdown(Vars::Menu::SpectatorLayout);
						FToggle(Vars::Menu::SpectatorGroup);
						FDropdown(Vars::Menu::SpectatorStates);
						FDropdown(Vars::Menu::SpectatorViews);
						FToggle(Vars::Menu::SpectatorTargets);
						FToggle(Vars::Menu::SpectatorLabels);
						FToggle(Vars::Menu::SpectatorRespawn);
						FSlider(Vars::Menu::SpectatorPage);
						FText(std::format("{} entries / Page {} of {}", F::SpectatorList.m_iEntries,
							F::SpectatorList.m_iCurrentPage, F::SpectatorList.m_iPageCount).c_str());
						if (FButton("Reset spectator size"))
						{
							FSet(Vars::Menu::SpectatorWidth, 0);
							FSet(Vars::Menu::SpectatorHeight, 0);
						}
						FText("Drag any spectator-panel corner to resize.");
						FText("Hidden observer data is presumed; targets are not guessed.");
					}
					if (FSlider(Vars::Menu::Scale))
						H::Fonts.Reload();
					if (FToggle(Vars::Menu::CheapText))
						H::Fonts.Reload();
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FColorPicker(Vars::Colors::IndicatorGood, FColorPickerEnum::Left);
							FColorPicker(Vars::Colors::IndicatorTextGood, FColorPickerEnum::Right);
							FColorPicker(Vars::Colors::IndicatorBad, FColorPickerEnum::Left);
							FColorPicker(Vars::Colors::IndicatorTextBad, FColorPickerEnum::Right);
							FColorPicker(Vars::Colors::IndicatorMid, FColorPickerEnum::Left);
							FColorPicker(Vars::Colors::IndicatorTextMid, FColorPickerEnum::Right);
							FColorPicker(Vars::Colors::IndicatorMisc, FColorPickerEnum::Left);
							FColorPicker(Vars::Colors::IndicatorTextMisc, FColorPickerEnum::Right);

							EndPopup();
						}
					}
					EndSection();
				}
				if (Section("Log options"))
				{
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::VoteStart));
					{
						FDropdown(Vars::Logging::VoteStart::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::VoteCast));
					{
						FDropdown(Vars::Logging::VoteCast::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::ClassChanges));
					{
						FDropdown(Vars::Logging::ClassChange::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::Damage));
					{
						FDropdown(Vars::Logging::Damage::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::CheatDetection));
					{
						FDropdown(Vars::Logging::CheatDetection::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::Tags));
					{
						FDropdown(Vars::Logging::Tags::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::Aliases));
					{
						FDropdown(Vars::Logging::Aliases::LogTo);
					}
					PopTransparent();
					PushTransparent(!(Vars::Logging::Logs.Value & Vars::Logging::LogsEnum::Resolver));
					{
						FDropdown(Vars::Logging::Resolver::LogTo);
					}
					PopTransparent();
				} EndSection();
			}
			EndTable();
		}
		break;
	}
	}
}

void CMenu::MenuMisc(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// Main
	case 0:
	{
		if (BeginTable("MiscTable", 2))
		{
			/* Column 1 */
			TableNextColumn();
			{
				if (Section("Movement"))
				{
					FDropdown(Vars::Misc::Movement::AutoStrafe);
					PushTransparent(Vars::Misc::Movement::AutoStrafe.Value != Vars::Misc::Movement::AutoStrafeEnum::Directional);
					{
						FSlider(Vars::Misc::Movement::AutoStrafeTurnScale, FSliderEnum::Left);
						FSlider(Vars::Misc::Movement::AutoStrafeMaxDelta, FSliderEnum::Right);
					}
					PopTransparent();
					FToggle(Vars::Misc::Movement::Bunnyhop, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::EdgeJump, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::AutoJumpbug, FToggleEnum::Left); // this is unreliable without setups, do not depend on it!
					FToggle(Vars::Misc::Movement::BreakJump, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::AutoRocketJump, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::AutoCTap, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::AutoFaNJump, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::AutoRevJump, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::FastStop, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::FastAccelerate, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::DuckSpeed, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::ShieldTurnRate, FToggleEnum::Right);
					FToggle(Vars::Misc::Movement::NoPush, FToggleEnum::Left);
					FToggle(Vars::Misc::Movement::MovementLock, FToggleEnum::Right);
				} EndSection();
				if (Section("Blockbot"))
				{
					FToggle(Vars::Misc::Blockbot::Enabled);
					FDropdown(Vars::Misc::Blockbot::Target);
					FDropdown(Vars::Misc::Blockbot::Team);
					FDropdown(Vars::Misc::Blockbot::Behavior);
					if (Vars::Misc::Blockbot::Team.Value != Vars::Misc::Blockbot::TeamEnum::Enemies)
						FDropdown(Vars::Misc::Blockbot::TeammateBehavior);
					FSlider(Vars::Misc::Blockbot::Range);
					FSlider(Vars::Misc::Blockbot::ResumeDelay);
					FSlider(Vars::Misc::Blockbot::Acceleration, FSliderEnum::Left);
					FSlider(Vars::Misc::Blockbot::Deceleration, FSliderEnum::Right);
					FToggle(Vars::Misc::Blockbot::WhileMenuOpen);
					FToggle(Vars::Misc::Blockbot::WhileCrouching);
					FToggle(Vars::Misc::Blockbot::ContinueFollowing);
					FToggle(Vars::Misc::Blockbot::IgnoreDanger);
					if (Vars::Misc::Blockbot::Target.Value == Vars::Misc::Blockbot::TargetEnum::Manual)
					{
						TextWrapped("Manual target: %s", F::Blockbot.ManualName().c_str());
						TextWrapped("Right-click a player in the player list to select them.");
					}
					TextWrapped("%s", F::Blockbot.Status().c_str());
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FSlider(Vars::Misc::Movement::AutoRocketJumpChokeGrounded, FSliderEnum::Left);
							FSlider(Vars::Misc::Movement::AutoRocketJumpChokeAir, FSliderEnum::Right);
							FSlider(Vars::Misc::Movement::AutoRocketJumpSkipGround, FSliderEnum::Left);
							FSlider(Vars::Misc::Movement::AutoRocketJumpSkipAir, FSliderEnum::Right);
							FSlider(Vars::Misc::Movement::AutoRocketJumpTimingOffset, FSliderEnum::Left);
							FSlider(Vars::Misc::Movement::AutoRocketJumpApplyAbove, FSliderEnum::Right);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Automation"))
				{
					FDropdown(Vars::Misc::Automation::AntiBackstab); // pitch/fake _might_ slip up some auto backstabs
					FToggle(Vars::Misc::Automation::TauntControl, FToggleEnum::Left);
					FToggle(Vars::Misc::Automation::KartControl, FToggleEnum::Right);
					FToggle(Vars::Misc::Automation::AntiAutobalance, FToggleEnum::Left);
					FToggle(Vars::Misc::Automation::AntiAFK, FToggleEnum::Right);
					FToggle(Vars::Misc::Automation::AutoF2Ignored, FToggleEnum::Left);
					FToggle(Vars::Misc::Automation::AutoF1Priority, FToggleEnum::Right);
					FToggle(Vars::Misc::Automation::AcceptItemDrops);
				} EndSection();
				if (Section("Mann vs. Machine"))
				{
					FToggle(Vars::Misc::MannVsMachine::InstantRespawn, FToggleEnum::Left);
					FToggle(Vars::Misc::MannVsMachine::InstantRevive, FToggleEnum::Right);
					FToggle(Vars::Misc::MannVsMachine::AllowInspect);
				} EndSection();
			}
			/* Column 2 */
			TableNextColumn();
			{
				if (Section("Exploits"))
				{
					FToggle(Vars::Misc::Exploits::PureBypass, FToggleEnum::Left);
					FToggle(Vars::Misc::Exploits::CheatsBypass, FToggleEnum::Right);
					FToggle(Vars::Misc::Exploits::UnlockCVars, FToggleEnum::Left);
					FToggle(Vars::Misc::Exploits::EquipRegionUnlock, FToggleEnum::Right);
					FToggle(Vars::Misc::Exploits::BackpackExpander, FToggleEnum::Left);
					FToggle(Vars::Misc::Exploits::NoisemakerSpam, FToggleEnum::Right);
					FToggle(Vars::Misc::Exploits::PingReducer, FToggleEnum::Left);
					PushTransparent(!Vars::Misc::Exploits::PingReducer.Value);
					{
						FSlider(Vars::Misc::Exploits::PingTarget, FSliderEnum::Right);
					}
					PopTransparent();
				} EndSection();
				if (Section("Game"))
				{
					FToggle(Vars::Misc::Game::NetworkFix, FToggleEnum::Left);
					FToggle(Vars::Misc::Game::SetupBonesOptimization, FToggleEnum::Right);
					FToggle(Vars::Misc::Game::AntiCheatCompatibility);
				} EndSection();
				if (Vars::Debug::Options.Value)
				{
					if (Section("##Debug AntiCheat"))
					{
						FText("Debug", { 5, 5 });
						if (FPopupButton("Debug", { 0, -5 }))
						{
							FToggle(Vars::Misc::Game::AntiCheatCritHack);

							EndPopup();
						}
					} EndSection();
				}
				if (Section("Queueing"))
				{
					FDropdown(Vars::Misc::Queueing::ForceRegions);
					FToggle(Vars::Misc::Queueing::ExtendQueue, FToggleEnum::Left);
					FToggle(Vars::Misc::Queueing::AutoCasualQueue, FToggleEnum::Right);
				} EndSection();
				if (Section("Sound"))
				{
					FDropdown(Vars::Misc::Sound::Block);
					FToggle(Vars::Misc::Sound::HitsoundAlways, FToggleEnum::Left);
					FToggle(Vars::Misc::Sound::RemoveDSP, FToggleEnum::Right);
					FToggle(Vars::Misc::Sound::GiantWeaponSounds);
				} EndSection();
				if (Section("Cheat Detection"))
				{
					FDropdown(Vars::CheatDetection::Methods);
					PushTransparent(!Vars::CheatDetection::DetectionsRequired.Value);
					{
						FSlider(Vars::CheatDetection::DetectionsRequired);
					}
					PopTransparent();
					PushTransparent(!(Vars::CheatDetection::Methods.Value & Vars::CheatDetection::MethodsEnum::PacketChoking));
					{
						FSlider(Vars::CheatDetection::MinChoking);
					}
					PopTransparent();
					PushTransparent(!(Vars::CheatDetection::Methods.Value & Vars::CheatDetection::MethodsEnum::AimFlicking));
					{
						FSlider(Vars::CheatDetection::MinFlick, FSliderEnum::Left);
						FSlider(Vars::CheatDetection::MaxNoise, FSliderEnum::Right);
					}
					PopTransparent();
				} EndSection();
			}
			EndTable();
		}
		if (Section("Skin changer"))
		{
			SkinChanger::Menu();
		} EndSection();
		break;
	}
	}
}

void CMenu::MenuLogs(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// PlayerList
	case 0:
	{
		if (Section("Players"))
		{
			if (I::EngineClient->IsInGame())
			{
				std::lock_guard tLock(m_tMutex);
				const auto& vPlayers = F::PlayerUtils.m_vPlayerCache;

				std::unordered_map<uint64_t, std::vector<const ListPlayer*>> mParties = {};
				int iPartyCount = 0;
				for (auto& tPlayer : vPlayers)
				{
					if (tPlayer.m_iParty)
					{
						mParties[tPlayer.m_iParty].push_back(&tPlayer);
						iPartyCount = std::max(iPartyCount, tPlayer.m_iParty);
					}
				}

				auto fGetTeamColor = [&](int iTeam, bool bAlive)
				{
					switch (iTeam)
					{
					case 3: return Color_t(100, 150, 200, bAlive ? 255 : 127).Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha);
					case 2: return Color_t(255, 100, 100, bAlive ? 255 : 127).Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha);
					}
					return Color_t(127, 127, 127, 255).Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha);
				};
				auto fDrawPlayer = [&](const ListPlayer& tPlayer)
				{
					TableNextRow(ImGuiTableRowFlags_None, H::Draw.Scale(18));
					TableSetBgColor(ImGuiTableBgTarget_RowBg0, ColorByteToFloat(fGetTeamColor(tPlayer.m_iTeam, tPlayer.m_bAlive)));
					PushID(tPlayer.m_iUserID);
					TableSetColumnIndex(0);
					Selectable(std::format("{}##player", tPlayer.m_iIndex).c_str(), false,
						ImGuiSelectableFlags_SpanAllColumns, { 0, GetTextLineHeight() });
					bool bPopup = IsItemHovered() && IsMouseReleased(ImGuiMouseButton_Right);
					auto cell = [&](int column, const std::string& value)
					{
						TableSetColumnIndex(column);
						TextUnformatted(value.c_str());
						if (IsItemHovered() && CalcTextSize(value.c_str()).x > GetContentRegionAvail().x)
							SetTooltip("%s", value.c_str());
					};
					cell(1, std::to_string(tPlayer.m_iUserID));
					cell(2, tPlayer.m_sName);
					cell(3, std::to_string(tPlayer.m_iScore));
					cell(4, std::to_string(tPlayer.m_iDeaths));
					cell(5, tPlayer.m_bFake ? "BOT" : std::to_string(tPlayer.m_iPing));
					TableSetBgColor(ImGuiTableBgTarget_CellBg, tPlayer.m_bAlive ? IM_COL32(28, 110, 38, 255) : IM_COL32(55, 55, 55, 255), 6);
					cell(6, tPlayer.m_bAlive ? std::to_string(tPlayer.m_iHealth) : "DEAD");
					static const char* classes[] = { "-", "Scout", "Sniper", "Soldier", "Demoman", "Medic", "Heavy", "Pyro", "Spy", "Engineer" };
					cell(7, classes[std::clamp(tPlayer.m_iClass, 0, 9)]);
					TableSetColumnIndex(8);
					bool hasTag = false;
					if (tPlayer.m_bF2P) { TextUnformatted("F2P"); SameLine(0, H::Draw.Scale(6)); hasTag = true; }
					if (tPlayer.m_bLocal) { TextUnformatted("Local"); hasTag = true; }
					else if (tPlayer.m_bFriend) { TextUnformatted("Friend"); hasTag = true; }
					else if (tPlayer.m_bParty) { TextUnformatted("Party"); hasTag = true; }
					if (!tPlayer.m_bFake)
					{
						for (int tag : F::PlayerUtils.GetPlayerTags(tPlayer.m_uAccountID))
							if (auto entry = F::PlayerUtils.GetTag(tag))
							{
								if (hasTag) SameLine(0, H::Draw.Scale(6));
								TextColored(ColorByteToVec(entry->m_tColor), "%s", entry->m_sName.c_str());
								hasTag = true;
							}
					}
					// popups
					if (bPopup)
						OpenPopup(std::format("RightClicked{}", tPlayer.m_iUserID).c_str());

					if (FBeginPopup(std::format("RightClicked{}", tPlayer.m_iUserID).c_str()))
					{
						PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), H::Draw.Scale(8) });

						if (!tPlayer.m_bFake)
						{
							if (FSelectable("Profile"))
								I::SteamFriends->ActivateGameOverlayToUser("steamid", CSteamID(tPlayer.m_uAccountID, k_EUniversePublic, k_EAccountTypeIndividual));
							if (FSelectable("History"))
								I::SteamFriends->ActivateGameOverlayToWebPage(std::format("https://steamhistory.net/id/{}", CSteamID(tPlayer.m_uAccountID, k_EUniversePublic, k_EAccountTypeIndividual).ConvertToUint64()).c_str());
						}

						if (FSelectable(F::Spectate.GetTarget(true) == tPlayer.m_iUserID ? "Unspectate" : "Spectate"))
							F::Spectate.SetTarget(tPlayer.m_iUserID);
						if (!tPlayer.m_bLocal && !I::EngineClient->IsPlayingDemo() && FSelectable("Set as blockbot target"))
						{
							F::Blockbot.SetManual(tPlayer.m_iUserID, tPlayer.m_uAccountID, tPlayer.m_sName);
							Vars::Misc::Blockbot::Target.Map[DEFAULT_BIND] = Vars::Misc::Blockbot::TargetEnum::Manual;
							Vars::Misc::Blockbot::Target.Value = Vars::Misc::Blockbot::TargetEnum::Manual;
						}
#ifdef NIKOGRAM_PRIVATE_LEARNING
						if (!tPlayer.m_bLocal && !tPlayer.m_bFake && tPlayer.m_uAccountID && !I::EngineClient->IsPlayingDemo() && FSelectable("Learn only this player (private)"))
							PrivateLearning::Select(tPlayer.m_uAccountID, tPlayer.m_sName);
#endif

						if (!I::EngineClient->IsPlayingDemo() && FBeginMenu("Votekick"))
						{
							if (IsItemHovered() && IsMouseClicked(ImGuiMouseButton_Left)) // clicked, so holding the mouse doesn't send it every frame
							{
								I::ClientState->SendStringCmd(std::format("callvote Kick \"{}\"", tPlayer.m_iUserID).c_str());
								CloseCurrentPopup();
							}
							if (FSelectable("No reason"))
								I::ClientState->SendStringCmd(std::format("callvote Kick \"{} other\"", tPlayer.m_iUserID).c_str());
							if (FSelectable("Cheating"))
								I::ClientState->SendStringCmd(std::format("callvote Kick \"{} cheating\"", tPlayer.m_iUserID).c_str());
							if (FSelectable("Idle"))
								I::ClientState->SendStringCmd(std::format("callvote Kick \"{} idle\"", tPlayer.m_iUserID).c_str());
							if (FSelectable("Scamming"))
								I::ClientState->SendStringCmd(std::format("callvote Kick \"{} scamming\"", tPlayer.m_iUserID).c_str());

							ImGui::EndMenu();
						}

						if (!tPlayer.m_bFake)
						{
							if (FBeginMenu("Add tag"))
							{
								for (auto it = F::PlayerUtils.m_vTags.begin(); it != F::PlayerUtils.m_vTags.end(); it++)
								{
									int iID = std::distance(F::PlayerUtils.m_vTags.begin(), it);
									auto& tTag = *it;
									if (!tTag.m_bAssignable || F::PlayerUtils.HasTag(tPlayer.m_uAccountID, iID))
										continue;

									ImVec4 tColor = ColorByteToVec(tTag.m_tColor);
									PushStyleColor(ImGuiCol_Text, tColor);
									tColor.x /= 3; tColor.y /= 3; tColor.z /= 3;
									if (FSelectable(tTag.m_sName.c_str(), tColor))
										F::PlayerUtils.AddTag(tPlayer.m_uAccountID, iID, true, tPlayer.m_sName.c_str());
									PopStyleColor();
								}

								ImGui::EndMenu();
							}
							if (FBeginMenu("Remove tag"))
							{
								int remove = -1;
								for (int tag : F::PlayerUtils.GetPlayerTags(tPlayer.m_uAccountID))
									if (auto entry = F::PlayerUtils.GetTag(tag))
										if (FSelectable(entry->m_sName.c_str())) remove = tag;
								if (remove >= 0) F::PlayerUtils.RemoveTag(tPlayer.m_uAccountID, remove, true, tPlayer.m_sName.c_str());
								ImGui::EndMenu();
							}
							if (FBeginMenu("Alias"))
							{
								bool bHasAlias = F::PlayerUtils.m_mPlayerAliases.contains(tPlayer.m_uAccountID);
								static std::string sInput = "";

								bool bEnter = FInputText("Alias...", sInput, H::Draw.Scale(150), ImGuiInputTextFlags_EnterReturnsTrue);
								if (!IsItemFocused())
									sInput = bHasAlias ? F::PlayerUtils.m_mPlayerAliases[tPlayer.m_uAccountID] : "";
								if (bEnter)
								{
									if (sInput.empty() && bHasAlias)
									{
										F::Output.AliasChanged(tPlayer.m_sName.c_str(), "Removed", F::PlayerUtils.m_mPlayerAliases[tPlayer.m_uAccountID].c_str());

										F::PlayerUtils.m_mPlayerAliases.erase(tPlayer.m_uAccountID);
										F::PlayerUtils.m_bSave = true;
									}
									else if (!sInput.empty())
									{
										F::PlayerUtils.m_mPlayerAliases[tPlayer.m_uAccountID] = sInput;
										F::PlayerUtils.m_bSave = true;

										F::Output.AliasChanged(tPlayer.m_sName.c_str(), bHasAlias ? "Changed" : "Added", sInput.c_str());
									}
								}

								ImGui::EndMenu();
							}
						}

						if (Vars::Resolver::Enabled.Value && !tPlayer.m_bLocal && !I::EngineClient->IsPlayingDemo())
						{
							if (FBeginMenu("Set yaw"))
							{
								static std::vector<std::pair<const char*, float>> vYaws = {
									{ "Auto", 0.f },
									{ "Forward", 0.f },
									{ "Left", 90.f },
									{ "Right", -90.f },
									{ "Backwards", 180.f }
								};
								for (auto& [sYaw, flValue] : vYaws)
								{
									if (FSelectable(sYaw))
									{
										switch (FNV1A::Hash32(sYaw))
										{
										case FNV1A::Hash32Const("Auto"):
											F::Resolver.SetYaw(tPlayer.m_iUserID, 0.f, true);
											break;
										default:
											F::Resolver.SetYaw(tPlayer.m_iUserID, flValue);
										}
									}
								}

								ImGui::EndMenu();
							}
							if (FBeginMenu("Set pitch"))
							{
								static std::vector<std::pair<const char*, float>> vPitches = {
									{ "Auto", 0.f },
									{ "Up", -90.f },
									{ "Down", 90.f },
									{ "Zero", 0.f },
									{ "Inverse", 0.f }
								};
								for (auto& [sPitch, flValue] : vPitches)
								{
									if (FSelectable(sPitch))
									{
										switch (FNV1A::Hash32(sPitch))
										{
										case FNV1A::Hash32Const("Auto"):
											F::Resolver.SetPitch(tPlayer.m_iUserID, 0.f, false, true);
											break;
										case FNV1A::Hash32Const("Inverse"):
											F::Resolver.SetPitch(tPlayer.m_iUserID, 0.f, true);
											break;
										default:
											F::Resolver.SetPitch(tPlayer.m_iUserID, flValue);
										}
									}
								}

								ImGui::EndMenu();
							}
							if (FBeginMenu("Set view"))
							{
								static std::vector<std::pair<const char*, bool>> vPitches = {
									{ "Offset from static view", true },
									{ "Offset from view to local", false }
								};
								for (auto& [sPitch, bValue] : vPitches)
								{
									if (FSelectable(sPitch))
										F::Resolver.SetView(tPlayer.m_iUserID, bValue);
								}

								ImGui::EndMenu();
							}
							if (FBeginMenu("Set minwalk"))
							{
								static std::vector<std::pair<const char*, bool>> vPitches = {
									{ "Minwalk on", true },
									{ "Minwalk off", false }
								};
								for (auto& [sPitch, bValue] : vPitches)
								{
									if (FSelectable(sPitch))
										F::Resolver.SetMinwalk(tPlayer.m_iUserID, bValue);
								}

								ImGui::EndMenu();
							}
						}

						if (mParties.contains(tPlayer.m_iParty))
						{
							Divider(H::Draw.Scale(1), 0);

							TextColored(F::Render.Inactive.Value, "Partied:");
							for (auto& pPlayer2 : mParties[tPlayer.m_iParty])
								TextColored(F::Render.Inactive.Value, pPlayer2->m_sName.c_str());
						}

						if (tPlayer.m_iLevel != -2)
						{
							Divider(H::Draw.Scale(1), 0);

							std::string sLevel = "T? L?";
							if (tPlayer.m_iLevel != -1)
							{
								int iTier = std::max(ceilf(tPlayer.m_iLevel / 150.f), 1.f);
								int iLevel = ((tPlayer.m_iLevel - 1) % 150) + 1;
								sLevel = std::format("T{} L{}", iTier, iLevel);
							}
							TextColored(F::Render.Inactive.Value, sLevel.c_str());
						}

						PopStyleVar();
						EndPopup();
					}
					PopID();
				};

				PushStyleVar(ImGuiStyleVar_CellPadding, { H::Draw.Scale(4), H::Draw.Scale(1) });
				PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 0 });
				if (BeginTable("PlayerGrid", 9, ImGuiTableFlags_Borders | ImGuiTableFlags_Resizable | ImGuiTableFlags_SizingStretchProp))
				{
					TableSetupColumn("Index", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(36));
					TableSetupColumn("UserID", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(44));
					TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch, 3.f);
					TableSetupColumn("Score", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(38));
					TableSetupColumn("Deaths", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(44));
					TableSetupColumn("Ping", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(38));
					TableSetupColumn("Health", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(44));
					TableSetupColumn("Class", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(66));
					TableSetupColumn("Tags", ImGuiTableColumnFlags_WidthStretch, 1.5f);
					TableHeadersRow();
					for (int team : { 3, 2, 1, 0 })
						for (const auto& player : vPlayers)
							if (player.m_iTeam == team) fDrawPlayer(player);
					EndTable();
				}
				PopStyleVar(2);
			}
			else
			{
				SetCursorPos({ H::Draw.Scale(15), H::Draw.Scale(40) });
				FText("Not ingame");
				DebugDummy({ 0, H::Draw.Scale(8) });
			}
		} EndSection();
		if (Section("Tags"))
		{
			static int iID = -1;
			static PriorityLabel_t tTag = {};
			static int iPendingDelete = -1; // tag deletion is deferred until the tag list is no longer being iterated

			const float editorHeight = CompactDropdownHeight(true);
			const float actionWidth = editorHeight * 2 + H::Draw.Scale(8);
			auto vTable = WidgetTable(3, std::max(H::Draw.Scale(40), editorHeight + H::Draw.Scale(8)), { GetWindowWidth() / 2, GetWindowWidth() / 2 - actionWidth - GetStyle().WindowPadding.x });

			if (BeginWidgetTable(0, vTable))
			{
				const ImVec2 nameOrigin = GetCursorPos();
				FSDropdown("Name", &tTag.m_sName, {}, FDropdownEnum::Left | FSDropdownEnum::AutoUpdate, -14);

				PushDisabled(iID == F::PlayerUtils.TagToIndex(DEFAULT_TAG) || iID == F::PlayerUtils.TagToIndex(IGNORED_TAG)); // iID is a list index, not a tag id
				{
					int iLabel = Disabled ? 0 : tTag.m_bLabel;
					FDropdown("Type", &iLabel, { "Priority", "Label" }, {}, FDropdownEnum::Right);
					tTag.m_bLabel = iLabel;
					if (Disabled)
						tTag.m_bLabel = false;
				}
				PopDisabled();
				// Draw the swatch after both fields so its item cannot move Type's baseline.
				const ImVec2 next = GetCursorPos();
				const float nameRight = nameOrigin.x + GetWindowWidth() / 2 - GetStyle().WindowPadding.x * 1.5f - H::Draw.Scale(14);
				const float typeLeft = GetWindowWidth() / 2 + GetStyle().WindowPadding.x * 0.5f;
				const float swatchLeft = (nameRight + typeLeft - H::Draw.Scale(10)) * 0.5f;
				SetCursorPos({ swatchLeft, nameOrigin.y + H::Draw.Scale(3) });
				FColorPicker("Color", &tTag.m_tColor, AttachedColorPicker | FColorPickerEnum::Tooltip, {}, { H::Draw.Scale(10), editorHeight });
				SetCursorPos(next);
				Dummy({0,0}); // Submit the restored row end before EndChild (ImGui 1.92).
			} EndChild();

			if (BeginWidgetTable(1, vTable))
			{
				PushTransparent(tTag.m_bLabel); // transparent if we want a label, user can still use to sort
				{
					SetCursorPosY(GetCursorPos().y + H::Draw.Scale(3));
					FSlider("Priority", &tTag.m_iPriority, -10, 10);
				}
				PopTransparent();
			} EndChild();

			if (BeginWidgetTable(2, vTable))
			{
				// create/modify button
				bool bCreate = false, bClear = false;

				const float buttonY = GetCursorPosY() + H::Draw.Scale(3) - GetStyle().WindowPadding.y;
				const float buttonSize = editorHeight / H::Draw.Scale(1);
				SetCursorPos({ GetWindowWidth() - GetStyle().WindowPadding.x - actionWidth, buttonY });
				PushDisabled(tTag.m_sName.empty());
				{
					bCreate = FButton(iID != -1 ? ICON_MD_SETTINGS : ICON_MD_ADD, FButtonEnum::None, { buttonSize, buttonSize }, 0, F::Render.IconFont);
				}
				PopDisabled();

				// clear button
				SetCursorPos({ GetWindowWidth() - GetStyle().WindowPadding.x - editorHeight, buttonY });
				bClear = FButton(ICON_MD_CLEAR, FButtonEnum::None, { buttonSize, buttonSize }, 0, F::Render.IconFont);

				if (bCreate)
				{
					F::PlayerUtils.m_bSave = true;
					if (iID > -1 && iID < F::PlayerUtils.m_vTags.size())
					{
						F::PlayerUtils.m_vTags[iID].m_sName = tTag.m_sName;
						F::PlayerUtils.m_vTags[iID].m_tColor = tTag.m_tColor;
						F::PlayerUtils.m_vTags[iID].m_iPriority = tTag.m_iPriority;
						F::PlayerUtils.m_vTags[iID].m_bLabel = tTag.m_bLabel;
					}
					else
						F::PlayerUtils.m_vTags.push_back(tTag);
				}
				if (bCreate || bClear)
				{
					iID = -1;
					tTag = {};
				}
			} EndChild();

			auto fDrawTag = [](std::vector<PriorityLabel_t>::iterator it, PriorityLabel_t& _tTag, int y)
			{
				int _iID = std::distance(F::PlayerUtils.m_vTags.begin(), it);

				ImVec2 vOriginalPos = { !_tTag.m_bLabel ? GetStyle().WindowPadding.x : GetWindowWidth() * 2 / 3 + GetStyle().WindowPadding.x / 2, H::Draw.Scale(96 + 22 * y) };

				// background
				float flWidth = GetWindowWidth() * (_tTag.m_bLabel ? 1.f / 3 : 2.f / 3) - GetStyle().WindowPadding.x * 1.5f;
				float flHeight = H::Draw.Scale(22);
				ImColor tColor = ColorByteToFloat(_tTag.m_tColor.Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha));
				ImVec2 vDrawPos = GetDrawPos() + vOriginalPos;
				if (iID != _iID)
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), tColor, 0);
				else
				{
					ImColor tColor2 = { tColor.Value.x * 1.1f, tColor.Value.y * 1.1f, tColor.Value.z * 1.1f, tColor.Value.w };
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), tColor2, 0);

					tColor2 = ColorByteToFloat(_tTag.m_tColor.Lerp(Vars::Menu::Theme::Background.Value, 0.25f, LerpEnum::NoAlpha));
					float flInset = H::Draw.Scale(0.5f) - 0.5f;
					GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(flWidth - flInset, flHeight - flInset), tColor2, 0, ImDrawFlags_None, H::Draw.Scale());
				}

				// Square, contiguous table-like cells retain the configured tag colours.
				GetWindowDrawList()->AddRect(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), GetColorU32(ImGuiCol_TableBorderLight));
				if (!_tTag.m_bLabel)
					GetWindowDrawList()->AddLine(vDrawPos + ImVec2(flWidth / 2 - H::Draw.Scale(4), 0), vDrawPos + ImVec2(flWidth / 2 - H::Draw.Scale(4), flHeight), GetColorU32(ImGuiCol_TableBorderLight));
				GetWindowDrawList()->AddLine(vDrawPos + ImVec2(flWidth - H::Draw.Scale(28), 0), vDrawPos + ImVec2(flWidth - H::Draw.Scale(28), flHeight), GetColorU32(ImGuiCol_TableBorderLight));

				// text
				SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(9), H::Draw.Scale(4)));
				FText(TruncateText(_tTag.m_sName, _tTag.m_bLabel ? flWidth - H::Draw.Scale(38) : flWidth / 2 - H::Draw.Scale(20)).c_str());

				if (!_tTag.m_bLabel)
				{
					SetCursorPos(vOriginalPos + ImVec2(flWidth / 2, H::Draw.Scale(4)));
					FText(std::format("{}", _tTag.m_iPriority).c_str());
				}

				// buttons / icons
				bool bDelete = false;
				if (!_tTag.m_bLocked)
				{
					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(26), H::Draw.Scale(2)));
					PushID(_iID);
					bDelete = SmallButton("x");
					PopID();
				}
				else
				{
					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(22), H::Draw.Scale(3)));
					switch (F::PlayerUtils.IndexToTag(_iID))
					{
						//case DEFAULT_TAG: // no image
					case IGNORED_TAG: IconImage(ICON_MD_DO_NOT_DISTURB); break;
					case CHEATER_TAG: IconImage(ICON_MD_FLAG); break;
					case FRIEND_TAG: IconImage(ICON_MD_GROUP); break;
					case PARTY_TAG: IconImage(ICON_MD_GROUPS); break;
					case F2P_TAG: IconImage(ICON_MD_MONEY_OFF); break;
					}
				}

				SetCursorPos(vOriginalPos);
				bool bClicked = InvisibleButton(std::format("##TagRow{}", _iID).c_str(), { flWidth - H::Draw.Scale(28), flHeight });
				bool bPopup = IsItemClicked(ImGuiMouseButton_Right);

				if (bClicked)
				{
					iID = _iID;
					tTag.m_sName = _tTag.m_sName;
					tTag.m_tColor = _tTag.m_tColor;
					tTag.m_iPriority = _tTag.m_iPriority;
					tTag.m_bLabel = _tTag.m_bLabel;
				}
				else if (bPopup)
					OpenPopup(std::format("RightClicked{}", _iID).c_str());
				else if (bDelete)
					OpenPopup(std::format("DeleteTag{}", _iID).c_str());

				if (FBeginPopup(std::format("RightClicked{}", _iID).c_str()))
				{
					PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), 0 });

					auto& _tTag2 = *it;
					bool bSave = false;

					{
						static std::string sInput = "";

						bool bEnter = FInputText("Name...", sInput, H::Draw.Scale(284), ImGuiInputTextFlags_EnterReturnsTrue);
						if (!IsItemFocused())
							sInput = _tTag2.m_sName;
						if (bEnter)
						{
							_tTag2.m_sName = sInput;
							bSave = true;
						}
					}

					PushDisabled(_iID == F::PlayerUtils.TagToIndex(DEFAULT_TAG) || _iID == F::PlayerUtils.TagToIndex(IGNORED_TAG));
					{
						int iLabel = Disabled ? 0 : _tTag2.m_bLabel;
						if (FDropdown("Type##", &iLabel, { "Priority", "Label" }))
							bSave = true;
						_tTag2.m_bLabel = iLabel;
						if (Disabled)
							_tTag2.m_bLabel = false;
					}
					PopDisabled();
					if (FSlider("Priority##", &_tTag2.m_iPriority, -10, 10))
						bSave = true;

					if (bSave)
						F::PlayerUtils.m_bSave = true;

					PopStyleVar();
					EndPopup();
				}
				else if (FBeginPopupModal(std::format("DeleteTag{}", _iID).c_str()))
				{
					FText(std::format("Do you really want to delete '{}'?", _tTag.m_sName).c_str());

					if (FButton("Yes", FButtonEnum::Left))
					{
						iPendingDelete = _iID;
						CloseCurrentPopup();
					}
					if (FButton("No", FButtonEnum::Right | FButtonEnum::SameLine))
						CloseCurrentPopup();

					EndPopup();
				}
			};

			for (bool label : { false, true })
			{
				const float x = label ? GetWindowWidth() * 2 / 3 + GetStyle().WindowPadding.x / 2 : GetStyle().WindowPadding.x;
				const float width = GetWindowWidth() * (label ? 1.f / 3 : 2.f / 3) - GetStyle().WindowPadding.x * 1.5f;
				const ImVec2 pos = GetDrawPos() + ImVec2(x, H::Draw.Scale(76));
				GetWindowDrawList()->AddRectFilled(pos, pos + ImVec2(width, H::Draw.Scale(20)), GetColorU32(ImGuiCol_TableHeaderBg));
				GetWindowDrawList()->AddRect(pos, pos + ImVec2(width, H::Draw.Scale(20)), GetColorU32(ImGuiCol_TableBorderStrong));
				SetCursorPos({ x + H::Draw.Scale(5), H::Draw.Scale(79) });
				FText(label ? "Labels" : "Priorities");
				if (!label)
				{
					SetCursorPos({ x + width / 2, H::Draw.Scale(79) }); FText("Value");
				}
			}

			std::vector<std::pair<std::vector<PriorityLabel_t>::iterator, PriorityLabel_t>> vPriorities = {}, vLabels = {};
			for (auto it = F::PlayerUtils.m_vTags.begin(); it != F::PlayerUtils.m_vTags.end(); it++)
			{
				auto& _tTag = *it;

				if (!_tTag.m_bLabel)
					vPriorities.emplace_back(it, _tTag);
				else
					vLabels.emplace_back(it, _tTag);
			}

			std::sort(vPriorities.begin(), vPriorities.end(), [&](const auto& a, const auto& b) -> bool
			{
				// override for default tag (keep the comparator irreflexive)
				bool bDefaultA = std::distance(F::PlayerUtils.m_vTags.begin(), a.first) == F::PlayerUtils.TagToIndex(DEFAULT_TAG), bDefaultB = std::distance(F::PlayerUtils.m_vTags.begin(), b.first) == F::PlayerUtils.TagToIndex(DEFAULT_TAG);
				if (bDefaultA != bDefaultB)
					return bDefaultA;

				// sort by priority if unequal
				if (a.second.m_iPriority != b.second.m_iPriority)
					return a.second.m_iPriority > b.second.m_iPriority;

				return a.second.m_sName < b.second.m_sName;
			});
			std::sort(vLabels.begin(), vLabels.end(), [&](const auto& a, const auto& b) -> bool
			{
				// sort by priority if unequal
				if (a.second.m_iPriority != b.second.m_iPriority)
					return a.second.m_iPriority > b.second.m_iPriority;

				return a.second.m_sName < b.second.m_sName;
			});

			// display tags
			int iPriorities = 0, iLabels = 0;
			for (auto& [it, _tTag] : vPriorities)
			{
				fDrawTag(it, _tTag, iPriorities);
				iPriorities++;
			}
			for (auto& [it, _tTag] : vLabels)
			{
				fDrawTag(it, _tTag, iLabels);
				iLabels++;
			}

			// apply a pending deletion now that no iterators into m_vTags are in use
			if (iPendingDelete > -1 && iPendingDelete < F::PlayerUtils.m_vTags.size())
			{
				const int _iID = iPendingDelete;
				F::PlayerUtils.m_vTags.erase(F::PlayerUtils.m_vTags.begin() + _iID);
				F::PlayerUtils.m_bSave = true;

				for (auto& vTags : F::PlayerUtils.m_mPlayerTags | std::views::values)
				{
					for (auto it = vTags.begin(); it != vTags.end();)
					{
						if (_iID == *it)
							it = vTags.erase(it);
						else
						{
							if (_iID < *it)
								(*it)--;
							it++;
						}
					}
				}

				if (iID == _iID)
				{
					iID = -1;
					tTag = {};
				}
				else if (iID > _iID)
					iID--;
			}
			iPendingDelete = -1;
			SetCursorPos({ 0, H::Draw.Scale(72 + 22 * std::max(iPriorities, iLabels)) }); DebugDummy({ 0, H::Draw.Scale(28) });
		} EndSection();
		{
			PushDisabled(F::PlayerUtils.m_bLoad);
			{
				SetCursorPosY(GetCursorPosY() - H::Draw.Scale(8));
				if (FButton(ICON_MD_SYNC, FButtonEnum::None, { 30, 30 }, 0, F::Render.IconFont))
					F::PlayerUtils.m_bLoad = true;

				if (FButton(ICON_MD_FOLDER, FButtonEnum::Fit | FButtonEnum::SameLine, { 30, 30 }, 0, F::Render.IconFont))
					ShellExecuteA(NULL, NULL, F::Configs.m_sCorePath.c_str(), NULL, NULL, SW_SHOWNORMAL);

				if (FButton("Export", FButtonEnum::Fit | FButtonEnum::SameLine))
				{
					// this should be up2date anyways
					std::ifstream fStream(F::Configs.m_sCorePath + "Players.json"); // no append mode, which would create an empty file if missing
					if (fStream.is_open())
					{
						std::string sString;
						{
							std::string line;
							while (std::getline(fStream, line))
								sString += line + "\n";
							if (!sString.empty())
								sString.pop_back();
						}
						fStream.close();

						SDK::SetClipboard(sString);
						SDK::Output("Nikogram", "Copied playerlist to clipboard", INFO_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_INFO);
					}
				}

				{
					static std::vector<PriorityLabel_t> vTags = {};
					static std::unordered_map<uint32_t, std::vector<int>> mPlayerTags = {};
					static std::unordered_map<uint32_t, std::string> mPlayerAliases = {};
					static std::unordered_map<int, int> mAs = {};

					if (FButton("Import", FButtonEnum::Fit | FButtonEnum::SameLine))
					{
						try
						{
							// will not directly support older tag systems
							boost::property_tree::ptree tRead;
							std::stringstream ssStream;
							ssStream << SDK::GetClipboard();
							read_json(ssStream, tRead);

							mPlayerTags.clear();
							mPlayerAliases.clear();
							mAs.clear();
							vTags = {
								{ "Default", { 200, 200, 200, 255 }, 0, false, false, true },
								{ "Ignored", { 200, 200, 200, 255 }, -1, false, true, true },
								{ "Cheater", { 255, 100, 100, 255 }, 1, false, true, true },
								{ "Friend", { 100, 255, 100, 255 }, 0, true, false, true },
								{ "Party", { 100, 100, 255, 255 }, 0, true, false, true },
								{ "F2P", { 255, 255, 255, 255 }, 0, true, false, true }
							};

							if (auto tSub = tRead.get_child_optional("Config"))
							{
								for (auto& [sName, tChild] : *tSub)
								{
									PriorityLabel_t tTag = {};
									F::Configs.LoadJson(tChild, "Name", tTag.m_sName);
									F::Configs.LoadJson(tChild, "Color", tTag.m_tColor);
									F::Configs.LoadJson(tChild, "Priority", tTag.m_iPriority);
									F::Configs.LoadJson(tChild, "Label", tTag.m_bLabel);

									int iID = F::PlayerUtils.TagToIndex(std::stoi(sName));
									if (iID > -1 && iID < vTags.size())
									{
										vTags[iID].m_sName = tTag.m_sName;
										vTags[iID].m_tColor = tTag.m_tColor;
										vTags[iID].m_iPriority = tTag.m_iPriority;
										vTags[iID].m_bLabel = tTag.m_bLabel;
									}
									else
										vTags.push_back(tTag);
								}
							}

							if (auto tSub = tRead.get_child_optional("Tags"))
							{
								for (auto& [sName, tChild] : *tSub)
								{
									uint32_t uAccountID = std::stoul(sName);
									for (auto& tTag : tChild | std::views::values)
									{
										const std::string& sTag = tTag.data();

										int iID = F::PlayerUtils.TagToIndex(std::stoi(sTag));
										if (iID < 0 || iID >= vTags.size() || !vTags[iID].m_bAssignable) // check against the imported tag list
											continue;

										if (!F::PlayerUtils.HasTag(uAccountID, iID, mPlayerTags))
											F::PlayerUtils.AddTag(uAccountID, iID, false, nullptr, mPlayerTags);
									}
								}
							}

							if (auto tSub = tRead.get_child_optional("Aliases"))
							{
								for (auto& [sName, tAlias] : *tSub)
								{
									uint32_t uAccountID = std::stoul(sName);
									const std::string& sAlias = tAlias.data();

									if (!sAlias.empty())
										mPlayerAliases[uAccountID] = sAlias;
								}
							}

							for (int i = 0; i < vTags.size(); i++)
							{
								if (vTags[i].m_bAssignable)
								{
									if (F::PlayerUtils.IndexToTag(i) <= 0)
										mAs[i] = i;
									else
										mAs[i] = -1;
								}
							}
							OpenPopup("ImportPlayerlist");
						}
						catch (...)
						{
							SDK::Output("Nikogram", "Failed to import playerlist", ERROR_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_CANCEL);
						}
					}

					SetNextWindowSize({ H::Draw.Scale(300), 0 });
					if (FBeginPopupModal("ImportPlayerlist"))
					{
						FText("Import");
						FText("As", {}, FTextEnum::Right | FTextEnum::SameLine);

						for (int i = 0; i < vTags.size(); i++)
						{
							if (!vTags[i].m_bAssignable)
								continue;

							auto& iIDTo = mAs[i];

							ImVec2 vOriginalPos = GetCursorPos();
							PushStyleColor(ImGuiCol_Text, ColorByteToInt(vTags[i].m_tColor));
							SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(8), H::Draw.Scale(5)));
							FText(vTags[i].m_sName.c_str());
							PopStyleColor();
							SetCursorPos(vOriginalPos - ImVec2(0, H::Draw.Scale(8))); DebugDummy({ GetWindowWidth() - GetStyle().WindowPadding.x * 2, H::Draw.Scale(32) });

							std::vector<const char*> vEntries = { "None" };
							std::vector<int> vValues = { 0 };
							for (int i = 0; i < F::PlayerUtils.m_vTags.size(); i++)
							{
								if (F::PlayerUtils.m_vTags[i].m_bAssignable)
								{
									vEntries.push_back(F::PlayerUtils.m_vTags[i].m_sName.c_str());
									vValues.push_back(i + 1);
								}
							}
							PushTransparent(iIDTo == -1);
							{
								int iTo = iIDTo + 1;
								FDropdown(std::format("##{}", i).c_str(), &iTo, vEntries, vValues, FDropdownEnum::Right);
								iIDTo = iTo - 1;
							}
							PopTransparent();
						}

						if (FButton("Import", FButtonEnum::Left))
						{
							for (auto& [uAccountID, vTags] : mPlayerTags)
							{
								for (auto& iTag : vTags)
								{
									int iID = mAs.contains(iTag) ? mAs[iTag] : -1;
									if (iID != -1 && !F::PlayerUtils.HasTag(uAccountID, iID))
										F::PlayerUtils.AddTag(uAccountID, iID, false);
								}
							}
							for (auto& [uAccountID, sAlias] : mPlayerAliases)
							{
								if (!F::PlayerUtils.m_mPlayerAliases.contains(uAccountID))
									F::PlayerUtils.m_mPlayerAliases[uAccountID] = sAlias;
							}

							F::PlayerUtils.m_bSave = true;
							SDK::Output("Nikogram", "Imported playerlist", INFO_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_INFO);

							CloseCurrentPopup();
						}
						if (FButton("Cancel", FButtonEnum::Right | FButtonEnum::SameLine))
							CloseCurrentPopup();

						EndPopup();
					}
				}

				if (FButton("Backup", FButtonEnum::Fit | FButtonEnum::SameLine))
				{
					try
					{
						// use the first unused backup name so an existing backup is never overwritten
						int iBackup = 1;
						while (std::filesystem::exists(F::Configs.m_sCorePath + std::format("Backup{}.json", iBackup)))
							iBackup++;
						std::filesystem::copy(
							F::Configs.m_sCorePath + "Players.json",
							F::Configs.m_sCorePath + std::format("Backup{}.json", iBackup)
						);
						SDK::Output("Nikogram", "Saved backup playerlist", INFO_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_INFO);
					}
					catch (...)
					{
						SDK::Output("Nikogram", "Failed to backup playerlist", ERROR_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_CANCEL);
					}
				}
			}
			PopDisabled();
		}
		break;
	}
	// Settings moved to Visuals / Menu & HUD and Misc.
	case 1:
		break;
	// Output
	case 2:
	{
		if (Section("##Output", false, GetWindowHeight() - GetStyle().WindowPadding.y * 2))
		{
			bool bClear = false;

			std::lock_guard tLock(m_tOutputMutex);
			for (auto& tOutput : m_vOutput)
			{
				ImVec2 vOriginalPos = GetCursorPos();
				size_t iLines = 1;

				float flWidth = GetWindowWidth() - GetStyle().WindowPadding.x * 2;
				if (!tOutput.m_sFunction.empty())
				{
					float flTitleWidth = 0.f;

					auto vWrapped = WrapText(tOutput.m_sFunction, flWidth);
					if (!vWrapped.empty())
					{
						PushStyleColor(ImGuiCol_Text, ColorByteToInt(tOutput.tAccent));

						for (auto& sText : vWrapped)
							FText(sText.c_str());
						iLines = vWrapped.size();
						flTitleWidth = FCalcTextSize(vWrapped.back().c_str()).x + H::Draw.Scale(4);

						PopStyleColor();
					}

					vWrapped = WrapText(tOutput.m_sLog, { int(flWidth - flTitleWidth), int(flWidth) });
					if (!vWrapped.empty())
					{
						SameLine(flTitleWidth + GetStyle().WindowPadding.x);
						for (auto& sText : vWrapped)
							FText(sText.c_str());
						iLines += vWrapped.size() - 1;
					}
				}
				else
				{
					PushStyleColor(ImGuiCol_Text, ColorByteToInt(tOutput.tAccent));

					auto vWrapped = WrapText(tOutput.m_sLog, flWidth);
					for (auto& sText : vWrapped)
						FText(sText.c_str());
					iLines = vWrapped.size();

					PopStyleColor();
				}

				SetCursorPos(vOriginalPos); DebugDummy({ flWidth, H::Draw.Scale(13) * iLines + GetStyle().WindowPadding.y });

				if (IsItemHovered() && IsMouseReleased(ImGuiMouseButton_Right))
					OpenPopup(std::format("Output{}", tOutput.m_iID).c_str());
				if (FBeginPopup(std::format("Output{}", tOutput.m_iID).c_str()))
				{
					PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), H::Draw.Scale(8) });

					if (FSelectable("Copy"))
						SDK::SetClipboard(std::format("{}{}{}", tOutput.m_sFunction, tOutput.m_sFunction != "" ? " " : "", tOutput.m_sLog));
					if (FSelectable("Clear"))
						bClear = true;

					PopStyleVar();
					EndPopup();
				}
			}

			if (bClear)
				m_vOutput.clear();
		} EndSection();
		break;
	}
	}
}

void CMenu::MenuSettings(int iTab)
{
	using namespace ImGui;

	switch (iTab)
	{
	// Settings
	case 0:
	{
		if (BeginTable("ConfigSettingsTable", 2))
		{
			/*
			if (Section("Config"))
			{
				static int iCurrentType = 0;
				PushFont(F::Render.FontBold);
				FTabs({ "GENERAL", "VISUAL", }, &iCurrentType, { H::Draw.Scale(20), H::Draw.Scale(28) }, { GetWindowWidth(), 0 }, FTabsEnum::AlignReverse | FTabsEnum::Fit);
				SetCursorPosY(GetCursorPosY() - H::Draw.Scale());
				PopFont();

				switch (iCurrentType)
			*/

			auto fDrawConfigs = [](std::string& sStaticName, bool bVisual = false)
			{
				auto& sPath = !bVisual ? F::Configs.m_sConfigPath : F::Configs.m_sVisualsPath;
				auto& sConfig = !bVisual ? F::Configs.m_sCurrentConfig : F::Configs.m_sCurrentVisuals;
				auto sType = !bVisual ? "Config" : "Visual";
				bool bNoSave = GetAsyncKeyState(VK_SHIFT) & 0x8000;

				FSDropdown("Name", &sStaticName, {}, FSDropdownEnum::AutoUpdate, -H::Draw.Unscale(FCalcTextSize("CREATE").x + H::Draw.Scale(32)) - 36);
				PushDisabled(sStaticName.empty());
				{
					if (FButton("Create", FButtonEnum::Fit | FButtonEnum::SameLine | FButtonEnum::Compact, { 0, 32 }))
					{
						std::error_code tError;
						if (!std::filesystem::exists(sPath + sStaticName + F::Configs.m_sConfigExtension, tError))
						{
							if (!bVisual)
								F::Configs.SaveConfig(sStaticName);
							else
								F::Configs.SaveVisual(sStaticName);
							InvalidateDirectoryCache();
						}
						sStaticName.clear();
					}
				}
				PopDisabled();

				if (FButton(ICON_MD_FOLDER, FButtonEnum::Fit | FButtonEnum::SameLine | FButtonEnum::Compact, { 32, 32 }, 0, F::Render.IconFont))
					ShellExecuteA(NULL, NULL, sPath.c_str(), NULL, NULL, SW_SHOWNORMAL);

				pRowSizes->clear();

				std::vector<std::pair<std::filesystem::directory_entry, std::string>> vConfigs = {};
				bool bDefaultFound = false, bRefreshed = false;
				for (auto& tEntry : GetDirectoryEntries(sPath, &bRefreshed))
				{
					std::error_code tError;
					if (!tEntry.is_regular_file(tError) || tEntry.path().extension() != F::Configs.m_sConfigExtension)
						continue;

					std::string sName;
					try { sName = tEntry.path().filename().string(); }
					catch (...) { continue; } // name not representable in the narrow encoding
					sName.erase(sName.end() - F::Configs.m_sConfigExtension.size(), sName.end());
					if (FNV1A::Hash32(sName.c_str()) == FNV1A::Hash32Const("default"))
						bDefaultFound = true;

					vConfigs.emplace_back(tEntry, sName);
				}
				if (!bVisual)
				{
					if (!bDefaultFound && bRefreshed) // only when a fresh listing shows it missing, not every frame
					{
						if (F::Configs.EnsureDefaultConfig())
							InvalidateDirectoryCache();
					}
					std::sort(vConfigs.begin(), vConfigs.end(), [&](const auto& a, const auto& b) -> bool
					{
						// override for default config (keep the comparator irreflexive)
						bool bDefaultA = FNV1A::Hash32(a.second.c_str()) == FNV1A::Hash32Const("default"), bDefaultB = FNV1A::Hash32(b.second.c_str()) == FNV1A::Hash32Const("default");
						if (bDefaultA != bDefaultB)
							return bDefaultA;

						return a.second < b.second;
					});
				}

				DebugDummy({ 0, H::Draw.Scale(6) });
				for (auto& [entry, sConfigName] : vConfigs)
				{
					bool bCurrentConfig = FNV1A::Hash32(sConfigName.c_str()) == FNV1A::Hash32(sConfig.c_str());
					ImVec2 vOriginalPos = GetCursorPos();

					SetCursorPos(vOriginalPos + ImVec2(H::Draw.Scale(2), H::Draw.Scale(1)));
					bool bLoad = CompactManagerIcon(bCurrentConfig ? ICON_MD_REFRESH : ICON_MD_DOWNLOAD);
					FTooltip(ICON_MD_ADD ICON_MD_FILE_UPLOAD_OFF, bNoSave && IsItemHovered(), 300.f, F::Render.IconFont);

					SetCursorPos({ H::Draw.Scale(43), vOriginalPos.y + H::Draw.Scale(4) });
					TextColored(bCurrentConfig ? F::Render.Active.Value : F::Render.Inactive.Value, TruncateText(sConfigName, GetWindowWidth() - GetStyle().WindowPadding.x * 2 - H::Draw.Scale(80)).c_str());

					int iOffset = 9;
					SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), vOriginalPos.y + H::Draw.Scale(1) });
					bool bDelete = CompactManagerIcon(ICON_MD_DELETE);

					SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), vOriginalPos.y + H::Draw.Scale(1) });
					bool bSave = CompactManagerIcon(ICON_MD_SAVE);
					FTooltip(ICON_MD_ADD ICON_MD_FILE_DOWNLOAD_OFF, bNoSave && IsItemHovered(), 300.f, F::Render.IconFont);

					if (bLoad)
					{
						if (!bVisual)
							F::Configs.LoadConfig(sConfigName);
						else
							F::Configs.LoadVisual(sConfigName);
					}
					else if (bSave)
					{
						if (!bCurrentConfig || !bVisual && !F::Configs.m_sCurrentVisuals.empty())
							OpenPopup(std::format("Save{}{}", sType, sConfigName).c_str());
						else if (!bVisual)
							F::Configs.SaveConfig(sConfigName);
						else
							F::Configs.SaveVisual(sConfigName);
					}
					else if (bDelete)
						OpenPopup(std::format("Remove{}{}", sType, sConfigName).c_str());

					if (FBeginPopupModal(std::format("Save{}{}", sType, sConfigName).c_str()))
					{
						FText(std::format("Do you really want to override '{}'?", sConfigName).c_str());

						if (FButton("Yes, override", FButtonEnum::Left))
						{
							if (!bVisual)
								F::Configs.SaveConfig(sConfigName);
							else
								F::Configs.SaveVisual(sConfigName);
							CloseCurrentPopup();
						}
						if (FButton("No", FButtonEnum::Right | FButtonEnum::SameLine))
							CloseCurrentPopup();

						EndPopup();
					}
					else if (FBeginPopupModal(std::format("Remove{}{}", sType, sConfigName).c_str()))
					{
						FText(std::format("Do you really want to remove '{}'?", sConfigName).c_str());

						PushDisabled(!bVisual && FNV1A::Hash32(sConfigName.c_str()) == FNV1A::Hash32Const("default"));
						{
							if (FButton("Yes, delete", FButtonEnum::Fit))
							{
								if (!bVisual)
									F::Configs.DeleteConfig(sConfigName);
								else
									F::Configs.DeleteVisual(sConfigName);
								InvalidateDirectoryCache();
								CloseCurrentPopup();
							}
						}
						PopDisabled();
						if (FButton("Yes, reset", FButtonEnum::Fit | FButtonEnum::SameLine))
						{
							if (!bVisual)
								F::Configs.ResetConfig(sConfigName);
							else
								F::Configs.ResetVisual(sConfigName);
							CloseCurrentPopup();
						}
						if (FButton("No", FButtonEnum::Fit | FButtonEnum::SameLine))
							CloseCurrentPopup();

						EndPopup();
					}

					SetCursorPos(vOriginalPos); DebugDummy({ 0, H::Draw.Scale(22) });
				}
				DebugDummy({ 0, H::Draw.Scale(7) });
			};

			/* Column 1 */
			TableNextColumn();
			if (Section("Config"))
			{
				static std::string sStaticName;

				fDrawConfigs(sStaticName);
			} EndSection();
			PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
			SetCursorPosX(GetCursorPosX() + GetStyle().WindowPadding.x);
			FText("Built @ " __DATE__ ", " __TIME__ ", " __CONFIGURATION__);
			//SetCursorPosX(GetCursorPosX() + GetStyle().WindowPadding.x);
			//FText(std::format("Time @ {}, {}", SDK::GetDate(), SDK::GetTime()).c_str());
			PopStyleColor();

			/* Column 2 */
			TableNextColumn();
			if (Section("Visuals"))
			{
				static std::string sStaticName;

				fDrawConfigs(sStaticName, true);
			} EndSection();

			EndTable();
		}
		break;
	}
	// Binds
	case 1:
	{
		const bool moonlit = MenuMode::DrawingMoonlit;
		const float bindIconSize = moonlit ? 26.f : 20.f;
		const float bindIconStep = moonlit ? 34.f : 25.f;
		const float bindActionWidth = 5 * bindIconStep + 2;
		const float bindRowHeight = moonlit ? BindLayout::MoonlitRowHeight(GetTextLineHeight(), H::Draw.Scale()) : H::Draw.Scale(22);
		if (Section("Settings"))
		{
			if (moonlit)
			{
				FToggle(Vars::Menu::BindWindow, FToggleEnum::Left);
				FToggle(Vars::Menu::BindWindowTitle, FToggleEnum::Right);
				FToggle(Vars::Menu::MenuShowsBinds);
			}
			else
			{
			auto vTable = WidgetTable(3, H::Draw.Scale(22));

			if (BeginWidgetTable(0, vTable))
			{
				DebugDummy({ 0, H::Draw.Scale(6) });
				FToggle(Vars::Menu::BindWindow);
			} EndChild();

			if (BeginWidgetTable(1, vTable))
			{
				DebugDummy({ 0, H::Draw.Scale(6) });
				FToggle(Vars::Menu::BindWindowTitle);
			} EndChild();

			if (BeginWidgetTable(2, vTable))
			{
				DebugDummy({ 0, H::Draw.Scale(6) });
				FToggle(Vars::Menu::MenuShowsBinds);
			} EndChild();
			}
			FToggle(Vars::Menu::BindWindowHorizontal);
			FToggle(Vars::Menu::BindTextGlow);
			FToggle(Vars::Menu::BindTextGlowCustom);
			if (FGet(Vars::Menu::BindTextGlowCustom))
				FColorPicker(Vars::Menu::BindTextGlowColour);
			else FText("Glow colour: lighter accent");
		} EndSection();
		if (Section("Binds"))
		{
			int& iBind = s_iEditBind;
			Bind_t& tBind = s_tEditBind;
			int iPendingRemove = DEFAULT_BIND; // bind removal is deferred until the bind list is no longer being iterated

			static int bParent = false;
			if (bParent)
				SetMouseCursor(ImGuiMouseCursor_Hand);

			// Two dropdown rows plus their measured padding, independent of text scale.
			const float editorHeight = moonlit ? BindLayout::MoonlitEditorHeight(CompactDropdownHeight(true), GetStyle().ItemSpacing.y, GetStyle().WindowPadding.y, H::Draw.Scale()) : H::Draw.Scale(80);
			const float actionHeight = moonlit ? CompactDropdownHeight(true) / H::Draw.Scale() : 32.f;
			auto vTable = WidgetTable(2, editorHeight, {}, ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse, moonlit);

			if (BeginWidgetTable(0, vTable, moonlit))
			{
				FSDropdown("Name", &tBind.m_sName, {}, FDropdownEnum::Left | FSDropdownEnum::AutoUpdate);
				{
					auto sParent = bParent ? "..." : tBind.m_iParent != DEFAULT_BIND && tBind.m_iParent < F::Binds.m_vBinds.size() ? F::Binds.m_vBinds[tBind.m_iParent].m_sName : "None";
					if (FButton(std::format("Parent: {}", sParent).c_str(), FButtonEnum::Right | FButtonEnum::SameLine | FButtonEnum::NoUpper | FButtonEnum::Compact, { 0, actionHeight }))
						bParent = 2;
				}
				FDropdown("Type", &tBind.m_iType, { "Key", "Class", "Weapon type", "Item slot", "Misc", "Is behind", "On threat" }, {}, FDropdownEnum::Left);
				switch (tBind.m_iType)
				{
				case BindEnum::Key: FDropdown("Behavior", &tBind.m_iInfo, { "Hold", "Toggle", "Double click" }, {}, FDropdownEnum::Right); break;
				case BindEnum::Class: FDropdown("Class", &tBind.m_iInfo, { "Scout", "Soldier", "Pyro", "Demoman", "Heavy", "Engineer", "Medic", "Sniper", "Spy" }, {}, FDropdownEnum::Right); break;
				case BindEnum::WeaponType: FDropdown("Weapon type", &tBind.m_iInfo, { "Hitscan", "Projectile", "Melee", "Throwable" }, {}, FDropdownEnum::Right); break;
				case BindEnum::ItemSlot: FDropdown("Item slot", &tBind.m_iInfo, { "1", "2", "3", "4", "5", "6", "7", "8", "9" }, {}, FDropdownEnum::Right); break;
				case BindEnum::Misc: FDropdown("Misc", &tBind.m_iInfo, { "Spectated", "Spectated 1st", "Spectated 3rd", "##Divider", "Zoomed", "Aiming" }, {}, FDropdownEnum::Right); break;
				case BindEnum::Behind: FText("Enemies only", {}, FTextEnum::Right | FTextEnum::SameLine); break;
				case BindEnum::Threat: FText("Lethal attack", {}, FTextEnum::Right | FTextEnum::SameLine); break;
				}
			} EndChild();

			if (BeginWidgetTable(1, vTable, moonlit))
			{
				int iNot = tBind.m_bNot;
				FDropdown("While", &iNot, { "Active", "Not active" }, {}, FDropdownEnum::Left);
				tBind.m_bNot = iNot;
				FDropdown("Visibility", &tBind.m_iVisibility, { "Always", "While active", "Hidden" }, {}, FDropdownEnum::Right);
				const float actionY = GetCursorPosY();
				if (tBind.m_iType == 0)
					FKeybind("Key", tBind.m_iKey, FButtonEnum::Compact, { Vars::Menu::PrimaryKey[DEFAULT_BIND], Vars::Menu::SecondaryKey[DEFAULT_BIND] }, { 0, actionHeight }, -80);

				// create/modify button
				bool bCreate = false, bClear = false, bParent = true;
				if (tBind.m_iParent != DEFAULT_BIND)
					bParent = F::Binds.m_vBinds.size() > tBind.m_iParent;

				SetCursorPos({ GetWindowWidth() - H::Draw.Scale(80) - (moonlit ? GetStyle().WindowPadding.x : 0.f), actionY });
				PushDisabled(!bParent || !(tBind.m_iType == BindEnum::Key ? tBind.m_iKey : true));
				{
					bool bMatch = iBind != DEFAULT_BIND && F::Binds.m_vBinds.size() > iBind;
					bCreate = FButton(bMatch ? ICON_MD_SETTINGS : ICON_MD_ADD, FButtonEnum::Compact, { 32, actionHeight }, 0, F::Render.IconFont);
				}
				PopDisabled();

				// clear button
				SetCursorPos({ GetWindowWidth() - H::Draw.Scale(40) - (moonlit ? GetStyle().WindowPadding.x : 0.f), actionY });
				bClear = FButton(ICON_MD_CLEAR, FButtonEnum::Compact, { 32, actionHeight }, 0, F::Render.IconFont);

				if (bCreate)
					F::Binds.AddBind(iBind, tBind);
				if (bCreate || bClear)
				{
					iBind = DEFAULT_BIND;
					tBind = {};
				}
			} EndChild();

			DrawConditionOptions(tBind);
			PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
			SetCursorPos({ H::Draw.Scale(13), GetCursorPosY() + H::Draw.Scale(4) });
			FText("Binds");
			DebugDummy({ 0, H::Draw.Scale(4) });
			PopStyleColor();

			auto fNumberToIndex = [](int iNumber, int iLayer)
			{
				int iIndex = -1, i = -1;

				std::unordered_mapset<int> mBinds = {};
				std::function<void(int)> fGetBinds = [&](int iParent)
				{
					for (int _iBind = 0; _iBind < F::Binds.m_vBinds.size(); _iBind++)
					{
						auto& _tBind = F::Binds.m_vBinds[_iBind];
						if (iParent != _tBind.m_iParent || mBinds.contains(_iBind))
							continue;

						mBinds[_iBind];

						i++;
						//if (iParent == iLayer && iNumber >= i)
						if (iIndex == -1 && iParent == iLayer && iNumber <= i)
							iIndex = _iBind;
						fGetBinds(_iBind);
					}
				};
				fGetBinds(DEFAULT_BIND);

				return iIndex;
			};
			auto fPositionToIndex = [&](ImVec2 vPos, int iLayer = DEFAULT_BIND)
			{
				int iIndex = floorf((vPos.y - GetCursorPosY() - H::Draw.Scale(2)) / (bindRowHeight + H::Draw.Scale(2) + GetStyle().ItemSpacing.y));
				iIndex = std::clamp(iIndex, 0, int(F::Binds.m_vBinds.size() - 1));
				iIndex = fNumberToIndex(iIndex, iLayer);
				return iIndex;
			};

			static int iDragging = -1, iLayer = DEFAULT_BIND;
			if (!IsMouseDown(ImGuiMouseButton_Left))
				iDragging = -1;
			else if (iDragging != -1)
			{
				int iTo = fPositionToIndex(GetMousePos() - GetDrawPos(), iLayer);
				if (iTo != -1 && iDragging != iTo)
				{
					F::Binds.Move(iDragging, iTo);
					if (iBind == iDragging)
						iBind = iTo;
					else if (iBind < iDragging && iBind >= iTo)
						iBind++;
					else if (iBind > iDragging && iBind <= iTo)
						iBind--;
					iDragging = iTo;
				}
			}

			std::unordered_mapset<int> mBinds = {};
			std::function<void(int, int)> fGetBinds = [&](int iParent, int x)
			{
				for (int _iBind = 0; _iBind < F::Binds.m_vBinds.size(); _iBind++)
				{
					auto& _tBind = F::Binds.m_vBinds[_iBind];
					if (iParent != DEFAULT_BIND - 1 && iParent != _tBind.m_iParent || mBinds.contains(_iBind))
						continue;

					mBinds[_iBind];

					std::string sType; std::string sInfo;
					switch (_tBind.m_iType)
					{
					case BindEnum::Key:
						switch (_tBind.m_iInfo)
						{
						case BindEnum::KeyEnum::Hold: { sType = "hold"; break; }
						case BindEnum::KeyEnum::Toggle: { sType = "toggle"; break; }
						case BindEnum::KeyEnum::DoubleClick: { sType = "double"; break; }
						}
						sInfo = U::KeyHandler.String(_tBind.m_iKey);
						break;
					case BindEnum::Class:
						sType = "class";
						switch (_tBind.m_iInfo)
						{
						case BindEnum::ClassEnum::Scout: { sInfo = "scout"; break; }
						case BindEnum::ClassEnum::Soldier: { sInfo = "soldier"; break; }
						case BindEnum::ClassEnum::Pyro: { sInfo = "pyro"; break; }
						case BindEnum::ClassEnum::Demoman: { sInfo = "demoman"; break; }
						case BindEnum::ClassEnum::Heavy: { sInfo = "heavy"; break; }
						case BindEnum::ClassEnum::Engineer: { sInfo = "engineer"; break; }
						case BindEnum::ClassEnum::Medic: { sInfo = "medic"; break; }
						case BindEnum::ClassEnum::Sniper: { sInfo = "sniper"; break; }
						case BindEnum::ClassEnum::Spy: { sInfo = "spy"; break; }
						}
						break;
					case BindEnum::WeaponType:
						sType = "weapon";
						switch (_tBind.m_iInfo)
						{
						case BindEnum::WeaponTypeEnum::Hitscan: { sInfo = "hitscan"; break; }
						case BindEnum::WeaponTypeEnum::Projectile: { sInfo = "projectile"; break; }
						case BindEnum::WeaponTypeEnum::Melee: { sInfo = "melee"; break; }
						case BindEnum::WeaponTypeEnum::Throwable: { sInfo = "throwable"; break; }
						}
						break;
					case BindEnum::ItemSlot:
						sType = "slot";
						sInfo = std::format("{}", _tBind.m_iInfo + 1);
						break;
					case BindEnum::Behind:
						sType = "behind"; sInfo = ConditionPolicy::ClassName(_tBind.m_tConditions.enemyClass); break;
					case BindEnum::Threat:
						sType = "threat"; sInfo = std::format("{:.2f}s", _tBind.m_tConditions.projectileWindow); break;
					case BindEnum::Misc:
						switch (_tBind.m_iInfo)
						{
						case BindEnum::MiscEnum::Spectated:
						case BindEnum::MiscEnum::SpectatedFirst:
						case BindEnum::MiscEnum::SpectatedThird:
							sType = "spectated";
							switch (_tBind.m_iInfo)
							{
							case BindEnum::MiscEnum::Spectated: { sInfo = "any"; break; }
							case BindEnum::MiscEnum::SpectatedFirst: { sInfo = "1st"; break; }
							case BindEnum::MiscEnum::SpectatedThird: { sInfo = "3rd"; break; }
							}
							break;
						case BindEnum::MiscEnum::Zoomed:
						case BindEnum::MiscEnum::Aiming:
							sType = "cond";
							switch (_tBind.m_iInfo)
							{
							case BindEnum::MiscEnum::Zoomed: { sInfo = "zoomed"; break; }
							case BindEnum::MiscEnum::Aiming: { sInfo = "aiming"; break; }
							}
							break;
						}
						break;
					}
					if (_tBind.m_bNot && (_tBind.m_iType != BindEnum::Key || _tBind.m_iInfo == BindEnum::KeyEnum::Hold))
						sType = std::format("not {}", sType);

					ImVec2 vOriginalPos = { (moonlit ? GetStyle().WindowPadding.x : H::Draw.Scale(8)) + H::Draw.Scale(28) * std::min(x, 3), GetCursorPosY() + H::Draw.Scale(2) };

					// background
					float flWidth = GetWindowWidth() - GetStyle().WindowPadding.x * 2 - H::Draw.Scale(28) * std::min(x, 3);
					float flHeight = bindRowHeight;
					const float textY = moonlit ? (flHeight - GetTextLineHeight()) * .5f : H::Draw.Scale(4);
					const float iconY = moonlit ? (flHeight - H::Draw.Scale(bindIconSize)) * .5f : H::Draw.Scale(2);
					ImVec2 vDrawPos = GetDrawPos() + vOriginalPos;
					// Use the player list's neutral row tint, independent of the black panel fill.
					Color_t rowColor = Color_t(127, 127, 127, 255).Lerp(Vars::Menu::Theme::Background.Value, 0.5f, LerpEnum::NoAlpha);
					if (moonlit) rowColor = ColorFloatToByte(F::Render.Background1p5L);
					if (iBind == _iBind)
						rowColor = rowColor.Lerp(ColorFloatToByte(F::Render.Accent), 0.2f, LerpEnum::NoAlpha);
					GetWindowDrawList()->AddRectFilled(vDrawPos, vDrawPos + ImVec2(flWidth, flHeight), ColorByteToFloat(rowColor), moonlit ? H::Draw.Scale(6) : 0.f);
					if (iBind == _iBind)
					{
						float flInset = H::Draw.Scale(0.5f) - 0.5f;
						GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(flWidth - flInset, flHeight - flInset), F::Render.Accent, 0.f, ImDrawFlags_None, H::Draw.Scale());
					}

					// text
					if (x > 3)
					{	// don't indent too much
						auto sText = std::format("-> {}", x);
						SetCursorPos(vOriginalPos + ImVec2(-FCalcTextSize(sText.c_str()).x - H::Draw.Scale(10), H::Draw.Scale(4)));
						PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
						FText(sText.c_str());
						PopStyleColor();
					}

					float flTextWidth = flWidth - H::Draw.Scale(bindActionWidth);
					PushTransparent(!F::Binds.WillBeEnabled(_iBind), true);

					// Match the list heading's left edge; retain parent/child indentation.
					SetCursorPos({ vOriginalPos.x + H::Draw.Scale(5), vOriginalPos.y + textY });
					const auto displayed=BindPresentation::Get(_tBind,_iBind,BindPresentation::ParentsActive(_tBind,F::Binds.m_vBinds),MenuMode::Active==MenuMode::Moonlit);
					PushStyleColor(ImGuiCol_Text, displayed.active ? F::Render.Accent.Value : F::Render.Active.Value);
					FText(TruncateText(_tBind.m_sName, flTextWidth * (1.f / 3) - H::Draw.Scale(20)).c_str());
					if(IsItemHovered())SetTooltip("%s: %s\nBind condition: %s",displayed.feature?"Feature":"Condition",displayed.active?"active":"inactive",_tBind.m_bActive?"matched":"not matched");
					PopStyleColor();

					SetCursorPos(vOriginalPos + ImVec2(flTextWidth * (1.f / 3), textY));
					FText(sType.c_str());

					SetCursorPos(vOriginalPos + ImVec2(flTextWidth * (2.f / 3), textY));
					FText(sInfo.c_str());

					// buttons
					float iOffset = 1;

					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(iOffset += bindIconStep), iconY));
					bool bDelete = CompactManagerIcon(ICON_MD_DELETE, bindIconSize);

					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(iOffset += bindIconStep), iconY));
					if (CompactManagerIcon(ICON_MD_EDIT, bindIconSize))
						CurrentBind = CurrentBind != _iBind ? _iBind : DEFAULT_BIND;

					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(iOffset += bindIconStep), iconY));
					if (CompactManagerIcon(!_tBind.m_bNot ? ICON_MD_CODE : ICON_MD_CODE_OFF, bindIconSize))
						_tBind.m_bNot = !_tBind.m_bNot;

					PushTransparent(Transparent || _tBind.m_iVisibility == BindVisibilityEnum::Hidden, true);
					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(iOffset += bindIconStep), iconY));
					if (CompactManagerIcon(_tBind.m_iVisibility == BindVisibilityEnum::Always ? ICON_MD_VISIBILITY : ICON_MD_VISIBILITY_OFF, bindIconSize))
						_tBind.m_iVisibility = (_tBind.m_iVisibility + 1) % 3;
					PopTransparent(1, 1);

					SetCursorPos(vOriginalPos + ImVec2(flWidth - H::Draw.Scale(iOffset += bindIconStep), iconY));
					if (CompactManagerIcon(_tBind.m_bEnabled ? ICON_MD_TOGGLE_ON : ICON_MD_TOGGLE_OFF, bindIconSize))
						_tBind.m_bEnabled = !_tBind.m_bEnabled;

					SetCursorPos(vOriginalPos);
					bool bClicked = InvisibleButton(std::format("##{}", _iBind).c_str(), { flWidth - H::Draw.Scale(bindActionWidth), flHeight });
					bool bPopup = IsItemClicked(ImGuiMouseButton_Right);

					PopTransparent(1, 1);

					if (bClicked)
					{
						if (!bParent)
						{
							iBind = _iBind;
							tBind = _tBind;
						}
						else
						{
							bParent = false;
							tBind.m_iParent = _iBind;

							// make sure bind can't be parented to itself or any of its children
							int _iBind2 = _iBind;
							Bind_t _tBind2;
							while (F::Binds.GetBind(_iBind2, &_tBind2))
							{
								if (_iBind2 == iBind)
									tBind.m_iParent = DEFAULT_BIND;
								_iBind2 = _tBind2.m_iParent;
							}
						}
					}
					else if (bPopup)
						OpenPopup(std::format("RightClicked{}", _iBind).c_str());
					else if (iDragging == -1 && IsItemHovered() && IsMouseDown(ImGuiMouseButton_Left))
						iDragging = _iBind, iLayer = iParent;
					else if (bDelete)
					{
						if (_tBind.m_vVars.size() <= 1 && !F::Binds.HasChildren(_iBind) || U::KeyHandler.Down(VK_SHIFT)) // allow user to quickly remove binds
							iPendingRemove = _iBind;
						else
							OpenPopup(std::format("DeleteBind{}", _iBind).c_str());
					}

					if (FBeginPopup(std::format("RightClicked{}", _iBind).c_str()))
					{
						PushStyleVar(ImGuiStyleVar_ItemSpacing, { H::Draw.Scale(8), 0 });

						{
							static std::string sInput = "";

							bool bEnter = FInputText("Name...", sInput, H::Draw.Scale(284), ImGuiInputTextFlags_EnterReturnsTrue);
							if (!IsItemFocused())
								sInput = _tBind.m_sName;
							if (bEnter)
								_tBind.m_sName = sInput;
						}

						FDropdown("Type", &_tBind.m_iType, { "Key", "Class", "Weapon type", "Item slot", "Misc", "Is behind", "On threat" }, {}, FDropdownEnum::Left);
						switch (_tBind.m_iType)
						{
						case BindEnum::Key: FDropdown("Behavior", &_tBind.m_iInfo, { "Hold", "Toggle", "Double click" }, {}, FDropdownEnum::Right); break;
						case BindEnum::Class: FDropdown("Class", &_tBind.m_iInfo, { "Scout", "Soldier", "Pyro", "Demoman", "Heavy", "Engineer", "Medic", "Sniper", "Spy" }, {}, FDropdownEnum::Right); break;
						case BindEnum::WeaponType: FDropdown("Weapon type", &_tBind.m_iInfo, { "Hitscan", "Projectile", "Melee", "Throwable" }, {}, FDropdownEnum::Right); break;
						case BindEnum::ItemSlot: FDropdown("Item slot", &_tBind.m_iInfo, { "1", "2", "3", "4", "5", "6", "7", "8", "9" }, {}, FDropdownEnum::Right); break;
						case BindEnum::Misc: FDropdown("Misc", &_tBind.m_iInfo, { "Spectated", "Spectated 1st", "Spectated 3rd", "##Divider", "Zoomed", "Aiming" }, {}, FDropdownEnum::Right); break;
						case BindEnum::Behind: FText("Enemies only", {}, FTextEnum::Right | FTextEnum::SameLine); break;
						case BindEnum::Threat: FText("Lethal attack", {}, FTextEnum::Right | FTextEnum::SameLine); break;
						}
						if (_tBind.m_iType == BindEnum::Key)
							FKeybind("Key", _tBind.m_iKey);
						DrawConditionOptions(_tBind);

						PopStyleVar();
						EndPopup();
					}
					else if (FBeginPopupModal(std::format("DeleteBind{}", _iBind).c_str()))
					{
						FText(std::format("Do you really want to delete '{}'{}?", _tBind.m_sName, F::Binds.HasChildren(_iBind) ? " and all of its children" : "").c_str());

						if (FButton("Yes", FButtonEnum::Left))
						{
							iPendingRemove = _iBind;
							CloseCurrentPopup();
						}
						if (FButton("No", FButtonEnum::Right | FButtonEnum::SameLine))
							CloseCurrentPopup();

						EndPopup();
					}

					if (iParent != DEFAULT_BIND - 1)
						fGetBinds(_iBind, x + 1);
				}
			};
			fGetBinds(DEFAULT_BIND, 0);

			// this should ideally never happen, but failsafe
			if (F::Binds.m_vBinds.size() > mBinds.size())
			{
				PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
				SetCursorPos({ H::Draw.Scale(13), GetCursorPosY() + H::Draw.Scale(5) });
				FText("Dangling");
				DebugDummy({ 0, H::Draw.Scale(4) });
				PopStyleColor();

				fGetBinds(DEFAULT_BIND - 1, 0);
			}

			// apply a pending removal now that no references into the bind list are in use
			if (iPendingRemove != DEFAULT_BIND)
			{
				RemoveBindAndRemap(iPendingRemove);
				iDragging = -1;
			}

			if (bParent == 2) // dumb
				bParent = 1;
			else if (bParent && IsMouseReleased(ImGuiMouseButton_Left))
			{
				bParent = false;
				tBind.m_iParent = DEFAULT_BIND;
			}
		} EndSection();
		break;
	}
	// Materials
	case 2:
	{
		static TextEditor tTextEditor;
		static std::string sCurrentMaterial;
		static bool bLockedMaterial;

		bool bTable = false;
		if (!sCurrentMaterial.empty())
			bTable = BeginTable("MaterialsTable", 2);
		{
			if (bTable)
			{
				TableSetupColumn("MaterialsTable1", ImGuiTableColumnFlags_WidthFixed, H::Draw.Scale(288));
				TableSetupColumn("MaterialsTable2", ImGuiTableColumnFlags_WidthFixed, GetWindowWidth());

				/* Column 1 */
				TableNextColumn();
			}

			if (Section("Manager"))
			{
				static std::string sStaticName;

				FSDropdown("Name", &sStaticName, {}, FSDropdownEnum::AutoUpdate, -H::Draw.Unscale(FCalcTextSize("CREATE").x + H::Draw.Scale(32)) - 36);
				PushDisabled(sStaticName.empty());
				{
					if (FButton("Create", FButtonEnum::Fit | FButtonEnum::SameLine | FButtonEnum::Compact, { 0, 32 }))
					{
						F::Materials.AddMaterial(sStaticName.c_str());
						sStaticName.clear();
					}
				}
				PopDisabled();

				if (FButton(ICON_MD_FOLDER, FButtonEnum::Fit | FButtonEnum::SameLine | FButtonEnum::Compact, { 32, 32 }, 0, F::Render.IconFont))
					ShellExecuteA(NULL, NULL, F::Configs.m_sMaterialsPath.c_str(), NULL, NULL, SW_SHOWNORMAL);

				// only copy what is displayed (not the whole material and its vmt); still a copy since materials can be removed while iterating
				struct MaterialEntry_t
				{
					std::string m_sName;
					bool m_bLocked;
				};
				std::vector<MaterialEntry_t> vMaterials;
				vMaterials.reserve(F::Materials.m_mMaterials.size());
				for (auto& tMaterial : F::Materials.m_mMaterials | std::views::values)
					vMaterials.push_back({ tMaterial.m_sName, tMaterial.m_bLocked });

				std::sort(vMaterials.begin(), vMaterials.end(), [&](const auto& a, const auto& b) -> bool
				{
					// override for none material (keep the comparator irreflexive)
					bool bNoneA = FNV1A::Hash32(a.m_sName.c_str()) == FNV1A::Hash32Const("None"), bNoneB = FNV1A::Hash32(b.m_sName.c_str()) == FNV1A::Hash32Const("None");
					if (bNoneA != bNoneB)
						return bNoneA;

					// keep locked materials higher
					if (a.m_bLocked && !b.m_bLocked)
						return true;
					if (!a.m_bLocked && b.m_bLocked)
						return false;

					return a.m_sName < b.m_sName;
				});

				DebugDummy({ 0, H::Draw.Scale(6) });
				for (auto& tMaterial : vMaterials)
				{
					ImVec2 vOriginalPos = GetCursorPos();

					SetCursorPos({ H::Draw.Scale(17), vOriginalPos.y + H::Draw.Scale(4) });
					TextColored(tMaterial.m_bLocked ? F::Render.Inactive.Value : F::Render.Active.Value, TruncateText(tMaterial.m_sName, GetWindowWidth() - GetStyle().WindowPadding.x * 2 - H::Draw.Scale(56)).c_str());

					int iOffset = 9;
					if (!tMaterial.m_bLocked)
					{
						SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), vOriginalPos.y + H::Draw.Scale(1) });
						if (CompactManagerIcon(ICON_MD_DELETE))
							OpenPopup(std::format("DeleteMat{}", tMaterial.m_sName).c_str());
						if (FBeginPopupModal(std::format("DeleteMat{}", tMaterial.m_sName).c_str()))
						{
							FText(std::format("Do you really want to delete '{}'?", tMaterial.m_sName).c_str());

							if (FButton("Yes", FButtonEnum::Left))
							{
								F::Materials.RemoveMaterial(tMaterial.m_sName.c_str());
								CloseCurrentPopup();
							}
							if (FButton("No", FButtonEnum::Right | FButtonEnum::SameLine))
								CloseCurrentPopup();

							EndPopup();
						}
					}

					SetCursorPos({ GetWindowWidth() - H::Draw.Scale(iOffset += 25), vOriginalPos.y + H::Draw.Scale(1) });
					if (CompactManagerIcon(ICON_MD_EDIT))
					{
						sCurrentMaterial = tMaterial.m_sName;
						bLockedMaterial = tMaterial.m_bLocked;

						tTextEditor.SetText(F::Materials.GetVMT(FNV1A::Hash32(sCurrentMaterial.c_str())));
						tTextEditor.SetReadOnlyEnabled(bLockedMaterial);
					}

					SetCursorPos(vOriginalPos); DebugDummy({ 0, H::Draw.Scale(22) });
				}
				DebugDummy({ 0, H::Draw.Scale(7) });
			}
			else
				SetScrollY(0);
			EndSection();

			if (bTable)
			{
				/* Column 2 */
				TableNextColumn();
				if (sCurrentMaterial.length())
				{
					SetCursorPosY(GetScrollY() + GetStyle().WindowPadding.y);
					if (Section("Editor", 0, GetWindowHeight() - GetStyle().WindowPadding.y * 2, true))
					{
						// Toolbar
						if (!bLockedMaterial)
						{
							if (FButton("Save", FButtonEnum::Fit))
							{
								auto sText = tTextEditor.GetText();
								F::Materials.EditMaterial(sCurrentMaterial.c_str(), sText.c_str());
							}
							SameLine();
						}
						if (FButton("Close", FButtonEnum::Fit))
							sCurrentMaterial = "";
						SetCursorPosY(H::Draw.Scale(52));
						PushStyleColor(ImGuiCol_Text, F::Render.Inactive.Value);
						FText(std::format("{}: {}", bLockedMaterial ? "Viewing" : "Editing", sCurrentMaterial).c_str(), {}, FTextEnum::Right);
						PopStyleColor();

						// Text editor
						DebugDummy({ 0, H::Draw.Scale(8) });

						if (static bool bLanguageSet = false; !bLanguageSet) // setting the language can recolorize the whole text, so only do it once
						{
							tTextEditor.SetLanguage(TextEditor::Language::Cpp());
							bLanguageSet = true;
						}
						TextEditor::Palette tPalette = {{
							F::Render.Active,				// text
							F::Render.Active,				// keyword
							F::Render.Active,				// declaration
							F::Render.Active,				// number
							F::Render.Accent,				// string
							F::Render.Inactive,				// punctuation
							F::Render.Inactive,				// preprocessor
							F::Render.Inactive,				// identifier
							F::Render.Inactive,				// known identifier
							F::Render.Inactive,				// comment
							F::Render.Background1,			// background
							F::Render.Active,				// cursor
							ImColor(F::Render.Inactive.Value.x, F::Render.Inactive.Value.y, F::Render.Inactive.Value.z, 0.5f),	// selection
							ImColor(F::Render.Inactive.Value.x, F::Render.Inactive.Value.y, F::Render.Inactive.Value.z, 0.1f),	// whitespace
							IM_COL32( 70,  70,  70, 255),	// matchingBracketBackground
							IM_COL32(140, 140, 140, 255),	// matchingBracketActive
							IM_COL32(246, 222,  36, 255),	// matchingBracketLevel1
							IM_COL32( 66, 120, 198, 255),	// matchingBracketLevel2
							IM_COL32(213,  96, 213, 255),	// matchingBracketLevel3
							IM_COL32(198,   8,  32, 255),	// matchingBracketError
							F::Render.Inactive,				// line number
							F::Render.Active,				// current line number
						}};
						tTextEditor.SetPalette(tPalette);
						//TextEditor.SetShowLineNumbersEnabled(false);

						PushFont(F::Render.FontMono);
						PushStyleVar(ImGuiStyleVar_ChildBorderSize, H::Draw.Scale(1));
						ImVec2 vDrawPos = GetDrawPos() + GetCursorPos();
						tTextEditor.Render("TextEditor");
						ImVec2 vSize = GetItemRectSize();
						float flInset = H::Draw.Scale(0.5f) - 0.5f;
						GetWindowDrawList()->AddRect(vDrawPos + ImVec2(flInset, flInset), vDrawPos + ImVec2(vSize.x - flInset, vSize.y - flInset), F::Render.Background2, H::Draw.Scale(4), ImDrawFlags_None, H::Draw.Scale());
						PopStyleVar();
						PopFont();
					} EndSection();
				}

				EndTable();
			}
		}
		break;
	}
	// Extra
	case 3:
	{
		if (Section("Debug"))
		{
			FToggle(Vars::Debug::Info, FToggleEnum::Left);
			FToggle(Vars::Debug::Logging, FToggleEnum::Right);
			FToggle(Vars::Debug::Options, FToggleEnum::Left);
			FToggle(Vars::Debug::CrashLogging, FToggleEnum::Right);

#ifdef DEBUG_TRACES
			FToggle(Vars::Debug::VisualizeTraces, FToggleEnum::Left);
			FToggle(Vars::Debug::VisualizeTraceHits, FToggleEnum::Right);
#endif
		} EndSection();
		if (Vars::Debug::Options.Value && I::EngineClient->IsConnected())
		{
			if (Section("##Debug"))
			{
				FToggle(Vars::Debug::DrawHitboxes);

				if (FButton("Restore visuals", FButtonEnum::Left))
				{
					for (auto& tLine : G::LineStorage)
						tLine.m_flTime = I::GlobalVars->curtime + 60.f;
					for (auto& tPath : G::PathStorage)
						tPath.m_flTime = I::GlobalVars->curtime + 60.f;
					for (auto& tBox : G::BoxStorage)
						tBox.m_flTime = I::GlobalVars->curtime + 60.f;
					for (auto& tSphere : G::SphereStorage)
						tSphere.m_flTime = I::GlobalVars->curtime + 60.f;
					for (auto& tSwept : G::SweptStorage)
						tSwept.m_flTime = I::GlobalVars->curtime + 60.f;
					for (auto& tTriangle : G::TriangleStorage)
						tTriangle.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear visuals", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::LineStorage.clear();
					G::PathStorage.clear();
					G::BoxStorage.clear();
					G::SphereStorage.clear();
					G::SweptStorage.clear();
					G::TriangleStorage.clear();
				}

				if (FButton("Restore lines", FButtonEnum::Left))
				{
					for (auto& tLine : G::LineStorage)
						tLine.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear lines", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::LineStorage.clear();
				}

				if (FButton("Restore paths", FButtonEnum::Left))
				{
					for (auto& tPath : G::PathStorage)
						tPath.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear paths", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::PathStorage.clear();
				}

				if (FButton("Restore boxes", FButtonEnum::Left))
				{
					for (auto& tBox : G::BoxStorage)
						tBox.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear boxes", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::BoxStorage.clear();
				}

				if (FButton("Restore spheres", FButtonEnum::Left))
				{
					for (auto& tSphere : G::SphereStorage)
						tSphere.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear spheres", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::SphereStorage.clear();
				}

				if (FButton("Restore swept", FButtonEnum::Left))
				{
					for (auto& tSwept : G::SweptStorage)
						tSwept.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear swept", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::SweptStorage.clear();
				}

				if (FButton("Restore triangles", FButtonEnum::Left))
				{
					for (auto& tTriangle : G::TriangleStorage)
						tTriangle.m_flTime = I::GlobalVars->curtime + 60.f;
				}
				if (FButton("Clear triangles", FButtonEnum::Right | FButtonEnum::SameLine))
				{
					G::TriangleStorage.clear();
				}
			} EndSection();
		}
		/*
		if (Vars::Debug::Options.Value)
		{
			if (Section("Convar spoofer"))
			{
				static std::string sName = "", sValue = "";

				FSDropdown("Convar", &sName, {}, FDropdownEnum::Left);
				FSDropdown("Value", &sValue, {}, FDropdownEnum::Right);
				if (FButton("Send"))
				{
					if (auto pNetChan = static_cast<CNetChannel*>(I::EngineClient->GetNetChannelInfo()))
					{
						SDK::Output("Convar", std::format("Sent {} as {}", sName, sValue).c_str(), Vars::Menu::Theme::Accent.Value);
						NET_SetConVar cmd(sName.c_str(), sValue.c_str());
						pNetChan->SendNetMsg(cmd);

						sName = sValue = "";
					}
				}
			} EndSection();
		}
		*/
#ifdef WORLD_DEBUG
		if (Section("World"))
		{
			FDropdown(Vars::World::Faces, FDropdownEnum::Left);
			FDropdown(Vars::World::Draw, FDropdownEnum::Right);
			FSlider(Vars::World::Offset, FSliderEnum::Left);
			FSlider(Vars::World::Resize, FSliderEnum::Right);
			FColorPicker(Vars::World::BoxBrush, FColorPickerEnum::Left);
			FColorPicker(Vars::World::PlaneBrush, FColorPickerEnum::Right);
			FColorPicker(Vars::World::Displacement, FColorPickerEnum::Left);
			FColorPicker(Vars::World::Prop, FColorPickerEnum::Right);
			FColorPicker(Vars::World::Entity, FColorPickerEnum::Left);
		} EndSection();
#endif
#ifdef DEBUG_HOOKS
		if (Section("Hooks"))
		{
			auto SetAll = [](bool bEnable)
			{
				for (auto& pBase : G::Vars)
				{
					if (std::string(pBase->Name()).find("Vars::Hooks::") == std::string::npos)
						continue;

					switch (FNV1A::Hash32(pBase->Name()))
					{
					case FNV1A::Hash32Const("Vars::Hooks::Direct3DDevice9_Present"):
					case FNV1A::Hash32Const("Vars::Hooks::Direct3DDevice9_Reset"):
						break;
					default:
						pBase->As<bool>()->Map[DEFAULT_BIND] = bEnable;
					}
				}
			};
			if (FButton("Enable all", FButtonEnum::Left))
				SetAll(true);
			if (FButton("Disable all", FButtonEnum::Right | FButtonEnum::SameLine))
				SetAll(false);

			int i = 0; for (auto& pBase : G::Vars)
			{
				if (std::string(pBase->Name()).find("Vars::Hooks::") == std::string::npos)
					continue;

				FToggle(*pBase->As<bool>(), !(i % 2) ? FToggleEnum::Left : FToggleEnum::Right);
				i++;
			}
		} EndSection();
#endif
		break;
	}
	}
}

void CMenu::MenuSearch(std::string sSearch)
{
	using namespace ImGui;

	if (sSearch.empty())
		return;

	static std::vector<BaseVar*> vVars = {}; // don't string search every single frame

	static uint32_t uStaticHash = 0;
	if (const uint32_t uCurrHash = FNV1A::Hash32(sSearch.c_str());
		uCurrHash != uStaticHash)
	{
		std::string sSearch2 = sSearch;
		std::transform(sSearch2.begin(), sSearch2.end(), sSearch2.begin(), [](unsigned char c) { return char(std::tolower(c)); });

		vVars.clear();
		for (auto& pBase : G::Vars)
		{
			if (!Vars::Debug::Options[DEFAULT_BIND] && pBase->m_iFlags & DEBUGVAR)
				continue;
			if (std::string_view(pBase->Name()).starts_with("Vars::AimModes::"))continue;

			std::vector<const char*> vSearch = { pBase->Name(), pBase->Section() };
			vSearch.insert(vSearch.end(), pBase->m_vNames.begin(), pBase->m_vNames.end());
			vSearch.insert(vSearch.end(), pBase->m_vValues.begin(), pBase->m_vValues.end());
			for (auto pSearch : vSearch)
			{
				std::string sSearch3 = pSearch;
				if (auto iFind = sSearch3.find("Vars::"); iFind != std::string::npos)
					sSearch3 = sSearch3.replace(iFind, strlen("Vars::"), "");
				if (auto iFind = sSearch3.find("##"); iFind != std::string::npos)
					sSearch3 = sSearch3.replace(iFind, strlen("##"), "");
				std::transform(sSearch3.begin(), sSearch3.end(), sSearch3.begin(), [](unsigned char c) { return char(std::tolower(c)); });
				if (sSearch3.find(sSearch2) != std::string::npos)
				{
					vVars.push_back(pBase);
					break;
				}
			}
		}

		uStaticHash = uCurrHash;
	}

	if (vVars.empty())
		return;

	uint32_t uLastSection = 0;
	int i = 0; for (auto pBase : vVars) // possibly implement tablelike visuals, do away with left right, just switch if current side is higher than other?
	{
		int iWidgetEnum = WidgetEnum::Invalid, iTypeEnum = WidgetEnum::Invalid;
		if (auto pVar = pBase->As<bool>())
			iWidgetEnum = iTypeEnum = WidgetEnum::FToggle;
		else if (auto pVar = pBase->As<int>())
		{
			if (!pVar->m_vValues.empty()
				|| FNV1A::Hash32(pVar->Name()) == FNV1A::Hash32Const("Vars::ESP::ActiveGroups"))
				iWidgetEnum = iTypeEnum = WidgetEnum::FDropdown;
			else if (pVar->m_sExtra)
				iWidgetEnum = WidgetEnum::FISlider, iTypeEnum = WidgetEnum::FSlider;
			else
				iWidgetEnum = iTypeEnum = WidgetEnum::FKeybind;
		}
		else if (auto pVar = pBase->As<float>())
			iWidgetEnum = WidgetEnum::FFSlider, iTypeEnum = WidgetEnum::FSlider;
		else if (auto pVar = pBase->As<IntRange_t>())
			iWidgetEnum = WidgetEnum::FIRSlider, iTypeEnum = WidgetEnum::FSlider;
		else if (auto pVar = pBase->As<FloatRange_t>())
			iWidgetEnum = WidgetEnum::FFRSlider, iTypeEnum = WidgetEnum::FSlider;
		else if (auto pVar = pBase->As<std::string>())
			iWidgetEnum = WidgetEnum::FSDropdown, iTypeEnum = WidgetEnum::FDropdown;
		else if (auto pVar = pBase->As<std::vector<std::pair<std::string, Color_t>>>())
			iWidgetEnum = WidgetEnum::FMDropdown, iTypeEnum = WidgetEnum::FDropdown;
		else if (auto pVar = pBase->As<Color_t>())
			iWidgetEnum = WidgetEnum::FColorPicker, iTypeEnum = WidgetEnum::FToggle;
		else if (auto pVar = pBase->As<Gradient_t>())
			iWidgetEnum = WidgetEnum::FGColorPicker, iTypeEnum = WidgetEnum::FToggle;
		else
			continue;

		uint32_t uSection = FNV1A::Hash32(pBase->Section());
		if (uSection != uLastSection)
		{
			if (uLastSection)
				EndSection();
			Section(std::format("{}## {}", pBase->Section(), pBase->Name()).c_str());
			i = 0;
		}
		uLastSection = uSection;

		static int iLastEnum = WidgetEnum::Invalid;
		if (!i || iTypeEnum != iLastEnum)
		{
			if (!i)
			{
				switch (iWidgetEnum)
				{
				case WidgetEnum::FToggle:
				case WidgetEnum::FISlider:
				case WidgetEnum::FFSlider:
				case WidgetEnum::FIRSlider:
				case WidgetEnum::FFRSlider:
				case WidgetEnum::FColorPicker:
				case WidgetEnum::FGColorPicker:
					DebugDummy({ 0, H::Draw.Scale(8) });
				}
				i = 2;
			}
			else if (iTypeEnum == WidgetEnum::FToggle && iLastEnum == WidgetEnum::FSlider && (i % 2))
			{
				SetCursorPos({ GetWindowWidth() / 2 + GetStyle().WindowPadding.x / 2, GetRowPos() + H::Draw.Scale(8) });
				i = 0;
			}
			else if (iTypeEnum == WidgetEnum::FSlider && iLastEnum == WidgetEnum::FDropdown && (i % 2) && !pRowSizes->empty())
			{
				auto& tRow = pRowSizes->front();
				tRow.m_vPos.y += H::Draw.Scale(13), tRow.m_vSize.y -= H::Draw.Scale(13);
				SetCursorPos({ GetWindowWidth() / 2 + GetStyle().WindowPadding.x / 2, GetRowPos() });
				i = 0;
			}
			else
				i = 2;
		}
		iLastEnum = iTypeEnum;

		int iOverride = -1;
		switch (iWidgetEnum)
		{
		case WidgetEnum::FToggle:
		{
			auto pVar = pBase->As<bool>();
			if (FToggle(*pVar, !(i % 2) ? FToggleEnum::Left : FToggleEnum::Right, nullptr, iOverride/*, iOverride*/))
			{
				if (FNV1A::Hash32(pVar->Name()) == FNV1A::Hash32Const("Vars::Debug::Options"))
					uStaticHash = 0;
			}
			break;
		}
		case WidgetEnum::FISlider:
		{
			auto pVar = pBase->As<int>();
			const char* sFormat = nullptr;
			switch (FNV1A::Hash32(pVar->Name()))
			{
			case FNV1A::Hash32Const("Vars::Aimbot::Projectile::SplashAirCount"):
				if (!pVar->Map[DEFAULT_BIND])
					sFormat = "random";
			}
			FSlider(*pVar, !(i % 2) ? FSliderEnum::Left : FSliderEnum::Right, sFormat, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FFSlider:
		{
			auto pVar = pBase->As<float>();
			const char* sFormat = nullptr;
			switch (FNV1A::Hash32(pVar->Name()))
			{
			case FNV1A::Hash32Const("Vars::Visuals::Prediction::PlayerDrawDuration"):
			case FNV1A::Hash32Const("Vars::Visuals::Prediction::ProjectileDrawDuration"):
				if (!pVar->Map[DEFAULT_BIND])
					sFormat = "timed";
				break;
			case FNV1A::Hash32Const("Vars::Aimbot::Projectile::SplashRotateX"):
			case FNV1A::Hash32Const("Vars::Aimbot::Projectile::SplashRotateY"):
				if (pVar->Map[DEFAULT_BIND] < 0.f)
					sFormat = "random";
			}
			FSlider(*pVar, !(i % 2) ? FSliderEnum::Left : FSliderEnum::Right, sFormat, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FIRSlider:
		{
			auto pVar = pBase->As<IntRange_t>();
			FSlider(*pVar, !(i % 2) ? FSliderEnum::Left : FSliderEnum::Right, nullptr, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FFRSlider:
		{
			auto pVar = pBase->As<FloatRange_t>();
			FSlider(*pVar, !(i % 2) ? FSliderEnum::Left : FSliderEnum::Right, nullptr, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FDropdown:
		{
			auto pVar = pBase->As<int>();
			FDropdown(*pVar, !(i % 2) ? FDropdownEnum::Left : FDropdownEnum::Right, 0, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FSDropdown:
		{
			auto pVar = pBase->As<std::string>();
			FSDropdown(*pVar, !(i % 2) ? FDropdownEnum::Left : FDropdownEnum::Right, 0, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FMDropdown:
		{
			auto pVar = pBase->As<std::vector<std::pair<std::string, Color_t>>>();
			FMDropdown(*pVar, !(i % 2) ? FDropdownEnum::Left : FDropdownEnum::Right, 0, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FColorPicker:
		{
			auto pVar = pBase->As<Color_t>();
			FColorPicker(*pVar, !(i % 2) ? FColorPickerEnum::Left : FColorPickerEnum::Right, {}, { H::Draw.Scale(12), H::Draw.Scale(12) }, {}, nullptr, iOverride, iOverride);
			break;
		}
		case WidgetEnum::FGColorPicker:
		{
			auto pVar = pBase->As<Gradient_t>();
			FColorPicker(*pVar, true, !(i % 2) ? FColorPickerEnum::Left : FColorPickerEnum::Right, {}, { H::Draw.Scale(12), H::Draw.Scale(12) }, {}, nullptr, iOverride/*, iOverride*/);
			FColorPicker(*pVar, false, !(++i % 2) ? FColorPickerEnum::Left : FColorPickerEnum::Right, {}, { H::Draw.Scale(12), H::Draw.Scale(12) }, {}, nullptr, iOverride/*, iOverride*/);
			break;
		}
		case WidgetEnum::FKeybind:
		{
			auto pVar = pBase->As<int>();
			std::vector<int> vIgnore;
			switch (FNV1A::Hash32(pVar->Name()))
			{
			case FNV1A::Hash32Const("Vars::Menu::PrimaryKey"):
				vIgnore = { Vars::Menu::SecondaryKey[DEFAULT_BIND], VK_LBUTTON, VK_RBUTTON };
				break;
			case FNV1A::Hash32Const("Vars::Menu::SecondaryKey"):
				vIgnore = { Vars::Menu::PrimaryKey[DEFAULT_BIND], VK_LBUTTON, VK_RBUTTON };
				break;
			default:
				vIgnore = { Vars::Menu::PrimaryKey[DEFAULT_BIND], Vars::Menu::SecondaryKey[DEFAULT_BIND] };
			}
			FKeybind(iOverride != -1 ? pVar->m_vNames[iOverride] : pVar->m_vNames.front(), pVar->Map[DEFAULT_BIND], !(i % 2) ? FButtonEnum::Left : FButtonEnum::Right | FButtonEnum::SameLine, vIgnore);
			break;
		}
		}

		if (iOverride != -2)
			i += i > 1 ? 1 : 2;
	}
	if (uLastSection)
		EndSection();
}
#pragma endregion

#pragma region Draggables
static inline void SquareConstraints(ImGuiSizeCallbackData* data)
{
	//data->DesiredSize.x = data->DesiredSize.y = std::max(data->DesiredSize.x, data->DesiredSize.y);
	data->DesiredSize.x = data->DesiredSize.y = (data->DesiredSize.x + data->DesiredSize.y) / 2;
}

static inline void OptionalConstraints(ImGuiSizeCallbackData* data)
{
	if (U::KeyHandler.Down(VK_SHIFT))
		SquareConstraints(data);
}

struct DragBoxStorage_t
{
	DragBox_t m_tDragBox;
	float m_flScale;
	ImVec2 m_vSize;
	int m_iStyle = MenuMode::Nullcore;
};
static std::unordered_map<uint32_t, DragBoxStorage_t> s_mDragBoxStorage = {};
void CMenu::AddDraggable(const char* sLabel, ConfigVar<DragBox_t>& tVar, bool bShouldDraw, ImVec2 vSize)
{
	using namespace ImGui;

	if (!bShouldDraw)
		return;

	auto tDragBox = FGet(tVar, true);
	auto uHash = FNV1A::Hash32(sLabel);
	const bool bCritPanel = &tVar == &Vars::Menu::CritsDisplay || &tVar == &Vars::Menu::TicksDisplay || &tVar == &Vars::Menu::SpectatorsDisplay
		|| (MoonlitHud::Enabled() && (&tVar == &Vars::Menu::PingDisplay || &tVar == &Vars::Menu::ConditionsDisplay || &tVar == &Vars::Menu::SeedPredictionDisplay));
	const bool bSpectatorPanel = &tVar == &Vars::Menu::SpectatorsDisplay;

	bool bContains = s_mDragBoxStorage.contains(uHash);
	auto& tStorage = s_mDragBoxStorage[uHash];
	const bool themeSizeChanged = (MoonlitHud::Enabled() || tStorage.m_iStyle == MenuMode::Moonlit)
		&& (tStorage.m_iStyle != MenuMode::Active || tStorage.m_vSize.x != vSize.x || tStorage.m_vSize.y != vSize.y);

	SetNextWindowSize(vSize, ImGuiCond_Always);
	if (!bContains || tDragBox != tStorage.m_tDragBox || H::Draw.Scale() != tStorage.m_flScale || themeSizeChanged)
		SetNextWindowPos({ float(tDragBox.x - vSize.x / 2), float(tDragBox.y) }, ImGuiCond_Always);
	if (bCritPanel)
	{
		ImVec2 pos(float(tDragBox.x) - vSize.x / 2, float(tDragBox.y));
		if (auto window = FindWindowByName(sLabel); window && bContains && tDragBox == tStorage.m_tDragBox && H::Draw.Scale() == tStorage.m_flScale && !themeSizeChanged)
			pos = window->Pos;
		const float bar = MoonlitHud::Enabled() ? 0.f : H::Draw.Scale(26);
		pos.x = BindLayout::ClampAxis(pos.x, vSize.x, 0.f, GetIO().DisplaySize.x);
		pos.y = BindLayout::ClampAxis(pos.y, vSize.y, Workspace::TopTaskbar ? bar : 0.f,
			GetIO().DisplaySize.y - (Workspace::TopTaskbar ? 0.f : bar));
		SetNextWindowPos(pos, ImGuiCond_Always);
	}

	PushStyleColor(ImGuiCol_WindowBg, {});
	PushStyleColor(ImGuiCol_Border, F::Render.Active.Value);
	PushStyleVar(ImGuiStyleVar_WindowRounding, H::Draw.Scale(3));
	// Crit hack already renders an accent outline; its editor is only a drag surface.
	PushStyleVar(ImGuiStyleVar_WindowBorderSize, bCritPanel ? 0.f : H::Draw.Scale(1));
	PushStyleVar(ImGuiStyleVar_WindowMinSize, bSpectatorPanel
		? ImVec2(F::SpectatorList.m_vMinimumSize.x, F::SpectatorList.m_vMinimumSize.y) : vSize);
	if (Begin(sLabel, nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoSavedSettings))
	{
		ImVec2 vWindowPos = GetWindowPos();
		if (bSpectatorPanel)
		{
			// Four explicit grips support all corners without ImGui's default border.
			static ImVec2 resizeMouse, resizePos, resizeSize;
			const float grip = std::max(8.f, H::Draw.Scale(8));
			for (int corner = 0; corner < 4; ++corner)
			{
				const bool right = (corner & 1) != 0, bottom = (corner & 2) != 0;
				SetCursorPos({ right ? vSize.x - grip : 0.f, bottom ? vSize.y - grip : 0.f });
				PushID(corner);
				InvisibleButton("##SpectatorResize", { grip, grip });
				if (IsItemHovered() || IsItemActive()) SetMouseCursor(right == bottom ? ImGuiMouseCursor_ResizeNWSE : ImGuiMouseCursor_ResizeNESW);
				if (IsItemActivated()) { resizeMouse = GetIO().MousePos; resizePos = vWindowPos; resizeSize = vSize; }
				if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left, 0.f))
				{
					const ImVec2 delta = GetIO().MousePos - resizeMouse;
					const float bar = MoonlitHud::Enabled() ? 0.f : H::Draw.Scale(26);
					const float minY = Workspace::TopTaskbar ? bar : 0.f;
					const float maxY = GetIO().DisplaySize.y - (Workspace::TopTaskbar ? 0.f : bar);
					const auto [newX, newW] = SpectatorStyle::ResizeAxis(resizePos.x, resizeSize.x, delta.x, right,
						F::SpectatorList.m_vMinimumSize.x, 0.f, GetIO().DisplaySize.x);
					const auto [newY, newH] = SpectatorStyle::ResizeAxis(resizePos.y, resizeSize.y, delta.y, bottom,
						F::SpectatorList.m_vMinimumSize.y, minY, maxY);
					vSize = { newW, newH }; vWindowPos = { newX, newY };
					SetWindowPos(vWindowPos); SetWindowSize(vSize);
					FSet(Vars::Menu::SpectatorWidth, int(vSize.x));
					FSet(Vars::Menu::SpectatorHeight, int(vSize.y));
				}
				const ImVec2 point = vWindowPos + ImVec2(right ? vSize.x - 1 : 1, bottom ? vSize.y - 1 : 1);
				const auto colour = MoonlitHud::Enabled() ? IM_COL32(192,163,243,255)
					: GetColorU32(ImVec4(Workspace::BorderChannel(0), Workspace::BorderChannel(1), Workspace::BorderChannel(2), 1.f));
				GetWindowDrawList()->AddLine(point, point + ImVec2(right ? -grip : grip, 0), colour, 2.f);
				GetWindowDrawList()->AddLine(point, point + ImVec2(0, bottom ? -grip : grip), colour, 2.f);
				PopID();
			}
		}

		if (bCritPanel)
		{
			const float bar = MoonlitHud::Enabled() ? 0.f : H::Draw.Scale(26);
			vWindowPos.x = BindLayout::ClampAxis(vWindowPos.x, vSize.x, 0.f, GetIO().DisplaySize.x);
			vWindowPos.y = BindLayout::ClampAxis(vWindowPos.y, vSize.y,
				Workspace::TopTaskbar ? bar : 0.f, GetIO().DisplaySize.y - (Workspace::TopTaskbar ? 0.f : bar));
			SetWindowPos(vWindowPos);
		}
		tDragBox.x = vWindowPos.x + vSize.x / 2, tDragBox.y = vWindowPos.y;
		tStorage = { tDragBox, H::Draw.Scale(), vSize, MenuMode::Active };
		FSet(tVar, tDragBox);

		// The crit panel is an empty drag surface. Only position the cursor when
		// submitting a label; a cursor-only layout extension triggers an ImGui assertion.
		if (!bCritPanel)
		{
			PushFont(F::Render.FontBold);
			ImVec2 vTextSize = FCalcTextSize(sLabel);
			SetCursorPos({ (vSize.x - vTextSize.x) * 0.5f, (vSize.y - vTextSize.y) * 0.5f });
			FText(sLabel);
			PopFont();
		}
	}
	End(); // must always be paired with Begin, even when it returns false
	PopStyleVar(3);
	PopStyleColor(2);
}

struct WindowBoxStorage_t
{
	WindowBox_t m_tWindowBox;
	float m_flScale;
};
static std::unordered_map<uint32_t, WindowBoxStorage_t> s_mWindowBoxStorage = {};
void CMenu::AddResizableDraggable(const char* sLabel, ConfigVar<WindowBox_t>& tVar, bool bShouldDraw, ImGuiSizeCallback fCustomCallback, ImVec2 vMinSize, ImVec2 vMaxSize)
{
	using namespace ImGui;

	if (!bShouldDraw)
		return;

	auto tWindowBox = FGet(tVar, true);
	auto uHash = FNV1A::Hash32(sLabel);

	bool bContains = s_mWindowBoxStorage.contains(uHash);
	auto& tStorage = s_mWindowBoxStorage[uHash];

	SetNextWindowSizeConstraints(vMinSize, vMaxSize, fCustomCallback);
	if (!bContains || tWindowBox != tStorage.m_tWindowBox || H::Draw.Scale() != tStorage.m_flScale)
	{
		SetNextWindowPos({ float(tWindowBox.x - tWindowBox.w / 2), float(tWindowBox.y) }, ImGuiCond_Always);
		SetNextWindowSize({ float(tWindowBox.w), float(tWindowBox.h) }, ImGuiCond_Always);
	}

	PushStyleColor(ImGuiCol_WindowBg, {});
	PushStyleColor(ImGuiCol_Border, F::Render.Active.Value);
	PushStyleVar(ImGuiStyleVar_WindowRounding, H::Draw.Scale(3));
	PushStyleVar(ImGuiStyleVar_WindowBorderSize, H::Draw.Scale(1));
	if (Begin(sLabel, nullptr, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoSavedSettings))
	{
		ImVec2 vWindowPos = GetWindowPos();
		ImVec2 vWinSize = GetWindowSize();

		tWindowBox.w = vWinSize.x, tWindowBox.h = vWinSize.y;
		tWindowBox.x = vWindowPos.x + tWindowBox.w / 2, tWindowBox.y = vWindowPos.y;
		tStorage = { tWindowBox, H::Draw.Scale() };
		FSet(tVar, tWindowBox);

		PushFont(F::Render.FontBold);
		ImVec2 vTextSize = FCalcTextSize(sLabel);
		SetCursorPos({ (vWinSize.x - vTextSize.x) * 0.5f, (vWinSize.y - vTextSize.y) * 0.5f });
		FText(sLabel);
		PopFont();
	}
	End(); // must always be paired with Begin, even when it returns false
	PopStyleVar(2);
	PopStyleColor(2);
}

struct BindInfo_t
{
	const char* sName;
	std::string sInfo;
	std::string sState;

	int iBind;
	Bind_t& tBind;
	bool bEffectiveActive;
};
void CMenu::DrawBinds()
{
	using namespace ImGui;
	const bool moonlit = MoonlitHud::Enabled();
	const int rowStride = moonlit ? 36 : 28;
	if (!m_bIsOpen && I::EngineClient->IsInGame() && H::Entities.GetLocal() && F::Radar.SuppressBinds()) return;

	if (!F::Binds.m_bDisplay)
		return;

	std::vector<BindInfo_t> vInfo;
	std::function<void(int, bool)> fGetBinds = [&](int iParent, bool bParentActive)
	{
		for (int iBind = 0; iBind < F::Binds.m_vBinds.size(); iBind++)
		{
			auto& tBind = F::Binds.m_vBinds[iBind];
			if (iParent != tBind.m_iParent || !tBind.m_bEnabled && !m_bIsOpen)
				continue;

			const auto display=BindPresentation::Get(tBind,iBind,bParentActive,MenuMode::Active==MenuMode::Moonlit);
			if (tBind.m_iVisibility == BindVisibilityEnum::Always || tBind.m_iVisibility == BindVisibilityEnum::WhileActive && display.active || m_bIsOpen)
			{
				std::string sType; std::string sInfo;
				switch (tBind.m_iType)
				{
				case BindEnum::Key:
					switch (tBind.m_iInfo)
					{
					case BindEnum::KeyEnum::Hold: { sType = "hold"; break; }
					case BindEnum::KeyEnum::Toggle: { sType = "toggle"; break; }
					case BindEnum::KeyEnum::DoubleClick: { sType = "double"; break; }
					}
					sInfo = U::KeyHandler.String(tBind.m_iKey);
					break;
				case BindEnum::Class:
					sType = "class";
					switch (tBind.m_iInfo)
					{
					case BindEnum::ClassEnum::Scout: { sInfo = "scout"; break; }
					case BindEnum::ClassEnum::Soldier: { sInfo = "soldier"; break; }
					case BindEnum::ClassEnum::Pyro: { sInfo = "pyro"; break; }
					case BindEnum::ClassEnum::Demoman: { sInfo = "demoman"; break; }
					case BindEnum::ClassEnum::Heavy: { sInfo = "heavy"; break; }
					case BindEnum::ClassEnum::Engineer: { sInfo = "engineer"; break; }
					case BindEnum::ClassEnum::Medic: { sInfo = "medic"; break; }
					case BindEnum::ClassEnum::Sniper: { sInfo = "sniper"; break; }
					case BindEnum::ClassEnum::Spy: { sInfo = "spy"; break; }
					}
					break;
				case BindEnum::WeaponType:
					sType = "weapon";
					switch (tBind.m_iInfo)
					{
					case BindEnum::WeaponTypeEnum::Hitscan: { sInfo = "hitscan"; break; }
					case BindEnum::WeaponTypeEnum::Projectile: { sInfo = "projectile"; break; }
					case BindEnum::WeaponTypeEnum::Melee: { sInfo = "melee"; break; }
					case BindEnum::WeaponTypeEnum::Throwable: { sInfo = "throwable"; break; }
					}
					break;
				case BindEnum::ItemSlot:
					sType = "slot";
					sInfo = std::format("{}", tBind.m_iInfo + 1);
					break;
				case BindEnum::Behind:
					sType = "behind"; sInfo = ConditionPolicy::ClassName(tBind.m_tConditions.enemyClass); break;
				case BindEnum::Threat:
					sType = "threat"; sInfo = std::format("{:.2f}s", tBind.m_tConditions.projectileWindow); break;
				case BindEnum::Misc:
					switch (tBind.m_iInfo)
					{
					case BindEnum::MiscEnum::Spectated:
					case BindEnum::MiscEnum::SpectatedFirst:
					case BindEnum::MiscEnum::SpectatedThird:
						sType = "spectated";
						switch (tBind.m_iInfo)
						{
						case BindEnum::MiscEnum::Spectated: { sInfo = "any"; break; }
						case BindEnum::MiscEnum::SpectatedFirst: { sInfo = "1st"; break; }
						case BindEnum::MiscEnum::SpectatedThird: { sInfo = "3rd"; break; }
						}
						break;
					case BindEnum::MiscEnum::Zoomed:
					case BindEnum::MiscEnum::Aiming:
						sType = "cond";
						switch (tBind.m_iInfo)
						{
						case BindEnum::MiscEnum::Zoomed: { sInfo = "zoomed"; break; }
						case BindEnum::MiscEnum::Aiming: { sInfo = "aiming"; break; }
						}
						break;
					}
					break;
				}
				if (!display.feature && tBind.m_bNot && (tBind.m_iType != BindEnum::Key || tBind.m_iInfo == BindEnum::KeyEnum::Hold))
					sInfo = std::format("not {}", sInfo);

				vInfo.emplace_back(tBind.m_sName.c_str(), sType, sInfo, iBind, tBind,
					display.active);
			}

			if (tBind.m_bActive || m_bIsOpen)
				fGetBinds(iBind, bParentActive && tBind.m_bEnabled && tBind.m_bActive);
		}
	};
	fGetBinds(DEFAULT_BIND, true);
	if (vInfo.empty())
		return;

	static DragBox_t tOld = { -2147483648, -2147483648 };
	DragBox_t tDragBox = m_bIsOpen ? FGet(Vars::Menu::BindsDisplay, true) : Vars::Menu::BindsDisplay.Value;
	if (tDragBox != tOld)
		SetNextWindowPos({ float(tDragBox.x), float(tDragBox.y) }, ImGuiCond_Always);

	float flNameWidth = 0, flInfoWidth = 0, flStateWidth = 0;
	PushFont(F::Render.FontSmall);
	for (auto& [sName, sInfo, sState, iBind, tBind, bEffectiveActive] : vInfo)
	{
		flNameWidth = std::max(flNameWidth, FCalcTextSize(sName).x);
		flInfoWidth = std::max(flInfoWidth, FCalcTextSize(sInfo.c_str()).x);
		flStateWidth = std::max(flStateWidth, FCalcTextSize(sState.c_str()).x);
	}
	PopFont();
	flNameWidth += H::Draw.Scale(9), flInfoWidth += H::Draw.Scale(9), flStateWidth += H::Draw.Scale(9);
	if (moonlit) { flNameWidth += H::Draw.Scale(12); flStateWidth += H::Draw.Scale(12); }

	float flWidth = flNameWidth + flInfoWidth + flStateWidth + (m_bIsOpen ? H::Draw.Scale(113) : H::Draw.Scale(14));
	const float flCardWidth = flWidth - H::Draw.Scale(12);
	const float flStride = flCardWidth + H::Draw.Scale(6);
	const int iColumns = BindLayout::Columns(int(vInfo.size()), Vars::Menu::BindWindowHorizontal.Value,
		GetIO().DisplaySize.x, flStride, H::Draw.Scale(16));
	const int iRows = BindLayout::Rows(int(vInfo.size()), iColumns);
	flWidth = iColumns * flStride + H::Draw.Scale(6);
	float flHeight = H::Draw.Scale(rowStride * iRows + (Vars::Menu::BindWindowTitle.Value ? (moonlit ? 48 : 38) : (moonlit ? 18 : 10)));
	SetNextWindowSize({ flWidth, flHeight }, ImGuiCond_Always);
	ImVec2 vLivePos(float(tDragBox.x), float(tDragBox.y));
	if (auto window = FindWindowByName("Binds"); window && tDragBox == tOld)
		vLivePos = window->Pos;
	const float flTaskbar = m_bIsOpen && !moonlit ? H::Draw.Scale(26) : 0.f;
	vLivePos.x = BindLayout::ClampAxis(vLivePos.x, flWidth, 0.f, GetIO().DisplaySize.x);
	vLivePos.y = BindLayout::ClampAxis(vLivePos.y, flHeight, Workspace::TopTaskbar ? flTaskbar : 0.f,
		GetIO().DisplaySize.y - (Workspace::TopTaskbar ? 0.f : flTaskbar));
	SetNextWindowPos(vLivePos, ImGuiCond_Always);
	PushStyleVar(ImGuiStyleVar_WindowMinSize, { H::Draw.Scale(40), H::Draw.Scale(40) });
	if (Begin("Binds", nullptr, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoSavedSettings))
	{
		ImVec2 vWindowPos = GetWindowPos();
		const ImVec2 vActualSize = GetWindowSize();
		const float flBar = m_bIsOpen && !moonlit ? H::Draw.Scale(26) : 0.f;
		vWindowPos.x = BindLayout::ClampAxis(vWindowPos.x, vActualSize.x, 0.f, GetIO().DisplaySize.x);
		vWindowPos.y = BindLayout::ClampAxis(vWindowPos.y, vActualSize.y,
			Workspace::TopTaskbar ? flBar : 0.f, GetIO().DisplaySize.y - (Workspace::TopTaskbar ? 0.f : flBar));
		SetWindowPos(vWindowPos);

		if (moonlit)
		{
			GetWindowDrawList()->AddRectFilled(vWindowPos, vWindowPos + vActualSize, IM_COL32(33,27,48,245), H::Draw.Scale(12));
			GetWindowDrawList()->AddRect(vWindowPos, vWindowPos + vActualSize, IM_COL32(72,59,92,255), H::Draw.Scale(12));
		}
		else if (Vars::Menu::BindWindowTitle.Value)
			RenderTwoToneBackground(H::Draw.Scale(28), F::Render.Background0, F::Render.Background0p5, F::Render.Background2);
		else
			RenderBackground(F::Render.Background0p5, F::Render.Background2);

		tDragBox.x = vWindowPos.x; tDragBox.y = vWindowPos.y; tOld = tDragBox;
		if (m_bIsOpen)
			FSet(Vars::Menu::BindsDisplay, tDragBox);

		int iListStart = moonlit ? 12 : 8;
		if (Vars::Menu::BindWindowTitle.Value)
		{
			SetCursorPos({ H::Draw.Scale(8), H::Draw.Scale(6) });
			if (moonlit && Workspace::PetEnabled)
			{
				if (auto icon = F::Render.NikoLauncherIcon()) Image(icon, {H::Draw.Scale(20), H::Draw.Scale(20)});
				else IconImage(ICON_MD_KEYBOARD, F::Render.Accent);
			}
			else IconImage(ICON_MD_KEYBOARD, F::Render.Accent);
			PushFont(F::Render.FontLarge);
			SetCursorPos({ H::Draw.Scale(30), H::Draw.Scale(7) });
			FText("Binds");
			PopFont();

			iListStart = moonlit ? 44 : 36;
		}

		PushFont(F::Render.FontSmall);
		int iPendingRemove = DEFAULT_BIND; // bind removal is deferred until vInfo (which references the bind list) is no longer being iterated
		int i = 0; for (auto& [sName, sInfo, sState, iBind, tBind, bEffectiveActive] : vInfo)
		{
			const float flCardX = H::Draw.Scale(6) + (i % iColumns) * flStride;
			const float flTextY = H::Draw.Scale(iListStart + rowStride * (i / iColumns));
			const float flCardRight = flCardX + flCardWidth;
			float flPosX = flCardX - H::Draw.Scale(6);
			const ImVec2 vMin(vWindowPos.x + flCardX, vWindowPos.y + flTextY - H::Draw.Scale(4));
			const ImVec2 vMax(vMin.x + flCardWidth, vMin.y + H::Draw.Scale(moonlit ? 30 : 24));
			GetWindowDrawList()->AddRectFilled(vMin, vMax, moonlit ? IM_COL32(43,36,60,255) : IM_COL32(0,0,0,255), moonlit ? H::Draw.Scale(8) : 0.f);
			if (moonlit)
				GetWindowDrawList()->AddCircleFilled(vMin + ImVec2(H::Draw.Scale(8), H::Draw.Scale(15)), H::Draw.Scale(2.5f),
					bEffectiveActive ? IM_COL32(192,163,243,255) : IM_COL32(100,87,120,255));
			if (bEffectiveActive && !moonlit)
			{
				// A steady glow communicates activation without distracting flashing.
				// Keep the halo inside the existing row gutter so neighbouring binds stay distinct.
				auto tint = [&](float alpha)
				{
					ImVec4 colour = F::Render.Accent.Value;
					colour.w = alpha;
					return GetColorU32(colour);
				};
				const float scale = std::max(.5f, H::Draw.Scale());
				for (int layer = 3; layer >= 1; --layer)
				{
					const ImVec2 spread(layer * .5f * scale, layer * .5f * scale);
					GetWindowDrawList()->AddRect(vMin - spread, vMax + spread,
						tint(.09f + (3 - layer) * .07f), 0.f, ImDrawFlags_None, scale);
				}
				GetWindowDrawList()->AddRectFilled(vMin, vMax, tint(.16f));
				const ImVec2 inset(scale, scale);
				GetWindowDrawList()->AddRect(vMin + inset, vMax - inset, tint(.55f), 0.f, ImDrawFlags_None, scale);
			}
			if (!moonlit) GetWindowDrawList()->AddRect(vMin, vMax, GetColorU32(F::Render.Accent.Value));
			PushID(iBind);

			if (m_bIsOpen)
				PushTransparent(!F::Binds.WillBeEnabled(iBind), true);

			auto drawBindText = [&](const char* text)
			{
				if (!bEffectiveActive || !Vars::Menu::BindTextGlow.Value)
				{
					FText(text);
					return;
				}
				Workspace::ScopedTextColour preserveColour;
				ImVec4 colour = Vars::Menu::BindTextGlowCustom.Value
					? ColorByteToFloat(Vars::Menu::BindTextGlowColour.Value).Value : F::Render.Accent.Value;
				if (!Vars::Menu::BindTextGlowCustom.Value)
				{
					colour.x += (1.f - colour.x) * .45f;
					colour.y += (1.f - colour.y) * .45f;
					colour.z += (1.f - colour.z) * .45f;
				}
				colour.w = 1.f;
				const ImVec2 position = GetCursorScreenPos();
				const float scale = std::max(.5f, H::Draw.Scale());
				// Low-alpha glyph copies form a soft halo; draw the crisp glyphs last.
				for (int ring = 2; ring >= 1; --ring)
				{
					ImVec4 halo = colour; halo.w = ring == 2 ? .075f : .14f;
					for (int dx = -1; dx <= 1; ++dx)
						for (int dy = -1; dy <= 1; ++dy)
							if (dx || dy)
								GetWindowDrawList()->AddText(GetFont(), GetFontSize(),
									position + ImVec2(dx * ring * scale, dy * ring * scale), GetColorU32(halo), text);
				}
				PushStyleColor(ImGuiCol_Text, colour);
				FText(text);
				PopStyleColor();
			};

			SetCursorPos({ flPosX += H::Draw.Scale(moonlit ? 22 : 12), flTextY });
			PushStyleColor(ImGuiCol_Text, bEffectiveActive ? F::Render.Accent.Value : F::Render.Inactive.Value);
			drawBindText(sName);
			PopStyleColor();

			SetCursorPos({ flPosX += flNameWidth, flTextY });
			PushStyleColor(ImGuiCol_Text, bEffectiveActive ? F::Render.Active.Value : F::Render.Inactive.Value);
			drawBindText(sInfo.c_str());

			SetCursorPos({ flPosX += flInfoWidth, flTextY });
			if (moonlit)
			{
				const auto keyPos = GetCursorScreenPos();
				GetWindowDrawList()->AddRectFilled(keyPos - ImVec2(H::Draw.Scale(4), H::Draw.Scale(2)),
					keyPos + CalcTextSize(sState.c_str()) + ImVec2(H::Draw.Scale(4), H::Draw.Scale(2)), IM_COL32(25,21,33,255), H::Draw.Scale(5));
			}
			drawBindText(sState.c_str());
			PopStyleColor();

			if (m_bIsOpen)
			{	// buttons
				SetCursorPos({ flCardRight - H::Draw.Scale(20), flTextY - H::Draw.Scale(2) });
				bool bDelete = IconButton(ICON_MD_DELETE, H::Draw.Scale(18), F::Render.Accent.Value);

				SetCursorPos({ flCardRight - H::Draw.Scale(45), flTextY - H::Draw.Scale(2) });
				bool bNot = IconButton(!tBind.m_bNot ? ICON_MD_CODE : ICON_MD_CODE_OFF, H::Draw.Scale(18), F::Render.Accent.Value);

				PushTransparent(Transparent || tBind.m_iVisibility == BindVisibilityEnum::Hidden, true);
				SetCursorPos({ flCardRight - H::Draw.Scale(70), flTextY - H::Draw.Scale(2) });
				bool bVisibility = IconButton(tBind.m_iVisibility == BindVisibilityEnum::Always ? ICON_MD_VISIBILITY : ICON_MD_VISIBILITY_OFF, H::Draw.Scale(18), F::Render.Accent.Value);
				PopTransparent(1, 1);

				SetCursorPos({ flCardRight - H::Draw.Scale(95), flTextY - H::Draw.Scale(2) });
				bool bEnable = IconButton(tBind.m_bEnabled ? ICON_MD_TOGGLE_ON : ICON_MD_TOGGLE_OFF, H::Draw.Scale(18), F::Render.Accent.Value);

				PopTransparent(1, 1);

				PushFont(F::Render.FontRegular);
				PushStyleVar(ImGuiStyleVar_WindowPadding, { H::Draw.Scale(8), H::Draw.Scale(8) });

				if (bEnable)
					tBind.m_bEnabled = !tBind.m_bEnabled;
				else if (bVisibility)
					tBind.m_iVisibility = (tBind.m_iVisibility + 1) % 3;
				else if (bNot)
					tBind.m_bNot = !tBind.m_bNot;
				else if (bDelete)
				{
					if (tBind.m_vVars.size() <= 1 && !F::Binds.HasChildren(iBind) || U::KeyHandler.Down(VK_SHIFT)) // allow user to quickly remove binds
						iPendingRemove = iBind;
					else
						OpenPopup(std::format("DeleteBind{}", iBind).c_str());
				}

				if (FBeginPopupModal(std::format("DeleteBind{}", iBind).c_str()))
				{
					FText(std::format("Do you really want to delete '{}'{}?", tBind.m_sName, F::Binds.HasChildren(iBind) ? " and all of its children" : "").c_str());

					SetCursorPosY(GetCursorPosY() - 8); // stupid and i don't know why this is needed here
					if (FButton("Yes", FButtonEnum::Left))
					{
						iPendingRemove = iBind;
						CloseCurrentPopup();
					}
					if (FButton("No", FButtonEnum::Right | FButtonEnum::SameLine))
						CloseCurrentPopup();

					EndPopup();
				}

				PopStyleVar();
				PopFont();
			}

			PopID();
			i++;
		}
		PopFont();

		if (iPendingRemove != DEFAULT_BIND)
			RemoveBindAndRemap(iPendingRemove);
	}
	End(); // must always be paired with Begin, even when it returns false
	PopStyleVar();
}
#pragma endregion

static inline void ManageVars()
{
	Vars::ESP::ActiveGroups.m_vValues = {};
	for (auto& tGroup : F::Groups.m_vGroups)
		Vars::ESP::ActiveGroups.m_vValues.push_back(tGroup.m_sName.c_str());
}

#include "Moonlit.inl"

void CMenu::Render()
{
	using namespace ImGui;

	if (!(GetIO().DisplaySize.x > 160.f && GetIO().DisplaySize.y > 28.f))
		return;

	m_bInKeybind = false;
	if (!m_bIsOpen || MenuMode::Active != MenuMode::Moonlit) MoonlitUI::CancelCapture();
	if (m_bIsOpen)
	{
		for (short iKey = 1; iKey < 255; iKey++)
			U::KeyHandler.StoreKey(iKey);
	}
	else
	{
		U::KeyHandler.StoreKey(Vars::Menu::PrimaryKey.Value);
		U::KeyHandler.StoreKey(Vars::Menu::SecondaryKey.Value);
	}
	if (U::KeyHandler.Pressed(Vars::Menu::PrimaryKey.Value) || U::KeyHandler.Pressed(Vars::Menu::SecondaryKey.Value))
		I::MatSystemSurface->SetCursorAlwaysVisible(m_bIsOpen = !m_bIsOpen);

    const auto applyClosedStyle = [&] {
        if (m_bIsOpen || !MenuMode::ApplyClosed()) return;
        ClearActiveID(); ClosePopupsOverWindow(nullptr, false); ActiveMap.clear();
        m_bInKeybind = false; NikoPet::Close();
        m_sInterfaceStatus = Workspace::Save() ? "Menu style saved." : "Menu changed, but preferences could not be saved.";
    };
    applyClosedStyle();

	PushFont(F::Render.FontRegular);
	if (m_bIsOpen)
	{
		ManageVars();
		if (MenuMode::Active == MenuMode::Moonlit) DrawMoonlit();
        else DrawMenu();
        applyClosedStyle();

		AddDraggable("Ticks", Vars::Menu::TicksDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::Ticks,
			{ F::Ticks.m_vIndicatorSize.x, F::Ticks.m_vIndicatorSize.y });
		AddDraggable("Crit hack", Vars::Menu::CritsDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::CritHack,
			{ F::CritHack.m_vIndicatorSize.x, F::CritHack.m_vIndicatorSize.y });
		AddDraggable("Spectators", Vars::Menu::SpectatorsDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::Spectators,
			{ F::SpectatorList.m_vIndicatorSize.x, F::SpectatorList.m_vIndicatorSize.y });
		AddDraggable("Ping", Vars::Menu::PingDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::Ping,
			MoonlitHud::Enabled() ? ImVec2(F::Backtrack.m_vIndicatorSize.x, F::Backtrack.m_vIndicatorSize.y) : ImVec2(H::Draw.Scale(100),H::Draw.Scale(40)));
		AddDraggable("Conditions", Vars::Menu::ConditionsDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::Conditions,
			MoonlitHud::Enabled() ? ImVec2(F::PlayerConditions.m_vIndicatorSize.x, F::PlayerConditions.m_vIndicatorSize.y) : ImVec2(H::Draw.Scale(100),H::Draw.Scale(40)));
		AddDraggable("Seed prediction", Vars::Menu::SeedPredictionDisplay, FGet(Vars::Menu::Indicators) & Vars::Menu::IndicatorsEnum::SeedPrediction,
			MoonlitHud::Enabled() ? ImVec2(F::NoSpreadHitscan.m_vIndicatorSize.x, F::NoSpreadHitscan.m_vIndicatorSize.y) : ImVec2(H::Draw.Scale(100),H::Draw.Scale(40)));
		AddResizableDraggable("Camera", Vars::Visuals::Simulation::ProjectileWindow, FGet(Vars::Visuals::Simulation::ProjectileCamera), OptionalConstraints);

		F::Render.Cursor = GetMouseCursor();
		m_bWindowHovered = IsWindowHovered(ImGuiHoveredFlags_AnyWindow | ImGuiHoveredFlags_AllowWhenBlockedByPopup | ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);

		if (!DisabledVec.empty())
		{
			IM_ASSERT_USER_ERROR(0, "Calling PopDisabled() too little times: stack overflow.");
			Disabled = false;
			DisabledVec.clear();
		}
		if (!TransparentVec.empty())
		{
			IM_ASSERT_USER_ERROR(0, "Calling PopTransparent() too little times: stack overflow.");
			Transparent = false;
			TransparentVec.clear();
		}
	}
	else
	{
		ActiveMap.clear();
		NikoPet::Suspend();
		m_bWindowHovered = false;
	}
	if (MoonlitHud::Enabled())
	{
		MoonlitUI::StyleScope theme;
		GetStyle().WindowPadding = {H::Draw.Scale(8), H::Draw.Scale(8)};
		PushFont(F::Render.FontMoonlit);
		DrawBinds();
		F::Notifications.Draw();
		PopFont();
	}
	else
	{
		DrawBinds();
		F::Notifications.Draw();
	}
	if (m_bIsOpen)
	{
		NikoPet::Draw();
		m_bWindowHovered |= NikoPet::Hovered;
		F::Render.Cursor = GetMouseCursor();
	}
	PopFont();
}

void CMenu::AddOutput(const char* sFunction, const char* sLog, Color_t tColor)
{
	static size_t iID = 0;

	std::lock_guard tLock(m_tOutputMutex);
	m_vOutput.emplace_back(sFunction, sLog, iID++, tColor);
	while (m_vOutput.size() > m_iMaxOutputSize)
		m_vOutput.pop_front();
}
