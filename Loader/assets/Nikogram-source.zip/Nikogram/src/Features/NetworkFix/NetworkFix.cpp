#include "NetworkFix.h"

void CReadPacketState::Store()
{
	m_flFrameTimeClientState = I::ClientState->m_frameTime;
	m_flFrameTime = I::GlobalVars->frametime;
	m_flCurTime = I::GlobalVars->curtime;
	m_nTickCount = I::GlobalVars->tickcount;
}

void CReadPacketState::Restore()
{
	I::ClientState->m_frameTime = m_flFrameTimeClientState;
	I::GlobalVars->frametime = m_flFrameTime;
	I::GlobalVars->curtime = m_flCurTime;
	I::GlobalVars->tickcount = m_nTickCount;
}

void CNetworkFix::FixInputDelay(bool bFinalTick)
{
	if (!Vars::Misc::Game::NetworkFix.Value || !I::EngineClient->IsInGame() || SDK::IsLoopback())
		return;

	m_tBackup.Store();

	static auto CL_ReadPackets = U::Hooks.m_mHooks["CL_ReadPackets"];
	CL_ReadPackets->Call<void>(bFinalTick);

	m_tState.Store();
	m_tBackup.Restore();
	m_bStored = true;
}

bool CNetworkFix::ShouldReadPackets()
{
	if (!Vars::Misc::Game::NetworkFix.Value || !I::EngineClient->IsInGame() || SDK::IsLoopback())
	{
		m_bStored = false;
		return true;
	}

	if (!m_bStored) // packets weren't read by FixInputDelay this tick
		return true;

	m_bStored = false;
	m_tState.Restore();
	return false;
}