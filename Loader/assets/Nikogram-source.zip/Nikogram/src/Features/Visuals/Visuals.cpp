#include "Visuals.h"
#include "RenderState.h"
#include "../ImGui/MoonlitHud.h"

#include "../Simulation/ProjectileSimulation/ProjectileSimulation.h"
#include "../Aimbot/AimbotProjectile/AimbotProjectile.h"
#include "../Aimbot/Aimbot.h"
#include "CameraWindow/CameraWindow.h"
#include "Groups/Groups.h"
#include "../Backtrack/Backtrack.h"
#include "../Spectate/Spectate.h"
#include "../CritHack/CritHack.h"
#include "../Ticks/Ticks.h"
#include "../PacketManip/AntiAim/AntiAim.h"
#include "FakeAngle/FakeAngle.h"
#include "AnimInterp/AnimInterp.h"
#include "../World/World.h"
#include "../ImGui/Workspace.h"
#include "../../SDK/Helpers/ExtrapolationEdge.h"

MAKE_SIGNATURE(UTIL_PlayerByIndex, "server.dll", "48 83 EC ? 8B D1 85 C9 7E ? 48 8B 05", 0x0);
MAKE_SIGNATURE(CBaseAnimating_DrawServerHitboxes, "server.dll", "44 88 44 24 ? 53 48 81 EC", 0x0);
MAKE_SIGNATURE(NDebugOverlay_BoxAngles, "server.dll", "48 83 EC ? 4C 8B D9 48 8B 0D ? ? ? ? 48 85 C9 74 ? 8B 84 24 ? ? ? ? F3 0F 10 84 24 ? ? ? ? 4C 8B 11 F3 0F 11 44 24 ? 89 44 24 ? 8B 84 24 ? ? ? ? 89 44 24 ? 8B 84 24 ? ? ? ? 89 44 24 ? 8B 84 24 ? ? ? ? 89 44 24 ? 4C 89 4C 24", 0x0);
MAKE_SIGNATURE(CBaseAnimating_DrawServerHitboxes_BoxAngles_Call, "server.dll", "8B 84 24 ? ? ? ? 49 83 C6", 0x0);
MAKE_SIGNATURE(CTFPlayerShared_UpdateCritBoostEffect, "client.dll", "48 8B C4 48 89 58 ? 48 89 70 ? 48 89 78 ? 41 56 48 81 EC ? ? ? ? 48 89 68", 0x0);

enum ECritBoostUpdateType { kCritBoost_Ignore, kCritBoost_ForceRefresh };

static std::vector<Vec3> SplashTrace(Vec3 vOrigin, float flRadius, Vec3 vNormal = { 0, 0, 1 }, bool bTrace = true, int iSegments = 100)
{
	if (!flRadius)
		return {};

	Vec3 vAngles = Math::VectorAngles(vNormal);
	Vec3 vRight, vUp; Math::AngleVectors(vAngles, nullptr, &vRight, &vUp);

	std::vector<Vec3> vPoints = {};
	for (float i = 0.f; i < iSegments; i++)
	{
		Vec3 vPoint = vOrigin + (vRight * cos(2 * Math::PI * i / iSegments) + vUp * sin(2 * Math::PI * i / iSegments)) * flRadius;
		if (bTrace)
		{
			CGameTrace trace = {};
			CTraceFilterWorldAndPropsOnly filter = {};
			SDK::Trace(vOrigin, vPoint, MASK_SHOT, &filter, &trace);
			vPoint = trace.endpos;
		}
		vPoints.push_back(vPoint);
	}
	vPoints.push_back(vPoints.front());

	return vPoints;
}

void CVisuals::ProjectileTrace(CTFPlayer* pPlayer, CTFWeaponBase* pWeapon, const bool bInterp)
{
	if (bInterp)
		F::CameraWindow.m_bShouldDraw = false;
	
	if (bInterp
		? !Vars::Visuals::Simulation::TrajectoryPath.Value && !Vars::Visuals::Simulation::ProjectileCamera.Value && !(Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Enabled)
		: !Vars::Visuals::Simulation::ShotPath.Value)
		return;

	Vec3 vAngles = bInterp ? I::EngineClient->GetViewAngles() : G::CurrentUserCmd->viewangles;
	int iFlags = bInterp ? ProjSimEnum::Redirect | ProjSimEnum::InitCheck | ProjSimEnum::Interp : ProjSimEnum::Redirect | ProjSimEnum::InitCheck;
	if (F::Spectate.HasTarget() && bInterp && pPlayer && pPlayer->m_hObserverTarget())
	{
		bool bThirdperson = pPlayer->m_iObserverMode() != OBS_MODE_FIRSTPERSON;
		pPlayer = pPlayer->m_hObserverTarget()->As<CTFPlayer>();
		if (!pPlayer || pPlayer->IsDormant())
			return;

		pWeapon = pPlayer->m_hActiveWeapon()->As<CTFWeaponBase>();
		if (!pWeapon || pWeapon->GetWeaponID() == TF_WEAPON_FLAMETHROWER)
			return;

		pPlayer->m_vecViewOffset() = pPlayer->GetViewOffset();
		if (bThirdperson)
			vAngles = pPlayer->GetEyeAngles();
	}
	else if (!pPlayer || !pWeapon || pWeapon->GetWeaponID() == TF_WEAPON_FLAMETHROWER)
		return;

	ProjectileInfo tProjInfo = {};
	if (!F::ProjSim.GetInfo(pPlayer, pWeapon, vAngles, tProjInfo, iFlags, (bInterp && Vars::Aimbot::Projectile::AutoRelease.Value) ? Vars::Aimbot::Projectile::AutoRelease.Value / 100 : -1.f)
		|| !F::ProjSim.Initialize(tProjInfo))
		return;

	CGameTrace trace = {};
	CTraceFilterCollideable filter = {};
	filter.pSkip = pPlayer;
	int nMask = MASK_SOLID;
	F::ProjSim.SetupTrace(filter, nMask, pWeapon, 0, bInterp);
	Vec3* pNormal = nullptr;

	SDK::TraceHull(F::ProjSim.GetOrigin(), F::ProjSim.GetOrigin(), -tProjInfo.m_vHull, tProjInfo.m_vHull, nMask, &filter, &trace);
	if (trace.startsolid)
		return;

	int iTicks = TIME_TO_TICKS(std::min(tProjInfo.m_flLifetime, 10.f));

	Vec3 vNew = F::ProjSim.GetOrigin();
	for (int n = 1; n <= iTicks; n++)
	{
		F::ProjSim.RunTick(tProjInfo);

		Vec3 vOld = vNew; vNew = F::ProjSim.GetOrigin();
		SDK::TraceHull(vOld, vNew, -tProjInfo.m_vHull, tProjInfo.m_vHull, nMask, &filter, &trace);
		F::ProjSim.SetupTrace(filter, nMask, pWeapon, n, bInterp);
		if (trace.DidHit())
		{
			pNormal = &trace.plane.normal;
			break;
		}
	}
	if (tProjInfo.m_vPath.empty())
		return;

	tProjInfo.m_vPath.push_back(trace.endpos);

	float flRadius = 0.f;
	Vec3 vEndPos = trace.endpos;
	if (Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Enabled)
	{
		switch (pWeapon->GetWeaponID())
		{
		case TF_WEAPON_ROCKETLAUNCHER:
		case TF_WEAPON_ROCKETLAUNCHER_DIRECTHIT:
		case TF_WEAPON_PARTICLE_CANNON:
			if (Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Rockets)
				flRadius = TF_ROCKET_RADIUS;
			break;
		case TF_WEAPON_PIPEBOMBLAUNCHER:
			if (Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Stickies)
				flRadius = TF_ROCKET_RADIUS;
			break;
		case TF_WEAPON_GRENADELAUNCHER:
			if (Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Pipes)
				flRadius = TF_ROCKET_RADIUS;
			break;
		case TF_WEAPON_FLAREGUN:
		case TF_WEAPON_FLAREGUN_REVENGE:
			if (Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Flares && pWeapon->As<CTFFlareGun>()->GetFlareGunType() == FLAREGUN_SCORCHSHOT)
				flRadius = TF_FLARE_DET_RADIUS;
		}

		if (flRadius)
		{
			flRadius = SDK::AttribHookValue(flRadius, "mult_explosion_radius", pWeapon);
			switch (pWeapon->GetWeaponID())
			{
			case TF_WEAPON_ROCKETLAUNCHER:
			case TF_WEAPON_ROCKETLAUNCHER_DIRECTHIT:
			case TF_WEAPON_PARTICLE_CANNON:
				if (pPlayer->InCond(TF_COND_BLASTJUMPING) && SDK::AttribHookValue(1.f, "rocketjump_attackrate_bonus", pWeapon) != 1.f)
					flRadius *= 0.8f;
				if (pNormal)
					vEndPos += *pNormal;
			}
		}
	}

	if (bInterp)
	{
		float flDistanceSqr = powf(500.f, 2);
		if (Vars::Visuals::Simulation::ProjectileCamera.Value && !I::EngineVGui->IsGameUIVisible() && pPlayer->m_vecOrigin().DistToSqr(trace.endpos) > flDistanceSqr)
		{
			CGameTrace cameraTrace = {};

			auto vAngles = Math::CalcAngle(trace.startpos, trace.endpos);
			Vec3 vForward; Math::AngleVectors(vAngles, &vForward);
			SDK::Trace(trace.endpos, trace.endpos - vForward * 500.f, MASK_SOLID, &filter, &cameraTrace);

			F::CameraWindow.m_bShouldDraw = true;
			F::CameraWindow.m_vCameraOrigin = cameraTrace.endpos;
			F::CameraWindow.m_vCameraAngles = vAngles;
		}

		if (Vars::Visuals::Simulation::TrajectoryPath.Value)
		{
			H::Draw.RenderPath(tProjInfo.m_vPath, Vars::Colors::TrajectoryPathIgnoreZ.Value, false, Vars::Visuals::Simulation::TrajectoryPath.Value);
			H::Draw.RenderPath(tProjInfo.m_vPath, Vars::Colors::TrajectoryPath.Value, true, Vars::Visuals::Simulation::TrajectoryPath.Value);

			if (Vars::Visuals::Simulation::Box.Value && pNormal)
			{
				const float flSize = std::max(tProjInfo.m_vHull.Min(), 1.f);
				const Vec3 vSize = { 1.f, flSize, flSize };
				Vec3 vAngles = Math::VectorAngles(*pNormal);

				H::Draw.RenderWireframeBox(trace.endpos, -vSize, vSize, vAngles, Vars::Colors::TrajectoryPathIgnoreZ.Value);
				H::Draw.RenderWireframeBox(trace.endpos, -vSize, vSize, vAngles, Vars::Colors::TrajectoryPath.Value, true);
			}
		}

		if (flRadius)
		{
			if (!(Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Sphere))
			{
				auto vPoints = SplashTrace(vEndPos, flRadius, pNormal ? *pNormal : Vec3(0, 0, 1), Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Trace);
				H::Draw.RenderPath(vPoints, Vars::Colors::SplashRadiusIgnoreZ.Value, false, Vars::Visuals::Path::StyleEnum::Line);
				H::Draw.RenderPath(vPoints, Vars::Colors::SplashRadius.Value, true, Vars::Visuals::Path::StyleEnum::Line);
			}
			else
			{
				H::Draw.RenderSphere(vEndPos, flRadius, 36, 36, Vars::Colors::SplashRadiusIgnoreZ.Value);
				H::Draw.RenderSphere(vEndPos, flRadius, 36, 36, Vars::Colors::SplashRadius.Value, true);
			}
		}
	}
	else if (Vars::Visuals::Simulation::ShotPath.Value)
	{
		G::BoxStorage.clear();
		G::PathStorage.clear();

		if (Vars::Colors::ShotPathIgnoreZ.Value.a)
			G::PathStorage.emplace_back(tProjInfo.m_vPath, -float(tProjInfo.m_vPath.size()) - TIME_TO_TICKS(F::Backtrack.GetReal()), Vars::Colors::ShotPathIgnoreZ.Value, Vars::Visuals::Simulation::ShotPath.Value);
		if (Vars::Colors::ShotPath.Value.a)
			G::PathStorage.emplace_back(tProjInfo.m_vPath, -float(tProjInfo.m_vPath.size()) - TIME_TO_TICKS(F::Backtrack.GetReal()), Vars::Colors::ShotPath.Value, Vars::Visuals::Simulation::ShotPath.Value, true);

		if (Vars::Visuals::Simulation::Box.Value && pNormal)
		{
			const float flSize = std::max(tProjInfo.m_vHull.x, 1.f);
			const Vec3 vSize = { 1.f, flSize, flSize };
			Vec3 vAngles = Math::VectorAngles(*pNormal);

			if (Vars::Colors::ShotPathIgnoreZ.Value.a)
				G::BoxStorage.emplace_back(trace.endpos, -vSize, vSize, vAngles, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Vars::Colors::ShotPathIgnoreZ.Value, Color_t(0, 0, 0, 0));
			if (Vars::Colors::ShotPath.Value.a)
				G::BoxStorage.emplace_back(trace.endpos, -vSize, vSize, vAngles, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Vars::Colors::ShotPath.Value, Color_t(0, 0, 0, 0), true);
		}

		if (flRadius)
		{
			if (!(Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Sphere))
			{
				std::vector<Vec3> vPoints = SplashTrace(vEndPos, flRadius, pNormal ? *pNormal : Vec3(0, 0, 1), Vars::Visuals::Simulation::SplashRadius.Value & Vars::Visuals::Simulation::SplashRadiusEnum::Trace);
				if (Vars::Colors::SplashRadiusIgnoreZ.Value.a)
					G::PathStorage.emplace_back(vPoints, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Vars::Colors::SplashRadiusIgnoreZ.Value, Vars::Visuals::Path::StyleEnum::Line);
				if (Vars::Colors::SplashRadius.Value.a)
					G::PathStorage.emplace_back(vPoints, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Vars::Colors::SplashRadius.Value, Vars::Visuals::Path::StyleEnum::Line, true);
			}
			else
			{
				if (Vars::Colors::SplashRadiusIgnoreZ.Value.a)
					G::SphereStorage.emplace_back(vEndPos, flRadius, 36, 36, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Color_t(), Vars::Colors::SplashRadiusIgnoreZ.Value);
				if (Vars::Colors::SplashRadius.Value.a)
					G::SphereStorage.emplace_back(vEndPos, flRadius, 36, 36, I::GlobalVars->curtime + TICKS_TO_TIME(tProjInfo.m_vPath.size()) + F::Backtrack.GetReal(), Color_t(), Vars::Colors::SplashRadius.Value, true);
			}
		}
	}
}

void CVisuals::DrawPickupTimers()
{
	if (!F::Groups.GroupsActive())
		return;

	for (auto it = m_vPickups.begin(); it != m_vPickups.end();)
	{
		auto& tPickup = *it;

		Group_t* pGroup = nullptr;
		float flTime = tPickup.m_flTime - I::GlobalVars->curtime;
		if (!F::Groups.GetGroup(tPickup.m_iType, pGroup) || !pGroup->m_bPickupTimer || flTime < 0.f)
		{
			it = m_vPickups.erase(it);
			continue;
		}

		Vec3 vScreen;
		if (SDK::W2S(tPickup.m_vLocation, vScreen))
		{
			if (MoonlitHud::Enabled()) MoonlitHud::Pill(vScreen.x, vScreen.y, std::format("{:.1f}s", flTime), pGroup->m_tColor, MoonlitHud::Detail(), true);
			else H::Draw.StringOutlined(H::Fonts.GetFont(FONT_ESP), vScreen.x, vScreen.y, pGroup->m_tColor, Vars::Menu::Theme::Background.Value, ALIGN_CENTER, std::format("{:.1f}s", flTime).c_str());
		}

		it++;
	}
}



std::vector<DrawBox_t> CVisuals::GetHitboxes(matrix3x4* aBones, CBaseAnimating* pEntity, std::vector<int> vHitboxes, int iTarget)
{
	if (!Vars::Colors::BoneHitboxEdge.Value.a && !Vars::Colors::BoneHitboxFace.Value.a && !Vars::Colors::BoneHitboxEdgeIgnoreZ.Value.a && !Vars::Colors::BoneHitboxFaceIgnoreZ.Value.a
		&& !Vars::Colors::TargetHitboxEdge.Value.a && !Vars::Colors::TargetHitboxFace.Value.a && !Vars::Colors::TargetHitboxEdgeIgnoreZ.Value.a && !Vars::Colors::TargetHitboxFaceIgnoreZ.Value.a)
		return {};

	std::vector<DrawBox_t> vBoxes = {};

	auto pSet = pEntity->GetHitboxSet();
	if (!pSet)
		return vBoxes;

	if (vHitboxes.empty())
	{
		for (int nHitbox = 0; nHitbox < pSet->numhitboxes; nHitbox++)
			vHitboxes.push_back(nHitbox);
	}

	for (int nHitbox : vHitboxes)
	{
		auto pBox = pSet->pHitbox(nHitbox);
		if (!pBox)
			continue;

		bool bTargeted = nHitbox == iTarget;
		Vec3 vAngle; Math::MatrixAngles(aBones[pBox->bone], vAngle);
		Vec3 vOrigin; Math::GetMatrixOrigin(aBones[pBox->bone], vOrigin);
		Vec3 vMins = pBox->bbmin * pEntity->m_flModelScale();
		Vec3 vMaxs = pBox->bbmax * pEntity->m_flModelScale();

		if (Vars::Debug::Info.Value)
		{
			float flBoneScale = Vars::Aimbot::Hitscan::BoneSizeMinimumScale.Value;
			float flBoneSubtract = Vars::Aimbot::Hitscan::BoneSizeSubtract.Value;

			if (F::AimbotGlobal.ShouldMultipoint(pEntity, nHitbox, Vars::Aimbot::Hitscan::MultipointHitboxes.Value))
				flBoneScale = std::max(flBoneScale, Vars::Aimbot::Hitscan::MultipointScale.Value / 100.f);

			vMins = (pBox->bbmin + flBoneSubtract / pEntity->m_flModelScale()) * flBoneScale * pEntity->m_flModelScale();
			vMaxs = (pBox->bbmax - flBoneSubtract / pEntity->m_flModelScale()) * flBoneScale * pEntity->m_flModelScale();
		}

		Color_t tEdge = bTargeted ? Vars::Colors::TargetHitboxEdgeIgnoreZ.Value : Vars::Colors::BoneHitboxEdgeIgnoreZ.Value;
		Color_t tFace = bTargeted ? Vars::Colors::TargetHitboxFaceIgnoreZ.Value : Vars::Colors::BoneHitboxFaceIgnoreZ.Value;
		if (tEdge.a || tFace.a)
			vBoxes.emplace_back(vOrigin, vMins, vMaxs, vAngle, I::GlobalVars->curtime + Vars::Visuals::Hitbox::DrawDuration.Value, tEdge, tFace);

		tEdge = bTargeted ? Vars::Colors::TargetHitboxEdge.Value : Vars::Colors::BoneHitboxEdge.Value;
		tFace = bTargeted ? Vars::Colors::TargetHitboxFace.Value : Vars::Colors::BoneHitboxFace.Value;
		if (tEdge.a || tFace.a)
			vBoxes.emplace_back(vOrigin, vMins, vMaxs, vAngle, I::GlobalVars->curtime + Vars::Visuals::Hitbox::DrawDuration.Value, tEdge, tFace, true);
	}

	return vBoxes;
}

void CVisuals::DrawExtrapolationGuide()
{
	const auto& guide = G::ExtrapolationGuide;
	if (!Vars::Aimbot::General::AimType.Value || !Vars::Aimbot::Hitscan::Extrapolation.Value
		|| !Vars::Aimbot::Hitscan::ExtrapolationGuide.Value || !AimPreview::Fresh(guide.tick, I::GlobalVars->tickcount) || guide.seconds <= 0.f)
		return;
	auto* target = reinterpret_cast<CBaseEntity*>(guide.target.Get());
	if (!target || !target->IsPlayer() || target->IsDormant()) return;
	auto* player = target->As<CTFPlayer>();
	if (!player->IsAlive()) return;
	Vec3 screenRecorded, screenEstimated;
	if (!SDK::W2S(guide.start, screenRecorded) || !SDK::W2S(guide.end, screenEstimated)) return;

	auto* set = player->GetHitboxSet();
	auto& bones = player->m_CachedBoneData();
	Vec3 anchor = player->GetAbsOrigin() + (player->m_vecMins() + player->m_vecMaxs()) * 0.5f;
	if (set && guide.hitbox >= 0 && guide.hitbox < set->numhitboxes)
	{
		auto* box = set->pHitbox(guide.hitbox);
		if (box && box->bone >= 0 && box->bone < bones.Count())
			Math::VectorTransform((box->bbmin + box->bbmax) * 0.5f, bones[box->bone], anchor);
	}
	Vec3 screenAnchor;
	if (!SDK::W2S(anchor, screenAnchor)) return;
	std::vector<ExtrapolationEdge::Point> outline;
	// Project the whole posed hitbox envelope, not a 3D face that can project
	// into the middle of the silhouette. Include collision bounds as a fallback.
	const auto addBox = [&](const Vec3& mins, const Vec3& maxs, const matrix3x4* transform)
	{
		for (int corner = 0; corner < 8; ++corner)
		{
			Vec3 point = { corner & 1 ? maxs.x : mins.x, corner & 2 ? maxs.y : mins.y, corner & 4 ? maxs.z : mins.z };
			if (transform) point = Math::VectorTransform(point, *transform);
			else point += player->GetAbsOrigin();
			Vec3 screen;
			if (SDK::W2S(point, screen)) outline.push_back({ screen.x, screen.y });
		}
	};
	if (set)
		for (int index = 0; index < set->numhitboxes; ++index)
		{
			auto* box = set->pHitbox(index);
			if (box && box->bone >= 0 && box->bone < bones.Count())
				addBox(box->bbmin, box->bbmax, &bones[box->bone]);
		}
	addBox(player->m_vecMins(), player->m_vecMaxs(), nullptr);
	const auto layout = ExtrapolationEdge::Place({ screenAnchor.x, screenAnchor.y },
		{ screenEstimated.x - screenRecorded.x, screenEstimated.y - screenRecorded.y }, outline);
	if (!layout.valid) return;

	const Color_t colour(int(Workspace::Accent[0] * 255), int(Workspace::Accent[1] * 255), int(Workspace::Accent[2] * 255), 255);
	const Color_t shadow(0, 0, 0, 220);
	// Screen overlay: visible through both geometry and players. Both endpoints
	// share an offset; this is a displacement indicator, NOT a world shot marker.
	const auto stroke = [&](ExtrapolationEdge::Point from, ExtrapolationEdge::Point to)
	{
		H::Draw.Line(int(from.x), int(from.y) + 1, int(to.x), int(to.y) + 1, shadow);
		H::Draw.Line(int(from.x), int(from.y), int(to.x), int(to.y), colour);
	};
	const auto mark = [&](ExtrapolationEdge::Point point, float size)
	{
		stroke({ point.x - layout.normal.x * size, point.y - layout.normal.y * size },
			{ point.x + layout.normal.x * size, point.y + layout.normal.y * size });
	};
	stroke(layout.start, layout.end);
	mark(layout.start, 3.f);
	for (int tick = 1; tick <= 32 && TICKS_TO_TIME(tick) < guide.seconds; ++tick)
	{
		const float fraction = TICKS_TO_TIME(tick) / guide.seconds;
		mark({ layout.start.x + (layout.end.x - layout.start.x) * fraction,
			layout.start.y + (layout.end.y - layout.start.y) * fraction }, 3.f);
	}
	mark(layout.end, 5.f);
}

void CVisuals::DrawEffects()
{
	for (auto& tLine : G::LineStorage)
	{
		if (tLine.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderLine(tLine.m_paOrigin.first, tLine.m_paOrigin.second, tLine.m_tColor, tLine.m_bZBuffer);
	}
	for (auto& tPath : G::PathStorage)
	{
		bool bTimed = tPath.m_flTime < 0.f;
		if (!bTimed && tPath.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderPath(tPath.m_vPath, tPath.m_tColor, tPath.m_bZBuffer, tPath.m_iStyle, tPath.m_flTime);
	}
	for (auto& tBox : G::BoxStorage)
	{
		if (tBox.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderBox(tBox.m_vOrigin, tBox.m_vMins, tBox.m_vMaxs, tBox.m_vAngles, tBox.m_tColorFace, tBox.m_bZBuffer);
		H::Draw.RenderWireframeBox(tBox.m_vOrigin, tBox.m_vMins, tBox.m_vMaxs, tBox.m_vAngles, tBox.m_tColorEdge, tBox.m_bZBuffer);
	}
	if (Vars::Aimbot::General::AimType.Value
		&& (Vars::Visuals::Hitbox::BoundsEnabled.Value & Vars::Visuals::Hitbox::BoundsEnabledEnum::PredictDuringCooldown))
		for (const auto& box : G::CooldownBoxStorage)
		{
			if (box.m_flTime < I::GlobalVars->curtime) continue;
			H::Draw.RenderBox(box.m_vOrigin, box.m_vMins, box.m_vMaxs, box.m_vAngles, box.m_tColorFace, box.m_bZBuffer);
			H::Draw.RenderWireframeBox(box.m_vOrigin, box.m_vMins, box.m_vMaxs, box.m_vAngles, box.m_tColorEdge, box.m_bZBuffer);
		}
	for (auto& tSphere : G::SphereStorage)
	{
		if (tSphere.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderSphere(tSphere.m_vOrigin, tSphere.m_flRadius, tSphere.m_nTheta, tSphere.m_nPhi, tSphere.m_tColorFace, tSphere.m_bZBuffer);
		H::Draw.RenderWireframeSphere(tSphere.m_vOrigin, tSphere.m_flRadius, tSphere.m_nTheta, tSphere.m_nPhi, tSphere.m_tColorEdge, tSphere.m_bZBuffer);
	}
	for (auto& tSwept : G::SweptStorage)
	{
		if (tSwept.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderWireframeSweptBox(tSwept.m_paOrigin.first, tSwept.m_paOrigin.second, tSwept.m_vMins, tSwept.m_vMaxs, tSwept.m_vAngles, tSwept.m_tColor, tSwept.m_bZBuffer);
	}
	for (auto& tTriangle : G::TriangleStorage)
	{
		if (tTriangle.m_flTime < I::GlobalVars->curtime)
			continue;

		H::Draw.RenderTriangle(tTriangle.m_aOrigin[0], tTriangle.m_aOrigin[1], tTriangle.m_aOrigin[2], tTriangle.m_tColor, tTriangle.m_bZBuffer);
	}
	for (auto& [tPath, _] :F::Aimbot.m_mRealPaths | std::views::values)
	{
		H::Draw.RenderPath(tPath.m_vPath, Vars::Colors::RealPath.Value, true, tPath.m_iStyle, tPath.m_flTime);
		H::Draw.RenderPath(tPath.m_vPath, Vars::Colors::RealPathIgnoreZ.Value, false, tPath.m_iStyle, tPath.m_flTime);
	}

	for (auto& tSightline : m_vSightLines)
		H::Draw.RenderLine(tSightline.m_vStart, tSightline.m_vEnd, tSightline.m_tColor, tSightline.m_bZBuffer);

	for (auto& [pEntity, tProjectile] : m_mProjectiles)
	{
		bool bZBuffer = !(tProjectile.m_iFlags & TrajectoryEnum::IgnoreZ);
		bool bPredict = tProjectile.m_iFlags & TrajectoryEnum::Predict && tProjectile.m_vPath.size() && tProjectile.m_flTime;

		if (bPredict && tProjectile.m_iFlags & TrajectoryEnum::Path)
			H::Draw.RenderPath(tProjectile.m_vPath, tProjectile.m_tColor, bZBuffer, Vars::Visuals::Path::StyleEnum::Line, tProjectile.m_flTime);

		if (tProjectile.m_iFlags & TrajectoryEnum::Radius)
		{
			Vec3 vOrigin = bPredict ? tProjectile.m_vPath.back() : pEntity->GetAbsOrigin();
			Vec3 vNormal = bPredict ? tProjectile.m_vNormal : Vec3(0, 0, 1);

			if (!(tProjectile.m_iFlags & TrajectoryEnum::Sphere))
			{
				auto vPoints = SplashTrace(vOrigin, tProjectile.m_flRadius, vNormal, tProjectile.m_iFlags & TrajectoryEnum::Trace);
				H::Draw.RenderPath(vPoints, tProjectile.m_tColor, bZBuffer, Vars::Visuals::Path::StyleEnum::Line);
			}
			else
				H::Draw.RenderSphere(vOrigin, tProjectile.m_flRadius, 36, 36, tProjectile.m_tColor, bZBuffer);
		}
	}

	DrawHitboxes();
}

static std::vector<DrawBox_t> s_vHitboxes = {}, s_vLocalHitboxes = {};
static bool s_bHitboxes = false, s_bBounds = false, s_bBoxesHeadOnly = false, s_bBoxesNoAngles = false;
void CVisuals::DrawHitboxes(int iStore)
{
	if (!Vars::Debug::DrawHitboxes.Value)
		return;

	switch (iStore)
	{
	case 0:
	{
		for (auto& tBox : s_vHitboxes)
			H::Draw.RenderWireframeBox(tBox.m_vOrigin, tBox.m_vMins, tBox.m_vMaxs, tBox.m_vAngles, tBox.m_tColorEdge, tBox.m_bZBuffer);
		for (auto& tBox : s_vLocalHitboxes)
			H::Draw.RenderWireframeBox(tBox.m_vOrigin, tBox.m_vMins, tBox.m_vMaxs, tBox.m_vAngles, tBox.m_tColorEdge, tBox.m_bZBuffer);
		break;
	}
	case 1:
	{
		s_vHitboxes.clear();

		bool bLocalhost = SDK::IsLoopback();
		for (auto& pEntity : H::Entities.GetGroup(EntityEnum::PlayerAll))
		{
			auto pPlayer = pEntity->As<CTFPlayer>();
			if (pPlayer->entindex() == I::EngineClient->GetLocalPlayer() && !I::Input->CAM_IsThirdPerson() || !pPlayer->IsAlive())
				continue;

			if (auto aBones = F::Backtrack.GetBones(pEntity))
			{
				auto vBoxes = GetHitboxes(aBones, pPlayer);
				for (auto& tBox : vBoxes)
					tBox.m_tColorEdge = { 255, 255, 255, 255 };
				s_vHitboxes.insert(s_vHitboxes.end(), vBoxes.begin(), vBoxes.end());
			}
			if (bLocalhost) // this ignores latency, beware!!
			{
				s_bHitboxes = true;
				if (auto pPlayer2 = S::UTIL_PlayerByIndex.Call<void*>(pPlayer->entindex()))
					S::CBaseAnimating_DrawServerHitboxes.Call<void>(pPlayer2, 0.f, true);
				s_bHitboxes = false;
			}
		}
		break;
	}
	case 2:
	{
		s_vLocalHitboxes.clear();

		if (!I::Input->CAM_IsThirdPerson())
			break;

		auto pLocal = H::Entities.GetLocal();
		if (!pLocal || !pLocal->SetupBones(F::Backtrack.m_tRecord.m_aBones, MAXSTUDIOBONES, BONE_USED_BY_ANYTHING, pLocal->m_flSimulationTime()))
			break;

		auto vBoxes = GetHitboxes(F::Backtrack.m_tRecord.m_aBones, pLocal);
		for (auto& tBox : vBoxes)
			tBox.m_tColorEdge = { 255, 255, 255, 255 };
		s_vLocalHitboxes.insert(s_vLocalHitboxes.end(), vBoxes.begin(), vBoxes.end());
	}
	}
}

MAKE_HOOK(CBaseAnimating_DrawServerHitboxes, S::CBaseAnimating_DrawServerHitboxes(), void,
	void* rcx, float duration, bool monocolor)
{
	DEBUG_RETURN(CBaseAnimating_DrawServerHitboxes, rcx, duration, monocolor);

	if (s_bBoxesHeadOnly)
		monocolor = false;

	CALL_ORIGINAL(rcx, duration, monocolor);
}

MAKE_HOOK(NDebugOverlay_BoxAngles, S::NDebugOverlay_BoxAngles(), void,
	Vector& origin, Vector& mins, Vector& maxs, QAngle& angles, int r, int g, int b, int a, float duration)
{
	DEBUG_RETURN(NDebugOverlay_BoxAngles, origin, mins, maxs, angles, r, g, b, a, duration);

	if (s_bBoxesHeadOnly)
	{
		const auto dwRetAddr = uintptr_t(_ReturnAddress());
		const auto dwDesired = S::CBaseAnimating_DrawServerHitboxes_BoxAngles_Call();

		if (dwRetAddr == dwDesired && (r != 255 || g != 127 || b != 127))
			return;
	}

	if (s_bBoxesNoAngles)
		angles = {};

	if (s_bHitboxes)
	{
		s_vHitboxes.emplace_back(origin, mins, maxs, angles, 0, Color_t(r, g, b, 255 - a), Color_t(0, 0, 0, 0), true);
		return;
	}

	CALL_ORIGINAL(origin, mins, maxs, angles, r, g, b, a, duration);
}



void CVisuals::FOV(CTFPlayer* pLocal, CViewSetup* pView)
{
	static auto fov_desired = H::ConVars.FindVar("fov_desired");
	static auto default_fov = H::ConVars.FindVar("default_fov");
	bool bZoomed = pLocal->InCond(TF_COND_ZOOMED);

	float flRegularFOV = fov_desired->GetFloat();
	float flZoomFOV = TF_WEAPON_ZOOM_FOV;

	float flRegularOverride = Vars::Visuals::UI::FieldOfView.Value;
	float flZoomOverride = Vars::Visuals::UI::ZoomFieldOfView.Value;
	if (SDK::CleanScreenshot())
		flRegularOverride = flZoomOverride = 0.f;

	if (flRegularOverride || flZoomOverride)
	{
		pView->fov = !bZoomed ? (flRegularOverride ? flRegularOverride : flRegularFOV) : (flZoomOverride ? flZoomOverride : flZoomFOV);
		if (!I::Prediction->InPrediction() && pLocal->m_flFOVRate() && !pLocal->InCond(TF_COND_HALLOWEEN_KART))
		{
			float flDeltaTime = (TICKS_TO_TIME(pLocal->m_nFinalPredictedTick()) - pLocal->m_flFOVTime() + TICKS_TO_TIME(I::GlobalVars->interpolation_amount)) / pLocal->m_flFOVRate();
			if (flDeltaTime < 1.f)
			{
				float flFrom = flRegularOverride && pLocal->m_iFOVStart() == flRegularFOV ? flRegularOverride
					: flZoomOverride && pLocal->m_iFOVStart() == flZoomFOV ? flZoomOverride
					: pLocal->m_iFOVStart();
				float flTo = pView->fov;
				if (flFrom != flTo)
					pView->fov = Math::SimpleSplineRemapVal(flDeltaTime, 0.f, 1.f, flFrom, flTo);
			}
		}
	}

	G::FOV = pView->fov;
	if (pLocal->IsAlive())
	{
		pLocal->m_iFOV() = ceilf(pView->fov);
		pLocal->m_iDefaultFOV() = ceilf(std::max(flRegularOverride, flRegularFOV));
		if (default_fov && default_fov->GetInt() != pLocal->m_iDefaultFOV())
		{
			if (!m_bStoredDefaultFOV)
				m_flOriginalDefaultFOV = default_fov->GetFloat(), m_bStoredDefaultFOV = true;
			default_fov->SetValue(pLocal->m_iDefaultFOV());
		}
	}
}

void CVisuals::ThirdPerson(CTFPlayer* pLocal, CViewSetup* pView)
{
	if (!pLocal->IsAlive() || F::Spectate.HasTarget())
		return I::Input->CAM_ToFirstPerson();

	const bool bForce = pLocal->IsTaunting() || pLocal->IsAGhost() || pLocal->InCond(TF_COND_HALLOWEEN_KART) || pLocal->InCond(TF_COND_STUNNED) && pLocal->m_iStunFlags() & (TF_STUN_CONTROLS | TF_STUN_LOSER_STATE);
	//if (bForce)
	//	return;

	if (Vars::Visuals::Thirdperson::Enabled.Value && !SDK::CleanScreenshot() || bForce)
		I::Input->CAM_ToThirdPerson();
	else
		I::Input->CAM_ToFirstPerson();
	pLocal->ThirdPersonSwitch();

	static auto cam_ideallag = H::ConVars.FindVar("cam_ideallag");
	if (cam_ideallag && cam_ideallag->GetFloat() != 0.f)
	{
		if (!m_bStoredCamIdealLag)
			m_flOriginalCamIdealLag = cam_ideallag->GetFloat(), m_bStoredCamIdealLag = true;
		cam_ideallag->SetValue(0.f);
	}

	if (I::Input->CAM_IsThirdPerson())
	{	// thirdperson offset
		Vec3 vForward, vRight, vUp; Math::AngleVectors(pView->angles, &vForward, &vRight, &vUp);

		Vec3 vOffset;
		float flScale = Vars::Visuals::Thirdperson::Scale.Value ? pLocal->m_flModelScale() : 1.f;
		vOffset += vRight * Vars::Visuals::Thirdperson::Right.Value * flScale;
		vOffset += vUp * Vars::Visuals::Thirdperson::Up.Value * flScale;
		vOffset -= vForward * Vars::Visuals::Thirdperson::Distance.Value * flScale;

		Vec3 vOrigin = pLocal->GetEyePosition(); //pView->origin
		Vec3 vStart = vOrigin;
		Vec3 vEnd = vOrigin + vOffset;

		if (Vars::Visuals::Thirdperson::Collide.Value)
		{
			float flHull = 9.f * flScale;
			Vec3 vMins = { -flHull, -flHull, -flHull }, vMaxs = { flHull, flHull, flHull };

			CGameTrace trace = {};
			CTraceFilterWorldAndPropsOnly filter = {};
			SDK::TraceHull(vStart, vEnd, vMins, vMaxs, MASK_SOLID, &filter, &trace);
			vEnd = trace.endpos;
		}

		pView->origin = vEnd;
	}
}

void CVisuals::Event(IGameEvent* pEvent, uint32_t uHash)
{
	switch (uHash)
	{
	case FNV1A::Hash32Const("player_hurt"):
	{
		bool bBones = Vars::Visuals::Hitbox::BonesEnabled.Value & Vars::Visuals::Hitbox::BonesEnabledEnum::OnHit;
		bool bBounds = Vars::Visuals::Hitbox::BoundsEnabled.Value & Vars::Visuals::Hitbox::BoundsEnabledEnum::OnHit;
		if (!bBones && !bBounds)
			return;

		if (I::EngineClient->GetPlayerForUserID(pEvent->GetInt("attacker")) != I::EngineClient->GetLocalPlayer())
			return;

		int iVictim = I::EngineClient->GetPlayerForUserID(pEvent->GetInt("userid"));
		auto pEntity = I::ClientEntityList->GetClientEntity(iVictim)->As<CBaseAnimating>();
		if (!pEntity || iVictim == I::EngineClient->GetLocalPlayer())
			return;

		switch (G::PrimaryWeaponType)
		{
		case EWeaponType::HITSCAN:
		case EWeaponType::MELEE:
		{
			if (!bBones)
				return;

			auto aBones = F::Backtrack.GetBones(pEntity);
			if (!aBones)
				return;

			auto vBoxes = GetHitboxes(aBones, pEntity);
			G::BoxStorage.insert(G::BoxStorage.end(), vBoxes.begin(), vBoxes.end());

			return;
		}
		case EWeaponType::PROJECTILE:
		{
			if (!bBounds)
				return;

			if (Vars::Colors::BoundHitboxEdgeIgnoreZ.Value.a || Vars::Colors::BoundHitboxFaceIgnoreZ.Value.a)
				G::BoxStorage.emplace_back(pEntity->m_vecOrigin(), pEntity->m_vecMins(), pEntity->m_vecMaxs(), Vec3(), I::GlobalVars->curtime + Vars::Visuals::Hitbox::DrawDuration.Value, Vars::Colors::BoundHitboxEdgeIgnoreZ.Value, Vars::Colors::BoundHitboxFaceIgnoreZ.Value);
			if (Vars::Colors::BoundHitboxEdge.Value.a || Vars::Colors::BoundHitboxFace.Value.a)
				G::BoxStorage.emplace_back(pEntity->m_vecOrigin(), pEntity->m_vecMins(), pEntity->m_vecMaxs(), Vec3(), I::GlobalVars->curtime + Vars::Visuals::Hitbox::DrawDuration.Value, Vars::Colors::BoundHitboxEdge.Value, Vars::Colors::BoundHitboxFace.Value, true);
		}
		}

		return;
	}
	case FNV1A::Hash32Const("item_pickup"):
	{
		auto pEntity = I::ClientEntityList->GetClientEntity(I::EngineClient->GetPlayerForUserID(pEvent->GetInt("userid")))->As<CTFPlayer>();
		if (!pEntity || !pEntity->IsPlayer())
			return;

		int iType = 0;
		{
			const char* sItemName = pEvent->GetString("item");
			if (std::strstr(sItemName, "medkit"))
				iType = TargetsEnum::Health;
			else if (std::strstr(sItemName, "ammopack"))
				iType = TargetsEnum::Ammo;
		}

		Group_t* pGroup = nullptr;
		if (!F::Groups.GetGroup(iType, pGroup, pEntity) || !pGroup->m_bPickupTimer)
			return;

		m_vPickups.emplace_back(iType, I::GlobalVars->curtime + 10.f, pEntity->m_vecOrigin());
		return;
	}
	case FNV1A::Hash32Const("client_disconnect"):
	case FNV1A::Hash32Const("client_beginconnect"):
	case FNV1A::Hash32Const("game_newmap"):
	case FNV1A::Hash32Const("teamplay_round_start"):
	{
		ResetLocalAnimationQueue();
		m_vPickups.clear();

		G::LineStorage.clear();
		G::BoxStorage.clear();
		G::PathStorage.clear();
		G::SphereStorage.clear();
		G::SweptStorage.clear();
		G::TriangleStorage.clear();
	}
	}
}

void CVisuals::Store()
{
	m_vSightLines.clear();
	if (!F::Groups.GroupsActive())
		return;

	Group_t* pGroup;

	{
		std::unordered_mapset<CBaseEntity*> mProjectiles = {};

		for (auto pEntity : H::Entities.GetGroup(EntityEnum::WorldProjectile))
		{
			if (!F::Groups.GetGroup(pEntity, pGroup, false) || !(pGroup->m_iTrajectory & TrajectoryEnum::Enabled))
				continue;

			Projectile_t& tProjectile = m_mProjectiles[pEntity];
			mProjectiles[pEntity];

			ProjectileInfo tProjInfo = {};
			F::ProjSim.GetInfo(pEntity, tProjInfo);

			tProjectile.m_tColor = F::Groups.GetColor(pEntity, pGroup);
			tProjectile.m_iFlags = pGroup->m_iTrajectory;
			tProjectile.m_flRadius = F::AimbotProjectile.GetSplashRadius(pEntity, tProjInfo.m_pWeapon, tProjInfo.m_pOwner);

			if (tProjInfo.m_flVelocity < 1.5f)
			{
				if (!tProjInfo.m_flVelocity)
					tProjectile.m_flTime = 0.f;
				continue;
			}

			bool bUnreliable = false;
			switch (pEntity->GetClassID())
			{
			case ETFClassID::CBaseGrenade:
			case ETFClassID::CTFWeaponBaseGrenadeProj:
			case ETFClassID::CTFWeaponBaseMerasmusGrenade:
			case ETFClassID::CTFGrenadePipebombProjectile:
			case ETFClassID::CTFStunBall:
			case ETFClassID::CTFBall_Ornament:
			case ETFClassID::CTFProjectile_Jar:
			case ETFClassID::CTFProjectile_Cleaver:
			case ETFClassID::CTFProjectile_JarGas:
			case ETFClassID::CTFProjectile_JarMilk:
			case ETFClassID::CTFProjectile_SpellBats:
			case ETFClassID::CTFProjectile_SpellKartBats:
			case ETFClassID::CTFProjectile_SpellMeteorShower:
			case ETFClassID::CTFProjectile_SpellMirv:
			case ETFClassID::CTFProjectile_SpellPumpkin:
			case ETFClassID::CTFProjectile_SpellSpawnBoss:
			case ETFClassID::CTFProjectile_SpellSpawnHorde:
			case ETFClassID::CTFProjectile_SpellSpawnZombie:
			case ETFClassID::CTFProjectile_SpellTransposeTeleport:
			case ETFClassID::CTFProjectile_Throwable:
			case ETFClassID::CTFProjectile_ThrowableBreadMonster:
			case ETFClassID::CTFProjectile_ThrowableBrick:
			case ETFClassID::CTFProjectile_ThrowableRepel:
			case ETFClassID::CTFProjectile_SpellFireball:
			case ETFClassID::CTFProjectile_SpellLightningOrb:
				bUnreliable = true;
			}

			if (tProjectile.m_iFlags & TrajectoryEnum::Predict
				&& (tProjectile.m_vPath.size() <= 1 || bUnreliable && tProjectile.m_vPath.size() + int(tProjectile.m_flTime) > TIME_TO_TICKS(0.5f)))
			{
				if (!F::ProjSim.Initialize(tProjInfo, false, true))
					continue;

				CGameTrace trace = {};
				CTraceFilterCollideable filter = {};
				filter.pSkip = tProjInfo.m_pOwner;
				int nMask = MASK_SOLID;
				F::ProjSim.SetupTrace(filter, nMask, pEntity);

				int iTicks = TIME_TO_TICKS(std::min(tProjInfo.m_flLifetime, 10.f));

				Vec3 vNew = F::ProjSim.GetOrigin();
				for (int n = 1; n <= iTicks; n++)
				{
					F::ProjSim.RunTick(tProjInfo);

					Vec3 vOld = vNew; vNew = F::ProjSim.GetOrigin();
					SDK::TraceHull(vOld, vNew, -tProjInfo.m_vHull, tProjInfo.m_vHull, nMask, &filter, &trace);
					if (trace.DidHit())
					{
						tProjectile.m_vNormal = trace.plane.normal;
						if (trace.startsolid)
							tProjectile.m_vNormal = F::ProjSim.GetVelocity().Normalized();
						break;
					}
				}

				tProjectile.m_vPath = tProjInfo.m_vPath;
				tProjectile.m_flTime = -int(tProjInfo.m_vPath.size());
			}
		}

		for (auto it = m_mProjectiles.begin(); it != m_mProjectiles.end();)
		{
			if (!mProjectiles.contains(it->first))
				it = m_mProjectiles.erase(it);
			else
				++it;
		}
	}

	{
		std::unordered_map<IClientEntity*, Vec3> mDots = {};

		for (auto pEntity : H::Entities.GetGroup(EntityEnum::SniperDots))
		{
			if (auto pOwner = pEntity->m_hOwnerEntity().Get())
				mDots[pOwner] = pEntity->m_vecOrigin();
		}

		for (auto pEntity : H::Entities.GetGroup(EntityEnum::PlayerAll))
		{
			auto pPlayer = pEntity->As<CTFPlayer>();
			if (pPlayer->entindex() == I::EngineClient->GetLocalPlayer() || pPlayer->IsDormant()
				|| !F::Groups.GetGroup(pEntity, pGroup, false) || !(pGroup->m_iSightlines & SightlinesEnum::Enabled))
				continue;

			auto pWeapon = pPlayer->m_hActiveWeapon()->As<CTFWeaponBase>();
			if (!pPlayer->InCond(TF_COND_AIMING) ||
				!pWeapon || pWeapon->GetWeaponID() == TF_WEAPON_COMPOUND_BOW || pWeapon->GetWeaponID() == TF_WEAPON_MINIGUN)
				continue;

			Vec3 vShootPos = pPlayer->m_vecOrigin() + pPlayer->GetViewOffset();
			Vec3 vForward; Math::AngleVectors(pPlayer->GetEyeAngles(), &vForward);
			Vec3 vShootEnd = mDots.contains(pPlayer) ? mDots[pPlayer] : vShootPos + (vForward * 8192.f);

			CGameTrace trace = {};
			CTraceFilterHitscan filter = {};
			filter.pSkip = pPlayer;
			SDK::Trace(vShootPos, vShootEnd, MASK_SHOT, &filter, &trace);

			m_vSightLines.emplace_back(vShootPos, trace.endpos, F::Groups.GetColor(pPlayer, pGroup), !(pGroup->m_iSightlines & SightlinesEnum::IgnoreZ));
		}
	}
}

void CVisuals::Tick()
{
	for (auto& tPath : G::PathStorage)
	{
		if (tPath.m_flTime < 0.f)
			tPath.m_flTime = std::min(tPath.m_flTime + 1.f, 0.f);
	}

	PruneDrawStorages();

	for (auto& tProjectile : m_mProjectiles | std::views::values)
	{
		if (tProjectile.m_flTime < 0.f)
			tProjectile.m_flTime = std::min(tProjectile.m_flTime + 1.f, 0.f);
	}
}



// the storages are otherwise only cleared on map change / round start. expired entries are kept while the
// storages are small so that the debug "Restore visuals" buttons keep working, but pruned once they grow
void CVisuals::PruneDrawStorages()
{
	constexpr size_t iMaxEntries = 2048;
	const float flCurTime = I::GlobalVars->curtime;
	auto IsExpired = [&](auto& tEntry) { return tEntry.m_flTime < flCurTime; };

	if (G::LineStorage.size() > iMaxEntries)
		std::erase_if(G::LineStorage, IsExpired);
	if (G::PathStorage.size() > iMaxEntries) // negative times are tick-based and still active
		std::erase_if(G::PathStorage, [&](DrawPath_t& tPath) { return tPath.m_flTime >= 0.f && tPath.m_flTime < flCurTime; });
	if (G::BoxStorage.size() > iMaxEntries)
		std::erase_if(G::BoxStorage, IsExpired);
	if (G::SphereStorage.size() > iMaxEntries)
		std::erase_if(G::SphereStorage, IsExpired);
	if (G::SweptStorage.size() > iMaxEntries)
		std::erase_if(G::SweptStorage, IsExpired);
	if (G::TriangleStorage.size() > iMaxEntries)
		std::erase_if(G::TriangleStorage, IsExpired);
}

void CVisuals::RestoreConVars()
{
	if (m_bStoredDefaultFOV)
	{
		if (auto default_fov = H::ConVars.FindVar("default_fov"))
			default_fov->SetValue(m_flOriginalDefaultFOV);
		m_bStoredDefaultFOV = false;
	}
	if (m_bStoredCamIdealLag)
	{
		if (auto cam_ideallag = H::ConVars.FindVar("cam_ideallag"))
			cam_ideallag->SetValue(m_flOriginalCamIdealLag);
		m_bStoredCamIdealLag = false;
	}
}

void CVisuals::OverrideWorldTextures()
{
	auto uHash = FNV1A::Hash32(Vars::Visuals::World::WorldTexture.Value.c_str());
	switch (uHash)
	{
	case FNV1A::Hash32Const("Default"):
	case FNV1A::Hash32Const("Flat"):
		return;
	}

	KeyValues* kv = new KeyValues("LightmappedGeneric");
	if (!kv)
		return;

	switch (uHash)
	{
	case FNV1A::Hash32Const("Dev"):
		kv->SetString("$basetexture", "dev/dev_measuregeneric01b");
		break;
	case FNV1A::Hash32Const("Camo"):
		kv->SetString("$basetexture", "patterns/paint_strokes");
		break;
	case FNV1A::Hash32Const("Black"):
		kv->SetString("$basetexture", "patterns/combat/black");
		break;
	case FNV1A::Hash32Const("White"):
		kv->SetString("$basetexture", "patterns/combat/white");
		break;
	case FNV1A::Hash32Const("Gray"):
		kv->SetString("$basetexture", "vgui/white_additive");
		kv->SetString("$color2", "[0.12 0.12 0.15]");
		break;
	default:
		kv->SetString("$basetexture", Vars::Visuals::World::WorldTexture.Value.c_str());
	}

	for (auto h = I::MaterialSystem->FirstMaterial(); h != I::MaterialSystem->InvalidMaterial(); h = I::MaterialSystem->NextMaterial(h))
	{
		auto pMaterial = I::MaterialSystem->GetMaterial(h);
		if (!pMaterial || pMaterial->IsErrorMaterial() || !pMaterial->IsPrecached() || pMaterial->IsTranslucent() || pMaterial->IsAlphaTested() || pMaterial->IsSpriteCard())
			continue;

		std::string_view sName = pMaterial->GetName();
		std::string_view sGroup = pMaterial->GetTextureGroupName();
		if (!sGroup.starts_with(TEXTURE_GROUP_WORLD)
			|| sName.find("sky") != std::string_view::npos
			|| sName.find("water") != std::string_view::npos)
			continue;

		pMaterial->SetShaderAndParams(kv);
	}

	kv->DeleteThis(); // SetShaderAndParams copies the keyvalues
}

namespace
{
	RenderState::MaterialModulation<IMaterial> worldModulation, skyModulation;
}

static inline void ApplyModulation(Color_t tColor, bool bSky = false)
{
	for (auto h = I::MaterialSystem->FirstMaterial(); h != I::MaterialSystem->InvalidMaterial(); h = I::MaterialSystem->NextMaterial(h))
	{
		auto pMaterial = I::MaterialSystem->GetMaterial(h);
		if (!pMaterial || pMaterial->IsErrorMaterial() || !pMaterial->IsPrecached())
			continue;

		std::string_view sName = pMaterial->GetName();
		std::string_view sGroup = pMaterial->GetTextureGroupName();
		if (!bSky)
		{
			if (!sGroup.starts_with(TEXTURE_GROUP_WORLD)
				|| sName.starts_with("skybox/"))
				continue;
		}
		else
		{
			if (!sGroup.starts_with(TEXTURE_GROUP_SKYBOX)
				&& !sName.starts_with("skybox/"))
				continue;
		}

		(bSky ? skyModulation : worldModulation).Apply(pMaterial, tColor.r / 255.f, tColor.g / 255.f, tColor.b / 255.f);
	}
}

void CVisuals::Modulate()
{
	const bool bScreenshot = SDK::CleanScreenshot();
	const bool bWorldModulation = Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::World && !bScreenshot;
	const bool bSkyModulation = Vars::Visuals::World::Modulations.Value & Vars::Visuals::World::ModulationsEnum::Sky && !bScreenshot;

	bool bSetChanged, bColorChanged, bSkyChanged, bConnection;
	{
		static bool bStaticWorld = false, bStaticSky = false;
		const bool bLastWorld = bStaticWorld, bLastSky = bStaticSky;
		const bool bCurrWorld = bStaticWorld = bWorldModulation, bCurrSky = bStaticSky = bSkyModulation;
		bSetChanged = bCurrWorld != bLastWorld || bCurrSky != bLastSky;
	}
	{
		static Color_t tStaticWorld = {}, tStaticSky = {};
		const Color_t tLastWorld = tStaticWorld, tLastSky = tStaticSky;
		const Color_t tCurrWorld = tStaticWorld = Vars::Colors::WorldModulation.Value, tCurrSky = tStaticSky = Vars::Colors::SkyModulation.Value;
		bColorChanged = tCurrWorld != tLastWorld || tCurrSky != tLastSky;
	}
	{
		static uint32_t uStaticHash = 0;
		const uint32_t uLastHash = uStaticHash;
		const uint32_t uCurrHash = uStaticHash = FNV1A::Hash32(Vars::Visuals::World::SkyboxChanger.Value.c_str());
		bSkyChanged = uCurrHash != uLastHash;
	}
	{
		static bool bStaticConnected = false;
		const bool bLastConnected = bStaticConnected;
		const bool bCurrConnected = bStaticConnected = I::EngineClient->IsConnected() && I::EngineClient->IsInGame();
		bConnection = bCurrConnected == bLastConnected;
	}

	if (!bWorldModulation) worldModulation.Restore();
	if (!bSkyModulation) skyModulation.Restore();
	if (bSetChanged || bColorChanged || bSkyChanged || !bConnection
		|| (bWorldModulation && worldModulation.Empty()) || (bSkyModulation && skyModulation.Empty()))
	{
		if (bWorldModulation) ApplyModulation(Vars::Colors::WorldModulation.Value);
		if (bSkyModulation) ApplyModulation(Vars::Colors::SkyModulation.Value, true);
	}
}

void CVisuals::RestoreWorldModulation()
{
	worldModulation.Restore();
	skyModulation.Restore();
}

#ifdef WORLD_DEBUG
class CEntityEnumerator : public IPartitionEnumerator
{
public:
	IterationRetval_t EnumElement(IHandleEntity* pHandleEntity)
	{
		m_vEntities.push_back(pHandleEntity);
		return ITERATION_CONTINUE;
	}

	std::vector<IHandleEntity*>	m_vEntities = {};
};
#endif

void CVisuals::CreateMove(CTFPlayer* pLocal, CTFWeaponBase* pWeapon)
{
	if (Vars::Visuals::Simulation::ShotPath.Value && G::Attacking == 1 && !F::Aimbot.m_bRan)
	{
		switch (pWeapon->GetWeaponID())
		{
		case TF_WEAPON_BAT_WOOD:
		case TF_WEAPON_BAT_GIFTWRAP:
			if (!G::Throwing)
				break;
			[[fallthrough]];
		default:
			F::Visuals.ProjectileTrace(pLocal, pWeapon, false);
		}
	}

	bool bEffects = F::CritHack.ShouldForceEffects(pLocal);
	if (!bEffects && !pLocal->IsCritBoosted() && pLocal->m_pCritBoostSoundLoop())
		S::CTFPlayerShared_UpdateCritBoostEffect.Call<void>(pLocal->m_Shared(), kCritBoost_Ignore);
	else if (bEffects && !pLocal->m_pCritBoostSoundLoop())
	{
		int iOriginalCond = pLocal->m_nPlayerCondEx();
		pLocal->AddCond(TF_COND_CRITBOOSTED_USER_BUFF);
		S::CTFPlayerShared_UpdateCritBoostEffect.Call<void>(pLocal->m_Shared(), kCritBoost_Ignore);
		pLocal->m_nPlayerCondEx() = iOriginalCond;
	}
	
	static uint32_t uOldHashBeam = 0, uOldHashCharge = 0;
	auto uHashBeam = FNV1A::Hash32(Vars::Visuals::Effects::MedigunBeam.Value.c_str()), uHashCharge = FNV1A::Hash32(Vars::Visuals::Effects::MedigunCharge.Value.c_str());
	if (uOldHashBeam != uHashBeam || uOldHashCharge != uHashCharge)
	{
		if (pWeapon && pWeapon->GetWeaponID() == TF_WEAPON_MEDIGUN)
		{
			auto pMedigun = pWeapon->As<CWeaponMedigun>();
			pMedigun->UpdateEffects();
			pMedigun->StopChargeEffect(false);
			pMedigun->ManageChargeEffect();
		}

		uOldHashBeam = uHashBeam, uOldHashCharge = uHashCharge;
	}

	if (Vars::Visuals::Effects::SpellFootsteps.Value && (F::Ticks.m_bDoubletap || F::Ticks.m_bWarp))
		pLocal->FireEvent(pLocal->GetAbsOrigin(), QAngle(), 7001, nullptr);

	DrawHitboxes(2);

#ifdef WORLD_DEBUG
	if (auto pLocal = H::Entities.GetLocal(); Vars::World::Faces.Value && pLocal && I::Input->CAM_IsThirdPerson())
	{
		//float flRadius = 146.f + pLocal->GetSize().Length() / 2;
		//Vec3 vOrigin = pLocal->GetCenter();
		//Vec3 vMins = vOrigin - flRadius;
		//Vec3 vMaxs = vOrigin + flRadius;
		Vec3 vOrigin = pLocal->m_vecOrigin();
		Vec3 vMins = vOrigin + pLocal->m_vecMins();
		Vec3 vMaxs = vOrigin + pLocal->m_vecMaxs();

		G::LineStorage.clear(); G::BoxStorage.clear(); G::TriangleStorage.clear();
		G::BoxStorage.emplace_back(Vec3(), vMins, vMaxs, Vec3(), I::GlobalVars->curtime + 60.f, Color_t(255, 255, 255), Color_t(0, 0, 0, 0), true);
		//G::BoxStorage.emplace_back(pLocal->m_vecOrigin(), pLocal->m_vecMins(), pLocal->m_vecMaxs(), Vec3(), I::GlobalVars->curtime + 60.f, Color_t(255, 255, 255), Color_t(0, 0, 0, 0), true);

		CTraceFilterWorldAndPropsOnly filter = {};
		std::vector<Face_t> vFaces = F::World.GetFacesInAABB(vMins, vMaxs, MASK_SOLID, &filter, Vars::World::Faces.Value);
		SDK::Output("Faces", std::format("{}", vFaces.size()).c_str(), {}, OUTPUT_CONSOLE);

		if (Vars::World::Draw.Value)
		{
			for (auto& tFace : vFaces)
			{
				if (Vars::World::Offset.Value)
					Math::OffsetPolygon(tFace.m_vVertices, tFace.m_vNormal, Vars::World::Offset.Value);
				if (Vars::World::Resize.Value)
					Math::ExpandPolygon(tFace.m_vVertices, tFace.m_vNormal, Vars::World::Resize.Value);

				F::World.DrawFace(tFace, Vars::World::Draw.Value);

				/*
				for (int i = 0; ++i < tFace.m_vVertices.size() - 1;)
				{
					const Vec3& vVertex1 = tFace.m_vVertices[0], &vVertex2 = tFace.m_vVertices[i], &vVertex3 = tFace.m_vVertices[i + 1];

					Vec3 vDir21 = vVertex2 - vVertex1, vDir31 = vVertex3 - vVertex1;
					float flArea = vDir21.Cross(vDir31).Length() / 2;

					SDK::Output("Area", std::format("{}", flArea).c_str());
				}
				*/
			}
		}
	}
#endif
}

void CVisuals::LocalAnimations(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd, bool bSendPacket)
{
	if (!pLocal->IsAlive() || pLocal->IsAGhost())
	{
		ResetLocalAnimationQueue();
		return;
	}
	if (m_pQueuedLocal != pLocal || m_pQueuedModel != pLocal->GetModel())
		ResetLocalAnimationQueue();
	m_pQueuedLocal = pLocal;
	m_pQueuedModel = pLocal->GetModel();
	const LocalAnimationCommand snapshot = { pCmd->viewangles, pLocal->m_vecVelocity(),
		TICKS_TO_TIME(pLocal->m_nTickBase()), pCmd->command_number, G::AntiAim && !bSendPacket };
	if (!m_vAngles.empty() && m_vAngles.back().command == pCmd->command_number)
		m_vAngles.back() = snapshot;
	else
		m_vAngles.push_back(snapshot);
	if (m_vAngles.size() > 66) // don't grow unbounded if packets are never sent
		m_vAngles.erase(m_vAngles.begin());
	if (pWeapon)
		pWeapon->UpdateAllViewmodelAddons();

	auto pAnimState = pLocal->m_PlayerAnimState();
	if (!pAnimState)
	{
		ResetLocalAnimationQueue();
		return;
	}
	if (!bSendPacket)
		return;

	float flOldFrametime = I::GlobalVars->frametime;
	float flOldCurtime = I::GlobalVars->curtime;
	const Vec3 vOldVelocity = pLocal->m_vecVelocity();
	AnimFrame_t tRealFrame = {};
	bool bRealFrame = false;
	I::GlobalVars->frametime = TICK_INTERVAL;
	for (const auto& command : m_vAngles)
	{
		const auto& vAngle = command.angles;
		I::GlobalVars->curtime = command.time;
		pLocal->m_vecVelocity() = command.velocity;
		if (pLocal->IsTaunting() && pLocal->m_bAllowMoveDuringTaunt())
			pLocal->m_flTauntYaw() = vAngle.y;
		pAnimState->Update(pAnimState->m_flEyeYaw = vAngle.y, vAngle.x);
		pLocal->FrameAdvance(TICK_INTERVAL);
		if (command.realPose)
			bRealFrame = F::AnimInterp.CaptureFrame(pLocal, tRealFrame);
	}
	pLocal->m_vecVelocity() = vOldVelocity;
	// Simulation retains EVERY outgoing command, including the final fake. Only
	// the local display gets the last actual real-command pose, not the fake's
	// eye/torso overwrite. No desired-yaw pose is manufactured here.
	F::AnimInterp.Record(pLocal, int(m_vAngles.size()), true, G::AntiAim && bRealFrame ? &tRealFrame : nullptr);
	I::GlobalVars->frametime = flOldFrametime;
	I::GlobalVars->curtime = flOldCurtime;
	m_vAngles.clear();

	F::AnimInterp.EndBurst(pLocal);
	F::FakeAngle.Run(pLocal);
}

void CVisuals::ResetLocalAnimationQueue()
{
	if (m_pQueuedLocal)
		F::AnimInterp.Forget(m_pQueuedLocal);
	m_vAngles.clear();
	m_pQueuedLocal = nullptr;
	m_pQueuedModel = nullptr;
	F::FakeAngle.bBonesSetup = false;
}
