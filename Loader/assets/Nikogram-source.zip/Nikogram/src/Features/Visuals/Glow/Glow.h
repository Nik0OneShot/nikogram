#pragma once
#include "../../../SDK/SDK.h"

#include <boost/functional/hash.hpp>

class CGlow
{
private:
	bool CheckMaterials();
	void FirstBegin(IMatRenderContext* pRenderContext);
	void FirstEnd(IMatRenderContext* pRenderContext);
	void SecondBegin(IMatRenderContext* pRenderContext, int w, int h);
	void SecondEnd(Glow_t tGlow, IMatRenderContext* pRenderContext, int w, int h);

	void DrawModel(CBaseEntity* pEntity);

	void RenderBacktrack(const DrawModelState_t& pState, const ModelRenderInfo_t& pInfo);
	void RenderFakeAngle(const DrawModelState_t& pState, const ModelRenderInfo_t& pInfo);

	IMaterial* m_pMatGlowColor;
	ITexture* m_pRenderBuffer1;
	ITexture* m_pRenderBuffer2;
	IMaterial* m_pMatHaloAddToScreen;
	IMaterial* m_pMatBlurX;
	IMaterial* m_pMatBlurY;
	IMaterialVar* m_pBloomAmount;



	struct GlowHasher_t
	{
		std::size_t operator()(const Glow_t& k) const
		{
			std::size_t seed = 0;

			boost::hash_combine(seed, boost::hash_value(k.Stencil));
			boost::hash_combine(seed, boost::hash_value(k.Blur));

			return seed;
		}
	};
	struct GlowInfo_t
	{
		CBaseEntity* m_pEntity;
		Color_t m_cColor;
		int m_iFlags = 0;
	};
	std::unordered_map<Glow_t, std::vector<GlowInfo_t>, GlowHasher_t> m_mEntities = {};


	int m_iFlags = false;

public:

	void Store(CTFPlayer* pLocal);
	void RenderFirst();
	void RenderSecond();
	void RenderHandler(const DrawModelState_t& pState, const ModelRenderInfo_t& pInfo, matrix3x4* pBoneToWorld, bool localViewmodel=false);

	void RenderViewmodel(void* rcx, int flags);
	void RenderViewmodel(const DrawModelState_t& pState, const ModelRenderInfo_t& pInfo, matrix3x4* pBoneToWorld, bool localViewmodel=false);

	void Initialize();
	void Unload();

	bool m_bRendering = false;
};

ADD_FEATURE(CGlow, Glow);
