#include "Materials.h"

#include "../Glow/Glow.h"
#include "../CameraWindow/CameraWindow.h"
#include "../../Configs/Configs.h"
#include "../../Binds/Binds.h"
#include "../Groups/Groups.h"
#include "../Dapper/Dapper.h"
#include "../Dapper/WorldPhoto.h"
#include <filesystem>
#include <fstream>

IMaterial* CMaterials::Create(char const* szName, KeyValues* pKV)
{
	IMaterial* pMaterial = I::MaterialSystem->CreateMaterial(szName, pKV);
	if(pMaterial){m_OwnedReferences.Acquire(pMaterial);m_mMatList[pMaterial];}
	return pMaterial;
}

void CMaterials::Remove(IMaterial* pMaterial)
{
	if (!pMaterial || !m_OwnedReferences.Take(pMaterial))
		return;

	if (!m_OwnedReferences.Count(pMaterial)&&m_mMatList.contains(pMaterial))
		m_mMatList.erase(pMaterial);

	pMaterial->DecrementReferenceCount();
	// Match Valve's CMaterialReference shutdown: release our reference and
	// let the material system own deletion, rather than deleting a shader
	// material that a queued render operation may still reference.
	pMaterial = nullptr;
}



void CMaterials::StoreStruct(const std::string& sName, const std::string& sVMT, bool bLocked)
{
	Material_t tMaterial = {};
	tMaterial.m_sName = sName;
	tMaterial.m_sVMT = sVMT;
	tMaterial.m_bLocked = bLocked;

	m_mMaterials[FNV1A::Hash32(sName.c_str())] = tMaterial;
}

static inline void StoreVars(Material_t& tMaterial)
{
	if (tMaterial.m_bStored || !tMaterial.m_pMaterial)
		return;

	tMaterial.m_bStored = true;

	bool bFound; auto $phongtint = tMaterial.m_pMaterial->FindVar("$phongtint", &bFound, false);
	if (bFound)
		tMaterial.m_phongtint = $phongtint;
	
	auto $envmaptint = tMaterial.m_pMaterial->FindVar("$envmaptint", &bFound, false);
	if (bFound)
		tMaterial.m_envmaptint = $envmaptint;
	
	auto $invertcull = tMaterial.m_pMaterial->FindVar("$invertcull", &bFound, false);
	if (bFound && $invertcull && $invertcull->GetIntValueInternal())
		tMaterial.m_bInvertCull = true;
	
	auto $blockoccluded = tMaterial.m_pMaterial->FindVar("$blockoccluded", &bFound, false);
	if (bFound && $blockoccluded && $blockoccluded->GetIntValueInternal())
		tMaterial.m_bBlockOccluded = true;
}

static inline void RemoveVars(Material_t& tMaterial)
{
	tMaterial.m_bStored = false;
	tMaterial.m_phongtint = nullptr;
	tMaterial.m_envmaptint = nullptr;
	tMaterial.m_bInvertCull = false;
	tMaterial.m_bBlockOccluded = false;
}

static inline void ModifyKeyValues(KeyValues* pKV)
{
	pKV->SetString("$model", "1"); // prevent wacko chams

	if (!pKV->FindKey("$cloakfactor"))
	{
		pKV->SetString("$cloakpassenabled", "1");
		auto sName = pKV->GetName();
		if (sName && FNV1A::Hash32(sName) == FNV1A::Hash32Const("VertexLitGeneric"))
		{
			if (auto pProxies = pKV->FindKey("Proxies", true))
				pProxies->FindKey("invis", true);
		}
	}
}



void CMaterials::LoadMaterials()
{
	// default materials
	StoreStruct( // hacky
		"None",
			"\"UnlitGeneric\""
			"\n{"
			"\n\t$color2 \"[0 0 0]\""
			"\n\t$additive \"1\""
			"\n}",
		true);
	StoreStruct(
		"Flat",
			"\"UnlitGeneric\""
			"\n{"
			"\n\t$basetexture \"white\""
			"\n}",
		true);
	StoreStruct(
		"Shaded",
			"\"VertexLitGeneric\""
			"\n{"
			"\n\t$basetexture \"white\""
			"\n}",
		true);
	StoreStruct(
		"Wireframe",
			"\"UnlitGeneric\""
			"\n{"
			"\n\t$basetexture \"white\""
			"\n\t$wireframe \"1\""
			"\n}",
		true);
	StoreStruct(
		"Fresnel",
			"\"VertexLitGeneric\""
			"\n{"
			"\n\t$basetexture \"white\""
			"\n\t$bumpmap \"models/player/shared/shared_normal\""
			"\n\t$color2 \"[0 0 0]\""
			"\n\t$additive \"1\""
			"\n\t$phong \"1\""
			"\n\t$phongfresnelranges \"[0 0.5 1]\""
			"\n\t$envmap \"skybox/sky_dustbowl_01\""
			"\n\t$envmapfresnel \"1\""
			"\n}",
		true);
	StoreStruct(
		"Shine",
			"\"VertexLitGeneric\""
			"\n{"
			"\n\t$additive \"1\""
			"\n\t$envmap \"cubemaps/cubemap_sheen002.hdr\""
			"\n\t$envmaptint \"[1 1 1]\""
			"\n}",
		true);
	StoreStruct(
		"Tint",
			"\"VertexLitGeneric\""
			"\n{"
			"\n\t$basetexture \"models/player/shared/ice_player\""
			"\n\t$bumpmap \"models/player/shared/shared_normal\""
			"\n\t$additive \"1\""
			"\n\t$phong \"1\""
			"\n\t$phongfresnelranges \"[0 0.001 0.001]\""
			"\n\t$envmap \"skybox/sky_dustbowl_01\""
			"\n\t$envmapfresnel \"1\""
			"\n\t$selfillum \"1\""
			"\n\t$selfillumtint \"[0 0 0]\""
			"\n}",
		true);
	Dapper::Load();
	for(int i=0;i<3;++i)
	{
		if(const auto texture=Dapper::TextureName(i))
			StoreStruct(Dapper::Names[i],std::format(
				"\"UnlitGeneric\"\n{{\n$basetexture \"{}\"\n$basetexturetransform \"center .5 .5 scale 4 4 rotate 0 translate 0 0\"\n$model 1\n}}",texture),true);
	}
	// user materials
	for (auto& tEntry : std::filesystem::directory_iterator(F::Configs.m_sMaterialsPath))
	{
		// Ignore all non-material files
		if (!tEntry.is_regular_file() || tEntry.path().extension() != std::string(".vmt"))
			continue;

		std::ifstream fStream(tEntry.path());
		if (!fStream.good())
			continue;

		std::string sName = tEntry.path().filename().string();
		sName.erase(sName.end() - 4, sName.end());
		std::string sVMT((std::istreambuf_iterator(fStream)), std::istreambuf_iterator<char>());

		auto uHash = FNV1A::Hash32(sName.c_str());
		if (uHash == FNV1A::Hash32Const("Original") || m_mMaterials.contains(uHash))
			continue;

		StoreStruct(sName, sVMT);
	}
	// create materials
	for (auto& tMaterial : m_mMaterials | std::views::values)
	{
		KeyValues* kv = new KeyValues(tMaterial.m_sName.c_str());
		if (!kv->LoadFromBuffer(tMaterial.m_sName.c_str(), tMaterial.m_sVMT.c_str()))
		{
			kv->DeleteThis(); // CreateMaterial never took ownership
			continue;
		}

		ModifyKeyValues(kv);
		// Keep saved/display names stable, but do not let photo chams resolve
		// a same-named material retained from an earlier DLL's texture set.
		std::string engineName=tMaterial.m_sName;
		for(int photo=0;photo<3;++photo)
			if(tMaterial.m_sName==Dapper::Names[photo])
				if(const auto texture=Dapper::TextureName(photo))engineName=std::format("{}_chams",texture);
		tMaterial.m_pMaterial = Create(engineName.c_str(), kv);
		//StoreVars(tMaterial);
	}

	F::Glow.Initialize();
	F::CameraWindow.Initialize();

	S::InitializeStandardMaterials.Call<void>();
	auto pMaterial = *reinterpret_cast<IMaterial**>(U::Memory.RelToAbs(S::Wireframe()));
	if(pMaterial)pMaterial->SetMaterialVarFlag(MATERIAL_VAR_VERTEXALPHA, true);

	static std::unordered_map<std::string, int> mSkyboxes = {};
	static std::vector<const char*> vFaces = { "rt.vmt", "lf.vmt", "bk.vmt", "ft.vmt", "up.vmt", "dn.vmt" };
	FileFindHandle_t hFind = -1;
	for (char const* szFile = I::FileSystem->FindFirst("materials/skybox/*.vmt", &hFind); szFile && *szFile; szFile = I::FileSystem->FindNext(hFind))
	{
		std::string sFile = szFile;

		int iFace = -1;
		for (int i = 0; i < vFaces.size(); i++)
		{
			auto sFace = vFaces[i];
			if (sFile.find(sFace) == sFile.length() - strlen(sFace))
			{
				iFace = 1 << i;
				sFile = sFile.substr(0, sFile.length() - strlen(sFace));
				break;
			}
		}
		if (iFace == -1)
			continue;

		mSkyboxes[sFile] |= iFace;
	}
	I::FileSystem->FindClose(hFind);
	Vars::Visuals::World::SkyboxChanger.m_vValues = { "Off" };
	for (auto& [sSkybox, iFaces] : mSkyboxes)
	{
		if (iFaces == 0b111111)
			Vars::Visuals::World::SkyboxChanger.m_vValues.push_back(sSkybox.c_str());
	}

	m_bLoaded = true;
}

void CMaterials::UnloadMaterials()
{
    DapperWorld::Restore();
	m_bLoaded = false;

	for (auto& tMaterial : m_mMaterials | std::views::values)
		Remove(tMaterial.m_pMaterial);
	m_mMaterials.clear();
	m_mMatList.clear();
	Dapper::Unload();

	F::Glow.Unload();
	F::CameraWindow.Unload();
}

void CMaterials::ReloadMaterials()
{
	UnloadMaterials();

	LoadMaterials();
}



void CMaterials::SetColor(Material_t* pMaterial, Color_t tColor)
{
	float r = tColor.r / 255.f;
	float g = tColor.g / 255.f;
	float b = tColor.b / 255.f;
	float a = tColor.a / 255.f;

	I::RenderView->SetColorModulation(r, g, b);
	I::RenderView->SetBlend(a);

	if (pMaterial)
	{
		StoreVars(*pMaterial);
		if (pMaterial->m_phongtint)
			pMaterial->m_phongtint->SetVecValue(r, g, b);
		if (pMaterial->m_envmaptint)
			pMaterial->m_envmaptint->SetVecValue(r, g, b);
	}
}



Material_t* CMaterials::GetMaterial(uint32_t uHash)
{
	if (uHash == FNV1A::Hash32Const("Original"))
		return nullptr;

	return m_mMaterials.contains(uHash) ? &m_mMaterials[uHash] : nullptr;
}

std::string CMaterials::GetVMT(uint32_t uHash)
{
	if (m_mMaterials.contains(uHash))
		return m_mMaterials[uHash].m_sVMT;

	return "";
}

void CMaterials::AddMaterial(const char* sName)
{
	auto uHash = FNV1A::Hash32(sName);
	if (uHash == FNV1A::Hash32Const("Original") || std::filesystem::exists(F::Configs.m_sMaterialsPath + sName + ".vmt") || m_mMaterials.contains(uHash))
		return;

	StoreStruct(
		sName,
			"\"VertexLitGeneric\""
			"\n{"
			"\n\t"
			"\n}"
		);
	auto& tMaterial = m_mMaterials[uHash];

	KeyValues* kv = new KeyValues(sName);
	if (!kv->LoadFromBuffer(sName, tMaterial.m_sVMT.c_str()))
	{
		kv->DeleteThis();
		return;
	}

	ModifyKeyValues(kv);
	tMaterial.m_pMaterial = Create(sName, kv);
	//StoreVars(tMaterial);

	std::ofstream outStream(F::Configs.m_sMaterialsPath + sName + ".vmt");
	outStream << tMaterial.m_sVMT;
	outStream.close();
}

void CMaterials::EditMaterial(const char* sName, const char* sVMT)
{
	if (!std::filesystem::exists(F::Configs.m_sMaterialsPath + sName + ".vmt"))
		return;

	m_bLoaded = false;

	auto uHash = FNV1A::Hash32(sName);
	if (m_mMaterials.contains(uHash) && !m_mMaterials[uHash].m_bLocked)
	{
		auto& tMaterial = m_mMaterials[uHash];

		Remove(tMaterial.m_pMaterial);
		tMaterial.m_pMaterial = nullptr; // Remove() only clears its own copy of the pointer
		RemoveVars(tMaterial);
		tMaterial.m_sVMT = sVMT;

		KeyValues* kv = new KeyValues(sName);
		if (!kv->LoadFromBuffer(sName, sVMT))
		{
			// previously this returned with m_bLoaded still false, which switched off chams/glow until a reload
			kv->DeleteThis();
			m_bLoaded = true;
			SDK::Output("Nikogram", std::format("Material {} has invalid VMT", sName).c_str(), ERROR_COLOR, OUTPUT_CONSOLE | OUTPUT_TOAST | OUTPUT_MENU | OUTPUT_DEBUG, ICON_MD_CANCEL);
			return;
		}

		ModifyKeyValues(kv);
		tMaterial.m_pMaterial = Create(sName, kv);
		//StoreVars(tMaterial);

		std::ofstream outStream(F::Configs.m_sMaterialsPath + sName + ".vmt");
		outStream << sVMT;
		outStream.close();
	}

	m_bLoaded = true;
}

void CMaterials::RemoveMaterial(const char* sName)
{
	if (!std::filesystem::exists(F::Configs.m_sMaterialsPath + sName + ".vmt"))
		return;

	m_bLoaded = false;

	auto uHash = FNV1A::Hash32(sName);
	if (m_mMaterials.contains(uHash) && !m_mMaterials[uHash].m_bLocked)
	{
		Remove(m_mMaterials[uHash].m_pMaterial);
		m_mMaterials.erase(uHash);

		std::filesystem::remove(F::Configs.m_sMaterialsPath + sName + ".vmt");

		auto fRemoveFromVal = [&](std::vector<std::pair<std::string, Color_t>>& val)
		{
			for (auto it = val.begin(); it != val.end();)
			{
				if (FNV1A::Hash32(it->first.c_str()) == uHash)
					it = val.erase(it);
				else
					++it;
			}
		};
		auto fRemoveFromVar = [&](ConfigVar<std::vector<std::pair<std::string, Color_t>>>& var)
		{
			for (auto& [iBind, vVal] : var.Map)
			{
				fRemoveFromVal(vVal);
			}
		};
		for (auto& tGroup : F::Groups.m_vGroups)
		{
			fRemoveFromVal(tGroup.m_tChams.Visible);
			fRemoveFromVal(tGroup.m_tChams.Occluded);
			fRemoveFromVal(tGroup.m_tBacktrackChams.Visible);
			fRemoveFromVal(tGroup.m_tBacktrackChams.Occluded);
		}
	}

	m_bLoaded = true;
}
